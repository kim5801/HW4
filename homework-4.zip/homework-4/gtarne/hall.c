/**
 * @file hall.c
 * @author Grant Arne
 * 
 * Representation of a convention hall which has sections that can be acquired by companies for use
 */

#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep
#include <stdbool.h>

/* Char array for the room statuses */
static char *rooms;
/* Number of total rooms in the hall */
static int numRooms;

/* Condition for blocking a company from aquiring rooms, are there enough rooms for the request */
pthread_cond_t roomAvail;
/* Lock for access to the hall */
pthread_mutex_t hallLock;

/** Checks if there is space available in the hall for n rooms
 * @return the section to start at if there is room, or -1 if there is not room
*/
int spaceAvailable( int n ) {
    // Loop through each starting spot
    for ( int i = 0; rooms[ i ] != '\0'; i++ ) {
        // Check if there is the given number of rooms available starting at i
        for (int j = 0; rooms[ i + j ] == '*' && i + j < numRooms; j++) {
            if ( j == n - 1 ) {
                return i;
            }
        }
    }
    // return -1 if there is no room available
    return -1;
}


/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    // Allocate room for n rooms
    rooms = (char *) malloc( n + 1 );
    numRooms = n;
    for (int i = 0; i < n; i++ ) {
        rooms[i] = '*';
    }
    rooms[n] = '\0';
    // Initialize condition variable and monitor lock
    pthread_mutex_init( &hallLock, NULL );
    pthread_cond_init( &roomAvail, NULL );
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free( rooms );
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock( &hallLock );
    int start = -1;
    bool waiting = false;
    // Check if space is available and wait if it is not
    while( ( start = spaceAvailable( width ) ) == -1 ) {
        if ( !waiting ) {
            printf( "%s waiting: %s\n", name, rooms );
            waiting = true;
        }
        pthread_cond_wait( &roomAvail, &hallLock );
    }
    // Claim the rooms
    for ( int i = start; i < start + width; i++ ) {
        rooms[ i ] = name[ 0 ];
    }
    printf( "%s allocated: %s\n", name, rooms );
    pthread_mutex_unlock( &hallLock );
    return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &hallLock );
    for ( int i = start; i < start + width; i++ ) {
        rooms[ i ] = '*';
    }
    printf( "%s freed: %s\n", name, rooms );
    pthread_cond_signal( &roomAvail );
    pthread_mutex_unlock( &hallLock );
}
