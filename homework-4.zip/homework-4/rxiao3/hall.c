
/**
 * @file hall.c
 * @author Rose Xiao
 * @details Practice with POSIX mutex and conditional variables to implement a simulation of conference hall allocation system.
 */

#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

 //cmd to run
 //gcc -g -Wall -std=c99 -D_XOPEN_SOURCE=500 hall.c driver1.c -o driver1 -lpthread
 //gcc -g -Wall -std=c99 -D_XOPEN_SOURCE=500 hall.c driver2.c -o driver2 -lpthread
 //gcc -g -Wall -std=c99 -D_XOPEN_SOURCE=500 hall.c driver3.c -o driver3 -lpthread
 //gcc -g -Wall -std=c99 -D_XOPEN_SOURCE=500 hall.c driver4.c -o driver4 -lpthread
 //gcc -g -Wall -std=c99 -D_XOPEN_SOURCE=500 hall.c driver10.c -o driver10 -lpthread
 //valgrind --tool=memcheck --leak-check=yes ./driver4

  // Lock for access to the hall.
static pthread_mutex_t monMutex;
//1/more condition variables

//condition for blocking the thread if not enough space for the requested
static pthread_cond_t waitingSpace;
//condition to prevent starvation
static pthread_cond_t starvingThread;

//total spaces
int hallSpace;
//allocated spaces
int allocated;
//the char sequence containing the status of the partitions
char* hall;
//flag to alert that a thread is starved
bool notStarving = false;

/** Initialize the monitor as a hall with n spaces that can be partitioned off. */
void initMonitor( int n )
{

	//pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
	//pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

	//init the mutex
	if ( ( pthread_mutex_init( &monMutex, NULL ) ) != 0 ) {
		fprintf( stderr, "Error Initalizing the Mutex\n" );
		exit( EXIT_FAILURE );
	}
	if ( ( pthread_cond_init( &waitingSpace, NULL ) ) != 0 || ( pthread_cond_init( &starvingThread, NULL ) ) != 0 ) {
		// //checks if initializing the condition variables were successful
		fprintf( stderr, "Error Initalizing the Conditonal\n" );
		exit( EXIT_FAILURE );
	}



	//malloc a buffer with given length
	hall = ( char* )malloc( sizeof( char ) * n + 1 );

	//set each hall as available
	for ( int i = 0; i < n; i++ ) {
		hall [ i ] = '*';
	}
	//set a null terminator to help with printing out the report
	hall [ n ] = 0;

	hallSpace = n;
	allocated = 0;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
	//free the hall
	free( hall );
}

/** Called when an organization wants to reserve the given number
	(width) of contiguous spaces in the hall.  Returns the index of
	the left-most (lowest-numbered) end of the space allocated to the
	organization. */
int allocateSpace( char const* name, int width )
{
	//Enter the monitor
	pthread_mutex_lock( &monMutex );

	//left-most index if available
	int index;
	//age of current thread
	int age = 0;

	//to report that the thread is in waiting state
	if ( ( hallSpace - allocated ) < width ) {
		printf( "%s waiting: %s\n", name, hall );
	}

	//Block until spaces equal or greater are available
	while ( ( hallSpace - allocated ) < width ) {

		//label to make the thread wait for more space to be freed
		//checkpoint after checking if contigous space is available...
	CHECK:
		//increment the age
		age++;
		//check if it's being starved for too long
		if ( age > 100 ) {
			notStarving = true;
		}
		//make thread wait and give the monitor to someone else
		pthread_cond_wait( &waitingSpace, &monMutex );

	}

	//counts consecutive spaces
	int ct = 0;

	//flag to see if contigous space is available...
	bool found = false;
	//loop through hall
	for ( int i = 0; i < hallSpace; i++ ) {
		//if not a free space,, continue
		//reset count to 0
		if ( hall [ i ] != '*' ) {
			ct = 0;
			continue;
		}
		ct++;
		//if found a fit section,, return i as the left most index
		if ( ct == width ) {
			index = i - width + 1;
			found = true;
			break; //stop searching
		}
	}

	//if not found a consecutive section,, block until available
	if ( !found ) {
		goto CHECK;
	}

	//if another thread is idle being starved,, let them go first even if current thread could go first
	while ( notStarving ) {
		pthread_cond_wait( &starvingThread, &monMutex );
	}

	//set the first letter as the company's name
	for ( int i = index; i < ( index + width ); i++ ) {
		hall [ i ] = name [ 0 ];
	}

	//update the number of space allocated
	allocated += width;
	// Leave the monitor
	pthread_mutex_unlock( &monMutex );
	printf( "%s allocated (%d): %s\n", name, age, hall );
	return index;

}

/** Release the allocated spaces from index start up to (and including)
	index start + width - 1. */
void freeSpace( char const* name, int start, int width )
{
	// Enter the monitor
	pthread_mutex_lock( &monMutex );

	//free the space
	for ( int i = start; i < ( start + width ); i++ ) {
		hall [ i ] = '*';
	}

	//update the number of space allocated
	allocated -= width;

	//reset the aging flag since now all the starved threads are satiated
	if ( notStarving ) {
		notStarving = false;
	}
	//BROADCAST--not signal--to alert all threads
	pthread_cond_broadcast( &waitingSpace ); //freed up space
	pthread_cond_broadcast( &starvingThread ); //freed up space after preemption
	// Leave the monitor
	pthread_mutex_unlock( &monMutex );
	printf( "%s freed: %s\n", name, hall );

}

