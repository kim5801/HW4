import java.util.Random;

public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  // An object representing the lock .
  private static Object cookingLock = new Object();
  private static boolean griddle = true;
  private static boolean mixer = true;
  private static boolean oven = true;
  private static boolean blender = true;
  private static boolean grill = true;
  private static boolean fryer = true;
  private static boolean microwave = true;
  private static boolean coffeeMaker = true;

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( coffeeMaker && microwave ) {
                coffeeMaker = false;
                microwave = false;
            } else {
                while ( !coffeeMaker || !microwave ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 105 );
        
        synchronized ( cookingLock ) {
            coffeeMaker = true;
            microwave = true;
            cookingLock.notifyAll();
        }
        
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( blender && oven && mixer ) {
                blender = false;
                oven = false;
                mixer = false;
            } else {
                while ( !blender || !oven || !mixer ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 30 );
        
        synchronized ( cookingLock ) {
            blender = true;
            oven = true;
            mixer = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( blender && grill ) {
                blender = false;
                grill = false;
            } else {
                while ( !blender || !grill ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 60 );
        
        synchronized ( cookingLock ) {
            blender = true;
            grill = true;
            cookingLock.notifyAll();
        }
        
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( coffeeMaker && microwave && griddle ) {
                coffeeMaker = false;
                microwave = false;
                griddle = false;
            } else {
                while ( !coffeeMaker || !microwave || !griddle ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 15 );
        
        synchronized ( cookingLock ) {
            coffeeMaker = true;
            microwave = true;
            griddle = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( fryer && oven ) {
                fryer = false;
                oven = false;
            } else {
                while ( !fryer || !oven ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 45 );
        
        synchronized ( cookingLock ) {
            fryer = true;
            oven = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( grill && griddle ) {
                grill = false;
                griddle = false;
            } else {
                while ( !grill || !griddle ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 15 );
        
        synchronized ( cookingLock ) {
            grill = true;
            griddle = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( mixer && griddle ) {
                mixer = false;
                griddle = false;
            } else {
                while ( !mixer || !griddle ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 15 );
        
        synchronized ( cookingLock ) {
            mixer = true;
            griddle = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( fryer && microwave && blender ) {
                fryer = false;
                microwave = false;
                blender = false;
            } else {
                while ( !fryer || !microwave || !blender ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 60 );
        
        synchronized ( cookingLock ) {
            fryer = true;
            microwave = true;
            blender = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( fryer && grill ) {
                fryer = false;
                grill = false;
            } else {
                while ( !fryer || !grill ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 75 );
        
        synchronized ( cookingLock ) {
            fryer = true;
            grill = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run()  {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( cookingLock ) {
            if ( coffeeMaker && oven && mixer ) {
                coffeeMaker = false;
                oven = false;
                mixer = false;
            } else {
                while ( !coffeeMaker || !oven || !mixer ) {
                    try {
                        cookingLock.wait();
                    } catch ( InterruptedException e ) {
                    }
                }
            }
        }
        cook( 30 );
        
        synchronized ( cookingLock ) {
            coffeeMaker = true;
            oven = true;
            mixer = true;
            cookingLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
