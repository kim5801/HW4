#include "hall.h"
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

static int num;
static int freeSpaces = 0;
static char* hall;

static pthread_mutex_t monitor;
static pthread_cond_t cond;

/*
static int curCap = 5;
static int numOrgs = 0;
static char** names;
*/

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    pthread_mutex_init( &monitor, NULL );
    pthread_cond_init( &cond, NULL);
    num = n;
    freeSpaces = n;
    hall = malloc( sizeof( char ) * num + 1 );
    
    for ( int i = 0; i < num; i++ ) {
        hall[ i ] = '*';
    }
    hall[ num ] = '\0';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free( hall );
    
    /*
    for ( int i = 0; i < numOrgs; i++ ) {
        free( names[ i ] );
    }
    free( names ); 
    */
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

    pthread_mutex_lock( &monitor );
    
    bool allocated = 0;
    bool keepGoing = 1;
    int firstIdx = 0;
    int firstCheck = 1;

    while ( freeSpaces < width ) {
        if ( firstCheck ) {
            printf( "%s waiting: %s\n", name, hall );
        }
        pthread_cond_wait( &cond, &monitor );
        firstCheck = 0;
    }
    while ( !allocated ) {
        for ( int i = 0; i <= num - width; i++ ) {
            allocated = 1;
            if ( keepGoing ) {
                for ( int j = i; j < i + width; j++ ) {
                    if ( hall[ j ] != '*' ) {
                        allocated = 0;
                    }
                } 
                if ( allocated ) {
                    firstIdx = i;
                    keepGoing = 0;
                }
            }
        }
    }
    
    for ( int i = firstIdx; i < firstIdx + width; i++ ) {
        hall[ i ] = name[ 0 ];
    }
    
    freeSpaces -= width;
    printf( "%s allocated: %s\n", name, hall );
    
    pthread_mutex_unlock( &monitor );
    
    return firstIdx;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    for ( int i = start; i < start + width; i++ ) {
        hall[ i ] = '*';
    }
    
    freeSpaces += width;
    printf( "%s freed: %s\n", name, hall );
    
    pthread_cond_signal( &cond );
}