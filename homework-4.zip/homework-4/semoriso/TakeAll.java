import java.util.Random;

public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  // An object representing the lock on each appliance.
  // Locking the needed objects before cooking prevents two
  // chefs from trying to use the same appliance at the same time.
  private static boolean griddle = false;
  private static boolean mixer = false;
  private static boolean oven = false;
  private static boolean blender = false;
  private static boolean grill = false;
  private static boolean fryer = false;
  private static boolean microwave = false;
  private static boolean coffeeMaker = false;
  private static Object chefCheck = new Object();

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (coffeeMaker || microwave) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            coffeeMaker = true;
            microwave = true;
        }
        cook( 105 );
        synchronized (chefCheck) {
            microwave = false;
            coffeeMaker = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (oven || blender || mixer) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            blender = true;
            oven = true;
            mixer = true;
        }
        cook( 30 );
        synchronized (chefCheck) {
            blender = false;
            oven = false;
            mixer = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (blender || grill) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            blender = true;
            grill = true;
        }
        cook( 60 );
        synchronized (chefCheck) {
            blender = false;
            grill = false;
            chefCheck.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (coffeeMaker || griddle || microwave) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            griddle = true;
            microwave = true;
            coffeeMaker = true;
        }
        cook( 15 );
        synchronized (chefCheck) {
            griddle = false;
            microwave = false;
            coffeeMaker = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (oven || fryer) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            fryer = true;
            oven = true;
        }
        cook( 45 );
        synchronized (chefCheck) {
            fryer = false;
            oven = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (grill || griddle) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            grill = true;
            griddle = true;
        }
        cook( 15 );
        synchronized (chefCheck) {
            grill = false;
            griddle = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (griddle || mixer) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            griddle = true;
            mixer = true;
        }
        cook( 15 );
        synchronized (chefCheck) {
            griddle = false;
            mixer = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (blender || fryer || microwave) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            microwave = true;
            fryer = true;
            blender = true;
        }
        cook( 60 );
        synchronized (chefCheck) {
            microwave = false;
            fryer = false;
            blender = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (fryer || grill) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            fryer = true;
            grill = true;
        }
        cook( 75 );
        synchronized (chefCheck) {
            fryer = false;
            grill = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( chefCheck ) {
            while (oven || coffeeMaker || mixer) {
              try {
                chefCheck.wait();
              }
              catch (InterruptedException e) {
                  //hello
              }
            }
            mixer = true;
            coffeeMaker = true;
            oven = true;

        }
        cook( 30 );
        synchronized (chefCheck) {
            mixer = false;
            coffeeMaker = false;
            oven = false;
            chefCheck.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
