#include "hall.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <stdbool.h>
    /** Resizable array to keep track of rooms in use */
    char *room;
    /** Count of how many spots are available */
    int count;
    /** Monitor to use for synchronization */
    pthread_mutex_t monitor;
    /** Condition variable to signal whether or not there are free spots */
    pthread_cond_t freeSpots;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    room = malloc(n * sizeof(char) + 1);
    for (int i = 0; i < n; i++) {
        room[i] = '*'; //period as placeholder to show empty
    }
    room[n] = '\0'; //null terminated string
    count = strlen(room);
    pthread_mutex_init(&monitor, NULL);
    pthread_cond_init(&freeSpots, NULL);
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free(room);
    pthread_cond_destroy(&freeSpots);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    bool goodSize = false; //if a good size was found before the next iteration
    bool started = false; //whether or not the tested string has a starting position
    bool printed = false; //don't need to print 'waiting' more than once per go
    pthread_mutex_lock(&monitor); //lock the monitor
    char ch = name[0]; 
    int start = -1; //start index to be returned at end, dummy value
    //wait if all spots are full or if not enough are available
    while (width > count) { //wait until told ready
        if (!printed) {
            printf("%s waiting: %s\n", name, room);
            printed = true;
        }
        pthread_cond_wait(&freeSpots, &monitor);
    }
    for (int i = 0; i < strlen(room); i++) {
        for (int j = i; j < width + i; j++) {
            if (room[j] == '*') { //check to make sure all vals are *
                if (!started) {
                    started = true;
                    start = j;
                }
                goodSize = true;
            }
            else { //if not enough adjacent space
                goodSize = false;
                started = false;
            }
        }
        if (goodSize) { 
            for (int j = start; j < width + start; j++) {
                room[j] = ch; //first letter of people in charge
            }
            count -= width; //subtract by # of spots just taken
            printf("%s allocated: %s\n", name, room);
            break;
        }
    }
    pthread_mutex_unlock(&monitor); //leave critical section
    return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    for (int i = start; i < start + width; i++) {
            room[i] = '*';
    }
    printf("%s freed: %s\n", name, room);
    count += width; //show number of spots used has decreased
    pthread_cond_signal( &freeSpots ); //signal there are more free spots!
}
