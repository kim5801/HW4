#include <stdio.h>
#include <unistd.h>    // for usleep
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <stdbool.h>
#include "hall.h"


/** Mutex lock */
pthread_mutex_t muteOne = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t muteTwo = PTHREAD_MUTEX_INITIALIZER;

/** Condition variables  */
pthread_cond_t condOne;
pthread_cond_t condTwo;

char freeUse = '*';

//character array hall 
char *hall;

//size of hall to be set
int size;

void initMonitor( int n ) {
    hall = malloc( n * sizeof(char) + 1);
    size = n;
    for (int i = 0; i < n; i++) {
        hall[i] = freeUse;
    }
    pthread_cond_init(&condOne, NULL);
    pthread_cond_init(&condTwo, NULL);


}

void destroyMonitor() {
    pthread_cond_destroy( &condOne );
    pthread_cond_destroy( &condTwo );

}

int allocateSpace( char const *name, int width ) {
    bool printOnce = false;
    label:;
    //lock monitor to make changes to hall
    pthread_mutex_lock( &muteOne );


    //index to be saved for return statement
    int index = 0;


    //checks to see if open section is valid
    bool valid = false;

    //checks to make sure each space is open while checking open sections
    bool foundSpace = false;


    
    //loop through the entire hall
    for (int i = 0; i < size; i++) {
        //loop through any potential openings where there are openings
        for (int j = i; j < i + width; j++) {
            
            //if theres no open space, break out of first loop
            if (hall[j] != '*') {
                foundSpace = false;
                break;
            }
            //keep note that there are openings while going through
            else {
                foundSpace = true;
            }
        }
        //if spaces are good, note the index, note its valid, and break out
        if (foundSpace) {
            index = i;
            valid = true;
            break;
        }
        

    }


    //if theres not an open space wait
    if (valid == false) {
        if (printOnce == false) {
            printf("%s waiting: %s\n", name, hall);
        }
        pthread_cond_wait(&condOne, &muteOne);
        //unlock for other changes to be made
        pthread_mutex_unlock( &muteOne );
        printOnce = true;
        goto label;
        
    }
    
    //loop through index to index + width and set name
    for (int i = index; i < index + width; i++) {
        hall[i] = name[0];
    }

    //print statement for whats been allocated
    printf("%s allocated: %s\n", name, hall);
    

    //unlock for other changes to be made
    pthread_mutex_unlock( &muteOne );

    //return index of first position open
    return index;

}

void freeSpace( char const *name, int start, int width ) {

    //lock monitor to make changes to hall
    pthread_mutex_lock( &muteOne );

    //set everything back to open space
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }
    
    //signal that space has been freed
    pthread_cond_signal(&condOne);

    //print new hall after being freed
    printf("%s freed: %s\n", name, hall);


    

    //unlock for other changes to be made
    pthread_mutex_unlock( &muteOne );
    
}