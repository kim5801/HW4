/**
 * @file hall.c
 * @author Arul Sharma (asharm52)
 * This program works with a driver program to allocate space for threads in a large hall, simulating a conference
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

// Lock for access to the buffer.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the process of freeing threads
pthread_cond_t freeCond = PTHREAD_COND_INITIALIZER;
// Condition for blocking the work allocation
pthread_cond_t allocCond = PTHREAD_COND_INITIALIZER;

// arr of chars, each char represents a company currently using a conference room in the hall
static char* arr;
// the number of rooms available in the hall
static int hallSize;
// the number of rooms that are empty in the hall
static int emptySpots;

/**
 * this intitalized the monitor representing the hall
 * @param n the number of rooms in the hall
 */
void initMonitor( int n ) {
    arr = (char*)malloc(n * sizeof(char));
    hallSize = n;
    emptySpots = n;
    for (int i = 0; i < n; i++) {
        arr[i] = '*';
    }
}

/**
 * this method destroys the monitor by freeing any space that needs to be freed
 */
void destroyMonitor() {
    free(arr);
}

/**
 * this method checks the hall array to see if there is space for a new company to take a room
 * @param width the width of the new room
 * @return true if there is space, false if there isn't
 */
bool checkForSpace(int width) {
    int counter = 0;
    for (int i = 0; i < hallSize; i++) {
        if (arr[i] == '*') {
            counter++;
        } else {
            counter = 0;
        }
        if (counter == width) {
            return true;
        }
    }
    return false;
}

/**
 * this method prints the current state of the hall
 * @return the string representing the current state of the hall
 */
char *allocReport() {
    // char ret[hallSize];
    char ret[hallSize + 1];
    char *ret_ptr = ret;
    for (int i = 0; i < hallSize; i++) {
        ret[i] = arr[i];
    }
    return ret_ptr;
}

/**
 * this method allocates space for a new room in the hall, checks for space and then adds to the hall
 * @param name the name of the new hall
 * @param width the width of the new room
 * @return the leftmost index in the array where the new room was added
 */
int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock( &mon );   // Enter the monitor
    bool messagePrinted = false;
    // checkForSpace(width);
    while (!checkForSpace(width)) {
        if(!messagePrinted) {
            printf("%s waiting: %s\n", name, allocReport());
            messagePrinted = true;
        }
        pthread_cond_wait( &allocCond, &mon );
    }

    char firstLetter = name[0];
    int leftmost;
    int counter = 0;
    for (int i = 0; i < hallSize; i++) {
        if (arr[i] == '*') {
            counter++;
        } else {
            counter = 0;
        }
        if (counter == width) {
            for (int j = counter; j > 0; j--) {
                arr[i] = firstLetter;
                if (j == 1) {
                    leftmost = i;
                }
                i--;
            }
            break;
        }
    }
    printf("%s ", name);
    printf("allocated: %s\n", allocReport());
    emptySpots = emptySpots - width;
    pthread_cond_signal( &freeCond );
    pthread_mutex_unlock( &mon );  // Leave the monitor

    return leftmost;
}

/**
 * this method frees space from the hall when a room can be emptied
 * @param name the name of the room that needs to be freed
 * @param start the starting index in the array where the room starts
 * @param width the width of the room to be freed
 */
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &mon );   // Enter the monitor
    while(emptySpots == hallSize) {
        pthread_cond_wait( &freeCond, &mon );
    }

    for (int i = start; i < (start + width); i++) {
        arr[i] = '*';
    }

    printf("%s freed: %s\n", name, allocReport());
    pthread_cond_signal( &allocCond );
    pthread_mutex_unlock( &mon );  // Leave the monitor
}

