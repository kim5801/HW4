#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "hall.h"

// Lock for access to the buffer.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

//dynamic list of characters, showing what's taken and available
static char *rooms;

//number of total rooms in hall
static int numRooms;

// Condition for if there is space or not in the hall
pthread_cond_t spaceCond = PTHREAD_COND_INITIALIZER;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {

    //set global variable number of rooms
    numRooms = n;

    //make it a list of n characters
    rooms = (char *) malloc(n * sizeof(char));

    //initialize all rooms to empty
    for (int i = 0; i < n; i++) {
        rooms[i] = '*';
    }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    //free heap array
    free (rooms);

    //destroy space condition variable and make sure it doesn't fail
    int ret = pthread_cond_destroy(&spaceCond); 
    if (ret != 0) {
        fail("Cannot destroy condition variable");
    }
}

/** Print the current allocation array with a new line char */
void currentAllocation() {
    for (int j = 0; j < numRooms; j++) {
        printf("%c", rooms[j]);
    }
    printf("\n");
}

/** Return the largest number of contiguous free spaces in the hall */
int largestFreeSpace() {
    //largest spot available
    int max = 0;
    //number of consecutive empty rooms
    int count = 0;
    //go through all possible rooms
    for (int i = 0; i < numRooms; i++) {
        //if an empty room increaes the count
        if (rooms[i] == '*') {
           count++;

        //if it's not, update max if appropriate and reset count
        } else {
            if (count > max) {
                max = count;
            }
            count = 0;
        }
    }

    //one last check for max in case last space was empty
    if (count > max) {
        max = count;
    }

    return max;
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    
    //enter monitor
    pthread_mutex_lock(&mon);

    //not enough space, so make it wait
    if (largestFreeSpace() < width) {
        //print the message
        printf("%s waiting: ", name);
        currentAllocation();

        //keep it in while loop waiting
        while(largestFreeSpace() < width) {
            pthread_cond_wait(&spaceCond, &mon);
        }
    }
    //count is number of available spots
    int count = 0;

    int i = 0;
    for (; i < numRooms; i++) {
        if (rooms[i] == '*') {
            count++;
            //found where there is enough room for guest, so leave loop
            if (count == width) {
                break;
            }
        //hit a taken room, so start count over
        } else {
            count = 0;
        }
    }

    //start is the index of first available room
    int start = i - width + 1;
    //update room array with first letter of name
    for (int j = start; j < start + width; j++) {
        rooms[j] = name[0];
    }

    //print the message
    printf("%s allocated: ", name);
    currentAllocation();

    //exit monitor
    pthread_mutex_unlock(&mon);

    return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    //enter monitor
    pthread_mutex_lock(&mon);

    //update rooms array to empty the spots
    for (int i = start; i < start + width; i++) {
        rooms[i] = '*';
    }
    //print the message
    printf("%s freed: ", name);
    currentAllocation();

    //wake up everyone waiting on space
    pthread_cond_broadcast(&spaceCond);

    //exit monitor
    pthread_mutex_unlock(&mon);
}
