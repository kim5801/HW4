/**
  This file is called by driver files. It implements a monitor to protect a hall
  and section allocations. Threads call allocateSpace in the hall to use some space in 
  the hall. Once the thread is done with the space it freeSpace from the hall which
  allows other threads to use the hall.
  @file hall.c
  @author Gabriella Micheli gsmichel
*/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hall.h"

pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the consumer, are there some items.
pthread_cond_t availCond = PTHREAD_COND_INITIALIZER;

char *hall;
int totalfree;
int maxSize;
/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. 
    @param n the number of spaces
    
*/
void initMonitor( int n )
{
  hall = (char *)malloc( n * sizeof(char));
  for ( int i = 0; i < n; i++){
    hall[i] = '*';
  }
  maxSize = n;
  totalfree = n;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
  free(hall);
}

/**
  Helper function to print monitor
*/
void printMonitor()
{
  for (int i = 0; i < maxSize; i++){
    printf("%c", hall[i]);
  }
  printf("\n");
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. 
    @param name the name of the org using space
    @param width the width of the space used
*/
int allocateSpace( char const *name, int width )
{
  pthread_mutex_lock( &mon );   // Enter the monitor
  bool space = false;
  int start = 0;
  int count = 0;
  for (int i = 0; i < maxSize; i++){
    if (hall[i] == '*'){
      count++;
      if( count == width ){
        start = (i + 1 - count);
        space = true;
      }
    } else {
      count = 0;
    }
  }
  if (!space ){
    printf( "%s waiting: ", name);
    printMonitor();
  }
  while ( !space ){	// Block until there's a slot
    pthread_cond_wait( &availCond, &mon );
    start = 0;
    count = 0;
    for (int i = 0; i < maxSize; i++){
      if (hall[i] == '*'){
        count++;
        if( count == width ){
          start = (i + 1 - count);
          space = true;
        }
      } else {
        count = 0;
      }
    }
  }
  char initial = name[0];
  for( int i = start; i < (start + width); i++ ){
    hall[i] = initial;
  }
  totalfree = totalfree - width;
  
  
  printf( "%s allocated: ", name);
  printMonitor();
  //printf("%s start: %d\n",name, start);
  pthread_mutex_unlock( &mon );
  return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. 
    @param name the name of the org using space
    @param start the start of the space used
    @param width the width of the space used
*/
void freeSpace( char const *name, int start, int width )
{
  pthread_mutex_lock( &mon );
  for( int i = start; i < (start + width); i++ ){
    hall[i] = '*';
  }
  printf( "%s freed: ", name);
  printMonitor();
  pthread_cond_signal( &availCond );
  pthread_mutex_unlock( &mon );
}
