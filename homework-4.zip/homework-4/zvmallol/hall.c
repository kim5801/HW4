#define _OPEN_THREADS
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

/* String of the hall. * represents empty, and if a room is occupied,
 * it is represented by the first letter of the owner's name 
 */
char *hall;

/* length of the hall */
int hallLength;

/* Pass to access the hall. Only one thread can be allocating rooms at a time */
pthread_mutex_t hallPass;

/* Signalled whenever rooms are freed to let waiting threads know space is
 * available
 */
pthread_cond_t roomsFreed;

void initMonitor( int n ) {
  // Creates a null terminated string of the hall
  hallLength = n;
  hall = malloc(sizeof(char) * hallLength + 1);
  for(int i = 0; i < hallLength; i++) {
    hall[i] = '*';
  }
  hall[hallLength] = '\0';

  // Initializes mutex and condition
  pthread_mutex_init(&hallPass, NULL);
  pthread_cond_init(&roomsFreed, NULL);
}

void destroyMonitor() {
  // Free hall string
  free(hall);
  // Destroy hall pass mutex
  pthread_mutex_destroy(&hallPass);
  // Destroy condition
  pthread_cond_destroy(&roomsFreed);
}

int allocateSpace( char const *name, int width ) {
  // We know we haven't found a start index if it's -1
  int startIndex = -1;
  int space = 0;
  // Gain a lock on hall pass so we don't mess with other threads
  pthread_mutex_lock(&hallPass);

  // Go through one loop without waiting
  for(int i = 0; i < hallLength; i++) {
    if(hall[i] == '*') {
      space++;
    }
    else {
      space = 0;
    }

    if(width == space) {
      startIndex = i - space + 1;
      for(int j = startIndex; j < startIndex + space; j++) {
        hall[j] = name[0];
      }
      pthread_mutex_unlock(&hallPass);
      printf("%s allocated: %s\n", name, hall);
      return startIndex;
    }
  }

  // At this point we're waiting on space to be freed
  printf("%s waiting: %s\n", name, hall);
  pthread_mutex_unlock(&hallPass);
  while(startIndex == -1) {
    pthread_cond_wait(&roomsFreed, &hallPass);

    space = 0;
    for(int i = 0; i < hallLength; i++) {
      if(hall[i] == '*') {
        space++;
      }
      else {
        space = 0;
      }

      if(width == space) {
        startIndex = i - space + 1;
        for(int j = startIndex; j < startIndex + space; j++) {
          hall[j] = name[0];
        }
        printf("%s allocated: %s\n", name, hall);
        break;
      }
    }
    pthread_mutex_unlock(&hallPass);
  }
  return startIndex;
}

void freeSpace( char const *name, int start, int width ) {
  // Acquire a lock so we can clear out the rooms
  pthread_mutex_lock(&hallPass);
  for(int i = start; i < start + width; i++) {
    hall[i] = '*';
  }

  printf("%s freed: %s\n", name, hall);
  pthread_mutex_unlock(&hallPass);
  // Let other threads who may be waiting for allocation know new space is free
  pthread_cond_signal(&roomsFreed);
}
