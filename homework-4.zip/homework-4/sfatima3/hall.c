/**
 * Using monitor hall to allow companies to reserve space
 * @file hall.c
 * @author Sameeha Fatima
 */

#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep

#include "hall.h"

//monitor that allocates spaces to different companies
static char* hall;

//mutex lock that's used when to modify hall
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

//used when a company is waiting for space
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

/**
 * Initializes monitor with the specified n space
 * @param n how large the monitor will be
 */
void initMonitor( int n ) {
  //malloc memory into hall monitor
  hall = malloc( sizeof( *hall ) * n + 1 );
  
  //fill monitor with *'s
  for (int i = 0; i < n; i++) {
    hall[i] = '*';
  }
  
  //null terminator
  hall[n] = '\0';
}

//free mutex, condition, and hall monitor
void destroyMonitor() {
  pthread_mutex_destroy( &lock );
  pthread_cond_destroy( &cond );
  free( hall );
}

/**
 * Allocates spaces to a company if there are enough spaces to fulfill the width.
 * @param name name of the company 
 * @param width how many spaces the company wants
 */
int allocateSpace( char const *name, int width ) {
  pthread_mutex_lock(&lock);
  
  //starting index of free space
  int startingIndex = 0;
  
  //checks to see if appropriate open space is available or not
  //int wait = 0;
  
  //counts the number of available spaces for a group
  int count = 0;
  
  //if the first iteration of the while loop has already been done, this variable will increment
  //to make sure that the waiting message only gets printed once
  int iterationAboveFirst = 0;

  int j = 0;
    //iterate through hall
    while (hall[j] != '\0') {
      //if the space is free
      if (hall[j] == '*') {
        //if this is the start of the free space group
        if (count == 0) {
          startingIndex = j;
        }
        count++;
      }
      //if the space is not free
      else {
        //if the number of spaces in the free space group is greater or equal to how many spaces
        //the company wants, then you no longer have to wait
        if (count >= width) {
           //wait = 1;
           break;
        }
        //end of the free space group
        count = 0;
      }

      j++;
    }

  //wait until there is a free spot that a name can occupy
  while (count < width) { 
    //if this hasn't been through the first iteration of the while loop
    if (iterationAboveFirst == 0) {
      //print out waiting report
      printf("%s waiting: %s\n", name, hall);
    }
    //the thread now waits until space has been freed by another company
    pthread_cond_wait(&cond, &lock);   
    startingIndex = 0;
    int j = 0;
    //iterate through hall
    while (hall[j] != '\0') {
      //if the space is free
      if (hall[j] == '*') {
        //if this is the start of the free space group
        if (count == 0) {
          startingIndex = j;
        }
        count++;
      }
      //if the space is not free
      else {
        //if the number of spaces in the free space group is greater or equal to how many spaces
        //the company wants, then you no longer have to wait
        if (count >= width) {
           //wait = 1;
           break;
        }
        //end of the free space group
        count = 0;
      }

      j++;
    }
    
    //if the number of spaces in the free space group is greater or equal to how many spaces
    //the company wants, then you no longer have to wait
    if (count >= width) {
      //wait = 1;
    }
    
    //went through at least one iteration of the while loop
    iterationAboveFirst = 1;
  }

  //allocate name into open hall spaces
  for (int i = startingIndex; i < (width + startingIndex); i++) {
    hall[i] = name[0];
  }
  
  //print out allocated report
  printf("%s allocated: %s\n", name, hall);
  
  //unlock
  pthread_mutex_unlock(&lock);
  
  //return starting index
  return startingIndex;
}

void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock(&lock);

  //free from hall monitor
  for (int i = start; i <= start + width - 1; i++) {
    hall[i] = '*';
  }
  
  //print out freed report
  printf("%s freed: %s\n", name, hall);
  
  //broadcast to the other threads that space has been opened up
  pthread_cond_broadcast(&cond);
  
  //unlock
  pthread_mutex_unlock(&lock);
}