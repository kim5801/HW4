/**
 * @file hall.c
 * @author Alex Sawdy (adsawdy)
 * monitor that manages and allocates rooms of a hallway to different groups
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>
#include <semaphore.h>
#include <pthread.h>
#include "hall.h"

// declaration of function to print character representation of halls
void printAllocation();

// Lock for access to the buffer
pthread_mutex_t lock;
// Pointer to condition for blocking the various parties when attempting to allocate halls
pthread_cond_t allocateCond;
// Pointer to list of integers to represent halls
int *halls;
// Length of the hall for convenience
int len;
// the highest aged wating group
int maxAge = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

void initMonitor( int n ) {  
  // initialize monitor's main lock and condition for blocking
  if (pthread_mutex_init( &(lock), NULL ) != 0)
    fail("failed to initialize monitor mutex/lock");
  if (pthread_cond_init( &(allocateCond), NULL ) != 0)
    fail("failed to initialize monitor condition");
  
  // initialize hall to be an array of integers n long
  halls = malloc(sizeof(int) * n);
  // initialize all integers within array to be -1 to denote that they are free to be allocated
  for (int i = 0; i < n; i++) {
    halls[i] = -1;
  }
  // initialize length of the hall to n
  len = n;
}

void destroyMonitor() {
  // must free all malloced data
  // 1: free halls
  free(halls);
  // 2: free monitor
}

int allocateSpace( char const *name, int width ) {
  // acquire access to monitor
  pthread_mutex_lock( &lock ); // enter monitor
  
  int age = 0;
  int index = -1;
  bool canAllocate = false;
  
  // if can find space to allocate, do it. if can't, block
  do {
    // if age considerably smaller than maxAge, immediately block
    while (age + 100 < maxAge) {
      printf("%s waiting: ", name);
      printAllocation();
      pthread_cond_wait( &allocateCond, &lock );
    }
    
    // things for checking things
    int count = 0;
    index = -1; // redo because checks multiple times if blocked
    canAllocate = false;
    
    // find first index with enough space to fit
    for (int i = 0; i < len; i++) {
      //printf("%c : %d : idx=%d : count=%d\n", name[0], i, index, count);
      if (halls[i] != -1) {
        index = -1; // need to reset index to next free space
        count = 0;
      } else {
        if (index == -1) {
          index = i; // new index to count from
        }
        count++; // increment count in hopes that it exceeds width
      }
      if (count >= width) {
        canAllocate = true;
        break; // found first index with enough space
      }
    }
    
    // if canAllocate is true, then exits without blocking and allocates, otherwise blocks and then rechecks (after signalled)
    if (canAllocate == false) {
      printf("%s waiting: ", name);
      printAllocation();
      // before blocking, increment age to prevent complete starvation
      age++;
      
      pthread_cond_wait( &allocateCond, &lock );
      
      // set maxAge if new max
      if (age > maxAge) {
        maxAge = age;
      }
    }
  } while (canAllocate == false);
  
  if (index == -1 || index >= len) {
    fail("index not found correctly");
  }
  
  // allocate (just change the integer array representation)
  for (int i = index; i < index + width; i++) {
    // double check working correctly
    if (halls[i] != -1) {
      fail("tried to set already allocated hall");
    }
    // set hall to first letter of name from index to index + witdth - 1
    halls[i] = name[0];
  }
  
  // "reset" max age if max aged group finally made it through
  if (age == maxAge) {
    maxAge = 0;
  }
  
  printf("%s allocated (%d): ", name, age);
  printAllocation();

  pthread_mutex_unlock( &lock ); // exit monitor
  // wake another trying to allocate now that we have exited (if blocked)
  pthread_cond_signal( &allocateCond );
  
  return index;
}

void freeSpace( char const *name, int start, int width ) {
  // acquire access to monitor
  pthread_mutex_lock( &lock ); // enter monitor
  
  for (int i = start; i < start + width; i++) {
    // double check working correctly
    if (halls[i] == -1) {
      fail("tried to free non-allocated hall");
    }
    halls[i] = -1;
  }
  
  printf("%s freed: ", name);
  printAllocation();

  pthread_mutex_unlock( &lock ); // exit monitor
  // signal all those waiting for allocation that they may be able to progress (might be problematic??)
  pthread_cond_broadcast( &allocateCond ); // "compete" over mutex lock (does this require to enter the lock again??) -> nah
}

// should only be called by one instance at a time, prints current representation of halls
void printAllocation() {
  for (int i = 0; i < len; i++) {
    if (halls[i] == -1) {
      printf("*");
    } else {
      printf("%c", halls[i]);
    }
  }
  printf("\n");
}