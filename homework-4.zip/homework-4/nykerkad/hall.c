/**
   @file hall.c
   @author Natalie Kerkado nykerkad
   This program allocates contigious space to different organization in a hall of 
   specified space.
  */

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <stdbool.h>
#include "hall.h"


char* hall;
int spaces = 0;
// Lock for access to the hall.
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t cond = PTHREAD_COND_INITIALIZER;



/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
  spaces = n;
  hall = (char*)malloc(n * sizeof(char));
  for(int i = 0; i < n; i++ ) {
    hall[i] = '*';
  }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  free(hall);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  pthread_mutex_lock( &lock );   // Enter the monitor
  bool found = false;
  bool waited = false;
  int index = 0;
  while( !found ) {
  index = 0;
  int counter = 0;
    //loop looking for contiguous space
    for(int i = 0; i < spaces; i++) {
      if( hall[i] == '*' ) {
        counter++;
        if(counter == width ) {
          found = true;
          // starting index to assign letter
          index = (i + 1) - width;
        }
      }
      else {
        counter = 0;
      }
    }
    if(!found) {
      if (!waited)
        printf( "%s waiting: %s\n", name, hall );
      pthread_cond_wait( &cond, &lock );
      waited = true;
    }
  }

  //assign letters if space is found
  if(found) {
    for(int i = index; i < index + width; i++ ) {
      hall[i] = name[0];
    }
    printf( "%s allocated: %s\n", name, hall );

  }
  
  pthread_mutex_unlock( &lock );  //leave the monitor
  
  return index;
  
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock( &lock );
  for(int i = start; i < start + width; i++ ) {
    hall[i] = '*';
    
  }
  printf( "%s freed: %s\n", name, hall );
  pthread_cond_signal( &cond );
  pthread_mutex_unlock( &lock );
}



