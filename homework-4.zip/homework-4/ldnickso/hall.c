/**
  @file hall.c
  @author Lane Nickson (ldnickso)
  Homework 4, Part 2
*/

#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h>

// Lock for enforcing synchronization
static pthread_mutex_t lock;
// Condition Variables
static pthread_cond_t waitForSpace;
// Array keeping track of the used rooms
static char * hall;
// Size of the hall
static int size;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
  // Initialize the mutex lock
  pthread_mutex_init( &lock, NULL );
  // Initialize the waitForSpace condition variable
  pthread_cond_init( &waitForSpace, NULL);

  // Allocate enough memory for a character (room) array of length n
  hall = (char *) malloc(n * sizeof(char));
  size = n;
  // Fill array with star symbols
  for( int i = 0; i < n; i++) {
    hall[i] = '*';
  }

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  free(hall);
  pthread_mutex_destroy(&lock);
  pthread_cond_destroy(&waitForSpace);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  // Enter the monitor
  pthread_mutex_lock( &lock );

  //Set up allocated variable
  bool printedMessage = false;

  // This will loop until a free space is found
  while (true) {
    int contigFreeSpace = 0;
    int contigStartingIndex = 0;
    for(int i = 0; i < size; i++) {
      //Increments counter if there's a contiguous free space, resets otherwise
      if (hall[i] == '*') {
        contigFreeSpace++;
        if (contigFreeSpace == 1) {
          contigStartingIndex = i;
        }
      }
      else {
        contigFreeSpace = 0;
      }

      //Reserve the space if there is enough room
      if (contigFreeSpace == width) {
        for (int j = contigStartingIndex; j <= contigStartingIndex + width - 1;  j++) {
          hall[j] = name[0];
        }
        printf("%s allocated: %s\n", name, hall);

        //Remove the lock and return the beginning index to the allocated space
        pthread_mutex_unlock( &lock );
        return contigStartingIndex;
      }

    }
      //If we reach here, there isn't enough free space. We have to wait for an opening.
      if (!printedMessage) {
        printf("%s waiting: %s\n", name, hall);
        printedMessage = true;
      }
      pthread_cond_wait(&waitForSpace, &lock);
  }

  //We should never reach the end of this function. Return value here just makes the compiler happy.
  return 0;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  // Enter the monitor
  pthread_mutex_lock( &lock );

  // Return the hall array back to empty stars
  for(int i = start; i <= start + width - 1; i++) {
    hall[i] = '*';
  }
  printf("%s freed: %s\n", name, hall);

  // Signal that more space could be allocated. Wa
  pthread_cond_broadcast(&waitForSpace);

  // Release the lock and exit the monitor
  pthread_mutex_unlock( &lock );
}