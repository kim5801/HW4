/**
    @file hall.c
    @author Thomas Welch
    hall is responsible for allocating available block of contiguous space so that no two threads
    have access to the same space simultaneously
 */
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

#include "hall.h"

//Total number of spaces
static int numSpaces;
//Array of all spaces
static char *spaces;
//Largest available space
static int largestSpace;
//Declare the lock
pthread_mutex_t lock;
//Condition of new space being open
pthread_cond_t spaceFreed;
//Condition of space being allocated, to determine age
pthread_cond_t spaceAllocated;

void initMonitor( int n ) {
    //Set number of spaces to n
    numSpaces = n;
    //Set largestSpace equal to n
    largestSpace = n;
    //Allocate memory for spaces
    spaces = (char *)malloc((n + 1) * sizeof(char));
    //Set spaces to asterisks to indicate free spaces
    memset(spaces, '*', numSpaces);
    //Set last char of spaces to null terminator so it can be printed as a string
    spaces[n] = '\0';
    //Initialize the mutex lock
    pthread_mutex_init( &lock, NULL );
    //Initialize the condition variable
    pthread_cond_init( &spaceFreed, NULL);
}

void destroyMonitor() {
    //Free the allocated space
    free(spaces);
}

int allocateSpace( char const *name, int width ) {
    //Count of contiguous available space
    int count = 0;
    //Starting index of space
    int startingSpace = -1;
    //Tracks whether waiting statement has already been declared
    bool declaredWaiting = false;

    //Enter the monitor
    pthread_mutex_lock( &lock );

    // Block until there's room if needed
    while ( largestSpace < width ) {
        if (!declaredWaiting) {
            //Print wait statement
            printf("%s waiting: %s\n", name, spaces);
            //Indicated that wait statement has been declared
            declaredWaiting = true;
        }
        pthread_cond_wait( &spaceFreed, &lock );
    }
    //Iterate through array to find wide enough space
    for (int i = 0; i < numSpaces; ++i) {
        //Case of empty space
        if (spaces[i] == '*') {
            //Check if starting index hasn't been set
            if (startingSpace == -1) {
                //Set new starting index
                startingSpace = i;
            }
            //Increment count
            count++;
            //Enough space has been found
            if (count == width) {
                for (int j = 0; j < width; ++j) {
                    //Set the value of the newly allocated spaces
                    spaces[startingSpace + j] = name[0];
                }
                //Break out of loop now that space has been found
                break;
            }
        } else {
            //Reset count
            count = 0;
            //Reset starting index
            startingSpace = -1;
        }
    }

    //Print allocation statement
    printf("%s allocated: %s\n", name, spaces);

    //Update the largest position 
    //Count of largest space found
    int largest = 0;
    //Current count
    count = 0;
    //Iterate through array to find new largest space
    for (int i = 0; i < numSpaces; ++i) {
        //Case of empty space
        if (spaces[i] == '*') {
            //Increment count
            count++;
            //Update largest if necessary
            if (count >= largest) {
                largest = count;
            }
        } else {
            //Reset count
            count = 0;
        }
    }
    //Update global variable for largest space
    largestSpace = largest;

    //Leave the monitor
    pthread_mutex_unlock( &lock );
    //Return found starting index
    return startingSpace;
}

void freeSpace( char const *name, int start, int width ) {
    //Enter the monitor
    pthread_mutex_lock( &lock );

    //Set previously allocated space to free
    for (int i = 0; i < width; ++i) {
        //Indicate space is free with asterisk
        spaces[start + i] = '*';
    }
    //Print free statement
    printf("%s freed: %s\n", name, spaces);

    //Count of largest space found
    int largest = 0;
    //Current count
    int count = 0;
    //Iterate through array to find new largest space
    for (int i = 0; i < numSpaces; ++i) {
        //Case of empty space
        if (spaces[i] == '*') {
            //Increment count
            count++;
            //Update largest if necessary
            if (count > largest) {
                largest = count;
            }
        } else {
            //Reset count
            count = 0;
        }
    }
    //Update global variable for largest space
    largestSpace = largest;
    //Wake waiting threads
    pthread_cond_broadcast( &spaceFreed );
    //Leave the monitor
    pthread_mutex_unlock( &lock );
}
