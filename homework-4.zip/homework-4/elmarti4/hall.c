#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep
#include <stdbool.h>
#include <string.h>
#include "hall.h"

// Hall where all spaces are stored
char *hall;

// Basic Monitor
pthread_mutex_t mon;

// Condition for allocating space on heap
pthread_cond_t alloc;

// Age limit for each loop
int ageLimit;

void initMonitor( int n ) {
    pthread_mutex_init( &mon, NULL );

    pthread_cond_init( &alloc, NULL );

    // Create spaces in the hall
    hall = ( char * ) malloc( n * sizeof( char ) + 1 );
    for ( int i = 0; i < n; i++ ) {
        hall[ i ] = '*';
    }

    // Add null terminator for string functions
    hall[ n ] = '\0';

    // Initial age for the loop
    ageLimit = 1;
}

void destroyMonitor() {
    pthread_mutex_destroy( &mon );
    pthread_cond_destroy( &alloc );
    free( hall );
}

int allocateSpace( char const *name, int width ) {

    // Create star string to check hall for space
    char stars[ width + 1 ];

    for ( int i = 0; i < width; i++) {
        stars[ i ] = '*';
    }
    stars[ width ] = '\0';
    
    // Lock monitor
    pthread_mutex_lock( &mon );

    // Check if the required space is available
    char *hallReplace = strstr( hall, stars );

    // If no space is available, wait until there is space.
    while ( hallReplace == NULL ) {
        printf( "%s waiting: %s\n", name, hall );
        pthread_cond_wait( &alloc, &mon );
        hallReplace = strstr( hall, stars );
    }

    // Get index of available space
    int replace = hallReplace - hall;

    // Replace *s with letters
    for ( int k = replace; k < replace + width; k++ ) {
        hall[ k ] = name[ 0 ];
    }
    printf( "%s allocated : %s\n", name, hall );

    // Unlock monitor after allocation is done
    pthread_mutex_unlock( &mon );

    // Return the index of the hall spaces you allocated
    return replace;
}

void freeSpace( char const *name, int start, int width ) {
    for ( int i = start; i < start + width; i++) {
        hall[ i ] = '*';
    }

    printf( "%s freed: %s\n", name, hall );

    pthread_cond_broadcast( &alloc );
}
