#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <limits.h>

#include "hall.h"

pthread_mutex_t lock;
char * hall;
int hallSize;
pthread_cond_t cond;

void initMonitor( int n ) {
  hallSize = n;
  //Set up mutex for monitor
  if (pthread_mutex_init( &lock, NULL ) != 0) {
    printf( "Monitor init has failed.\n" );
    exit( 1 );
  }
  //Set up condition for waiting on empty space updates.
  if (pthread_cond_init( &cond, NULL) != 0) {
    printf( "Condition init has failed.\n" );
    exit( 1 );
  }
  //Allocate memory for a hall
  hall = malloc( (n + 1) * sizeof(char) );
  //Set to empty
  memset( hall, '*', n * sizeof(char) );
  //Null terminator so it can be easily printed
  hall[n] = '\0';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  pthread_mutex_destroy( &lock );
  free( hall );
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  pthread_mutex_lock( &lock );
  int minFree = INT_MAX;
  int minFreeLocation = -1;
  //Try again until space is found, using break to get out of the loop
  while(true) {
    int freeCount = 0;
    for (int i = 0; i <= hallSize; i++) {
      if(i < hallSize && hall[i] == '*') {
        //Found an empty space, count it and move on
        freeCount++;
      }
      else {
      	//Found a occupied space
      	if(freeCount < minFree && freeCount >= width) {
      	  //Found a candidate string of empty spaces with some length. Keep going to try and find a minimum one
          minFree = freeCount;
          minFreeLocation = i - freeCount;
        }
        freeCount = 0;
      }
    }
    //If a fitting space was found get out of the loop
    if(minFree <= hallSize) {
      break;
    }
    //Otherwise wait for a change to be made to the hall
    printf( "%s waiting: %s\n", name, hall );
    pthread_cond_wait(&cond, &lock);
  }
  //Update the hall
  for(int i = minFreeLocation; i < minFreeLocation + width; i++) {
    hall[i] = name[0];
  }
  //Done
  printf( "%s allocated: %s\n", name, hall );
  pthread_mutex_unlock( &lock );
  return minFreeLocation;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock( &lock );
  //Clear any letters in the hall spaces
  for(int i = start; i < start + width; i++) {
    hall[i] = '*';
  }
  printf( "%s freed: %s\n", name, hall );
  //Tell other threads that some space is free and they may be able to get their space
  pthread_cond_signal(&cond);
  pthread_mutex_unlock( &lock );
  
}
