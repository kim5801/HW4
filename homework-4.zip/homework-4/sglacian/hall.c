/*
 * Implementation of using POSIX mutex and condition variables to 
 * simulate a conference hall allocation system.
 * @file hall.c
 * @author Sophia Laciano
 */
 
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static pthread_mutex_t lock;

static pthread_cond_t spaceCond;

/* Keeps track of which parts of the hall are in use.
    0 means the space is open and 1 means the space is in use */
char *hall;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    // Initialize mutex lock.
    pthread_mutex_init( &lock, NULL );
    
    // Initialize condition variables.
    pthread_cond_init( &spaceCond, NULL );
    
    hall = (char*)malloc( n * sizeof( char ) );
        
    for ( int i = 0; i < n; i++ ) {
        hall[ i ] = '*';
    }

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    
    pthread_cond_destroy( &spaceCond );  
    free(hall);  
    
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {


    pthread_mutex_lock( &lock );
    
    int maxSpace = 0;
    int starterIndex = -1;
    int i = 0;
    for( int j = 0; j < strlen(hall); j++ ) {
        // If the space is empty:
        if ( hall[ j ] == '*' ) {
            // If we are at the first empty space, make this the starter index.
            if ( maxSpace == 0 ) {
                starterIndex = j;
            }
            maxSpace++;
            
            // Break if we have found enough consecutive spaces for n.
            if ( maxSpace >= width ) {
                break;
            }
        }
        // If the space is occupied:
        else {
            maxSpace = 0;
        }
    }
    
    if ( maxSpace < width ) {
        // Print allocation report while waiting.
        printf( "%s waiting: ", name );
        for( int j = 0; j < strlen(hall); j++ ) {
            printf( "%c", hall[ j ] );
        }
        printf("\n");
    }
    // If we don't have enough space for n, wait.
    while ( maxSpace < width ) {
        pthread_cond_wait( &spaceCond, &lock );
        
        i = 0;
        starterIndex = -1;
        maxSpace = 0;
        for( int j = 0; j < strlen(hall); j++ ) {
            // If the space is empty:
            if ( hall[ j ] == '*' ) {
                // If we are at the first empty space, make this the starter index.
                if ( maxSpace == 0 ) {
                    starterIndex = j;
                }
                maxSpace++;
            
                // Break if we have found enough consecutive spaces for n.
                if ( maxSpace >= width ) {
                    break;
                }
            }
            // If the space is occupied:
            else {
                maxSpace = 0;
            }
        }
        
    }
    
    // Now we have space.
    for ( i = starterIndex; i < width + starterIndex; i++ ) {
        hall[ i ] = name[0];
    }
    // Print updated allocation report.
    printf( "%s allocated: ", name );
    for( int j = 0; j < strlen(hall); j++ ) {
        printf( "%c", hall[ j ] );
    }
    printf("\n");
    
    
    pthread_mutex_unlock( &lock );  

    return starterIndex;
    
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    
    pthread_mutex_lock( &lock );   
    
    for ( int i = start; i <= start + width - 1; i++ ) {
        hall[ i ] = '*';
    }
    
    pthread_cond_signal( &spaceCond );
    
    // current allocation report.
    printf( "%s freed: ", name );
    for( int j = 0; j < strlen(hall); j++ ) {
        printf( "%c", hall[ j ] );
    }
    printf("\n");
    
    
    pthread_mutex_unlock( &lock );   
}


