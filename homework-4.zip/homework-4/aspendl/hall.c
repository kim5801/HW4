#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "hall.h"

// Stores information for a range of the Hall
typedef struct HallRange_T {
	int len;
	char const* owner; // can be used to check if range is taken (not occupied: owner == NULL)
	struct HallRange_T* next;
} *HallRange;

// Creates a new HallRange node
HallRange hallRangeFactory(int len, char const* owner, HallRange next) {
	HallRange creat = malloc(sizeof(struct HallRange_T));
	creat->len = len;
	creat->owner = owner;
	creat->next = next;
	return creat;
}

// Total available slots (used for error checking)
static int total = 0;
// Variable storing the Hall
static HallRange hall;

// Print the current allocation of the HallRange and subsequent HallRanges
void printHall() {
	for (HallRange search = hall; search; search = search->next)
		for (int i = 0; i < search->len; i++)
			printf("%c", search->owner ? search->owner[0] : '*');
	printf("\n");
}

//synchronization variables
static pthread_mutex_t hallMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t hallCondition = PTHREAD_COND_INITIALIZER;

void initMonitor(int n) {
	// Can't initialize with non-positive amount
	if (n < 1) return;
	// Can't initialize more than once
	if (total) return;

	hall = hallRangeFactory(n, NULL, NULL);
	total = n;
}

void destroyMonitor() {
	// free each node on the list
	HallRange toFree = hall;
	while (toFree) {
		HallRange next = toFree->next;
		free(toFree);
		toFree = next;
	}
	total = 0;
}

int allocateSpace(char const* name, int width) {
	// bad input handling
	if (width < 1 || total < width) return -1;

	bool waitMsg = true;

	// get a lock (after error handling so bad calls don't wait for nothing to happen)
	pthread_mutex_lock(&hallMutex);

	while (true) { // don't return until slot is occupied
		// search for an available slot
		int idx = 0;
		for (HallRange search = hall; search; search = search->next) {
			if (!search->owner && search->len >= width) { // slot available
				if (search->len > width) { // larger than needed
					search->next = hallRangeFactory(search->len - width, NULL, search->next);
					search->len = width;
				}
				// take ownership
				search->owner = name;

				printf("%s allocated: ", name);
				printHall();
				pthread_mutex_unlock(&hallMutex);
				return idx;
			}
			idx += search->len;
		}

		// slot not available (print current allocation and wait)
		if (waitMsg) {
			printf("%s waiting: ", name);
			printHall();
			waitMsg = false;
		}
		pthread_cond_wait(&hallCondition, &hallMutex);
	}

	// just incase something supernatural happens
	pthread_mutex_unlock(&hallMutex);
	return 0;
}

void freeSpace(char const* name, int start, int width) {
	// bad input handling
	if (width < 1 || total < width || start < 0 || total < start + width) return;

	// get a lock (after error handling so bad calls don't wait for nothing to happen)
	pthread_mutex_lock(&hallMutex);

	// search for the appropriate HallRange (maintain current and previous node variables)
	for (HallRange search = hall, prev = NULL; search; search = (prev = search)->next) {
		if (start == 0 && search->len == width && search->owner && strcmp(search->owner, name) == 0) { // HallRange found
			search->owner = NULL;

			// merge with next if exists and free
			HallRange next = search->next;
			if (next && !next->owner) {
				search->len += next->len;
				search->next = next->next;
				free(next);
			}

			// merge with previous if exists and free
			if (prev && !prev->owner) {
				prev->len += search->len;
				prev->next = search->next;
				free(search);
			}

			printf("%s freed: ", name);
			printHall();
			pthread_cond_broadcast(&hallCondition);
			break;
		}
		// 'start' can be interpreted as the number of spaces preceeding the HallRange
		start -= search->len;
	}

	pthread_mutex_unlock(&hallMutex);
}
