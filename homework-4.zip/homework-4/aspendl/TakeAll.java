import java.util.Random;

public class TakeAll {
  /**
   * To tell all the chefs when they can quit running.
   */
  private static boolean running = true;

  /**
   * Superclass for all chefs.  Contains methods to cook and rest and
   * keeps a record of how many dishes were prepared.
   */
  private static class Chef extends Thread {
    /**
     * Each appliance has an 'available' flag, compressed here into a single flags int
     * The order of the flags is: blender, coffee, fryer, griddle, grill, microwave, mixer, oven
     */
    private int appliancesUsed;
    /**
     * Number of dishes prepared by this chef.
     */
    private int dishCount = 0;

    /**
     * Source of randomness for this chef.
     */
    private final Random rand = new Random();

    /**
     * This constructor takes care of the order of the bit flags
     */
    protected void setAppliancesUsed(boolean blender, boolean coffee, boolean fryer, boolean griddle, boolean grill, boolean microwave, boolean mixer, boolean oven) {
      appliancesUsed = (blender ? 0b1000_0000 : 0) | (coffee ? 0b0100_0000 : 0) | (fryer ? 0b0010_0000 : 0) | (griddle ? 0b0001_0000 : 0)
              | (grill ? 0b0000_1000 : 0) | (microwave ? 0b0000_0100 : 0) | (mixer ? 0b0000_0010 : 0) | (oven ? 0b0000_0001 : 0);
    }

    protected int getAppliancesUsed() {
      return appliancesUsed;
    }

    /**
     * Called after the chef has locked all the required appliances and is
     * ready to cook for about the given number of milliseconds.
     */
    protected void cook(int duration) {
      System.out.printf("%s is cooking\n", getClass().getSimpleName());
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep(rand.nextInt(duration / 2) + duration / 2);
      } catch (InterruptedException ignored) {
      }
      dishCount++;
    }

    /**
     * Called between dishes, to let the chef rest before cooking another dish.
     */
    protected void rest() {
      System.out.printf("%s is resting\n", getClass().getSimpleName());
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep(rand.nextInt(25 / 2) + 25 / 2);
      } catch (InterruptedException ignored) {
      }
    }
  }

  private static class Kitchen {
    // Each appliance has an 'available' flag, compressed here into a single flags int
    // The order of the flags is: blender, coffee, fryer, griddle, grill, microwave, mixer, oven
    private int appliances = 0b1111_1111;

    private synchronized void useAppliance(int needToUse) {
      while ((appliances & needToUse) != needToUse)
        try {
          wait();
        } catch (InterruptedException e) {
          throw new RuntimeException(e);
        }
      appliances &= ~needToUse;
    }

    private synchronized void releaseAppliances(int doneWith) {
      appliances |= doneWith;
      notifyAll();
    }
  }

  private static final Kitchen kitchen = new Kitchen();

  /**
   * Mandy is a chef needing 105 milliseconds to prepare a dish.
   */
  private static class Mandy extends Chef {
    Mandy() {
      setAppliancesUsed(false, true, false, false, false, true, false, false);
    }

    public void run() {
      while (running) {

        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(105);
        // Release the appliances this chef uses.
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Edmund is a chef needing 30 milliseconds to prepare a dish.
   */
  private static class Edmund extends Chef {
    Edmund() {
      setAppliancesUsed(true, false, false, false, false, false, true, true);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(30);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Napoleon is a chef needing 60 milliseconds to prepare a dish.
   */
  private static class Napoleon extends Chef {
    Napoleon() {
      setAppliancesUsed(true, false, false, false, true, false, false, false);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(60);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Prudence is a chef needing 15 milliseconds to prepare a dish.
   */
  private static class Prudence extends Chef {
    Prudence() {
      setAppliancesUsed(false, true, false, true, false, true, false, false);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(15);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Kyle is a chef needing 45 milliseconds to prepare a dish.
   */
  private static class Kyle extends Chef {
    Kyle() {
      setAppliancesUsed(false, false, true, false, false, false, false, true);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(45);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Claire is a chef needing 15 milliseconds to prepare a dish.
   */
  private static class Claire extends Chef {
    Claire() {
      setAppliancesUsed(false, false, false, true, true, false, false, false);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(15);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Lucia is a chef needing 15 milliseconds to prepare a dish.
   */
  private static class Lucia extends Chef {
    Lucia() {
      setAppliancesUsed(false, false, false, true, false, false, true, false);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(15);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Marcos is a chef needing 60 milliseconds to prepare a dish.
   */
  private static class Marcos extends Chef {
    Marcos() {
      setAppliancesUsed(true, false, true, false, false, true, false, false);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(60);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Roslyn is a chef needing 75 milliseconds to prepare a dish.
   */
  private static class Roslyn extends Chef {
    Roslyn() {
      setAppliancesUsed(false, false, true, false, true, false, false, false);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(75);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  /**
   * Stephenie is a chef needing 30 milliseconds to prepare a dish.
   */
  private static class Stephenie extends Chef {
    Stephenie() {
      setAppliancesUsed(false, true, false, false, false, false, true, true);
    }

    public void run() {
      while (running) {
        // Get the appliances this chef uses.
        kitchen.useAppliance(getAppliancesUsed());
        cook(30);
        kitchen.releaseAppliances(getAppliancesUsed());

        rest();
      }
    }
  }

  public static void main(String[] args) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef[] chefList = {
            new Mandy(),
            new Edmund(),
            new Napoleon(),
            new Prudence(),
            new Kyle(),
            new Claire(),
            new Lucia(),
            new Marcos(),
            new Roslyn(),
            new Stephenie(),
    };

    // Start running all our chefs.
    for (Chef chef : chefList) chef.start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep(10000);
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for (Chef chef : chefList) {
      chef.join();
      System.out.printf("%s cooked %d dishes\n",
              chef.getClass().getSimpleName(),
              chef.dishCount);
      total += chef.dishCount;
    }
    System.out.printf("Total dishes cooked: %d\n", total);
  }
}
