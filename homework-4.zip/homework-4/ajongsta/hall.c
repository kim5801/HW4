#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Conference room
static char * conference;
// Size of our conference room
static int size;
// Our monitor
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition variable
pthread_cond_t roomCond = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    // Initialize our conference space with size n. All values should be empty in our array.
    conference =  ( char * )malloc( n*sizeof( char ) );
    for( int i = 0; i < n; i++ ) {
        conference[ i ] = '*';
    }
    // Initialize the size of our conference space
    size = n;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free( conference );
}

/**
* Returns the starting index of the smallest first best space for our organization.
* Returns a negative integer if there's not enough space.
* @param width the amount of space required for the organization
* @return the starting index of the first smallest space for the organization.
*/
int smallestSpace( int width ) {
    // Keeps track of our smallest streak
    int smallestStreak = -1;
    // Keeps track of our current streak of free space
    int currentStreak = 0;
    // Tells us we have a streak going.
    int ongoing = 0;
    // Tracks the starting index of a streak.
    int index = 0;
    // Tracks the starting index of our best streak.
    int finalIndex = -1;
    // Iterates through our array and tells us if there's a streak of free space.
    for( int i = 0; i < size; i++ ) {
        // Find free space!
        if( conference[ i ] == '*' ) {
            //If we didn't have a streak going, start one and save our starting index.
            if( ongoing == 0 ) {
                ongoing = 1;
                index = i;
            }
            currentStreak++;
            if( ( i == size - 1) && currentStreak == size ) {
                return index;
            }
            if( i == size - 1 ) {
                if( currentStreak == width ) {
                    return index;
                }

                if( ( currentStreak < smallestStreak || smallestStreak < 0 ) && currentStreak > width ) {
                    smallestStreak = currentStreak;
                    finalIndex = index;
                }
            }
        } else {
            // Streak is over.
            ongoing = 0;
            // Checks if our streak perfectly meets our width requirement (first best).
            if( currentStreak == width ) {
                return index;
            }
            
            // Ensures that our current streak is smaller than our smallest streak but is still larger
            // than the width we need.
            if( ( currentStreak < smallestStreak || smallestStreak < 0 ) && currentStreak > width ) {
                smallestStreak = currentStreak;
                finalIndex = index;
            }
            currentStreak = 0;
        }
    }
    // Return our best index.
    return finalIndex;
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    // The first character of the organization
    char first = name[ 0 ];
    // Checks if it's already been waiting
    int waitBefore = 0;
    // Returns the starting index of the smallest first space available for that organization
    int startingIndex = smallestSpace( width );
    // If that starting index is invalid (no space available).
    while( startingIndex < 0 ) {
        if( waitBefore == 0 ) {
            // Let the user know we're waiting
            printf( "%s waiting: %s\n", name, conference );
            waitBefore = 1;
        }
        // Wait policy
        pthread_mutex_lock(&mon);  
        pthread_cond_wait( &roomCond, &mon );
        pthread_mutex_unlock(&mon);  
        //Check index again
        startingIndex = smallestSpace( width );
        //printf("Hey my name is %s and my starting index is %d.\n", name, startingIndex);
    }
    waitBefore = 0;
    // Iterate through an update our conference indeces to include this organization
    for( int i = startingIndex; i < ( startingIndex + width ); i++ ) {
        conference[ i ] = first;
    }
    // Print our successful allocation and return the starting index returned from smallestSpace.
    printf( "%s allocated: %s\n", name, conference );
    pthread_cond_broadcast( &roomCond );
    return startingIndex;
}

/** Release the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    for(int i = start; i < ( start + width ); i++ ) {
        conference[ i ] = '*';
    }
    // Wake other threads and have them try again
    pthread_cond_broadcast( &roomCond );
    // Print our free message.
    printf( "%s freed: %s\n", name, conference );
}