/**
 * @file hall.c
 * @author ssomasu 
 * This is a program that implements the monitor functions.
 * 
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

static char *hall;
static int numSpaces;
static int numSpacesUsed;
// static int threadAge;

// Lock for access to the buffer.
static pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t allocCond = PTHREAD_COND_INITIALIZER;
static pthread_cond_t freeCond = PTHREAD_COND_INITIALIZER;
// static pthread_cond_t threadcount = PTHREAD_COND_INITIALIZER;

// This method gets the index of the leftmost slot and can be used to check if a valid slot exists in the hall
int checkHall (int width) {
    int count = 0;
    for (int i = 0; i < numSpaces; i++) {
        if (hall[i] == '*') {
            count++;
            if (count == width) {
                return (i+1) - width;
            }
        }
        else {
            count = 0;
        }
    }

    return -1;
}

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {

    hall = (char *) malloc( n * sizeof(char));
    for (int i = 0; i < n; i++ ) {
        hall[i] = '*';
    }
    numSpaces = n;
    numSpacesUsed = 0;
    // printf("initalized");

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free(hall);

}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

    bool waitMessage = true;

    // threadAge = 0;
    pthread_mutex_lock( &mon );   // Enter the monitor
    // check to see if there are any valid slots available in the slot
    while ( checkHall(width) == -1 ) {
        // print out the waiting message
        if (waitMessage) {
            printf("%s waiting: %s\n", name, hall);
            waitMessage = false;
        }

        // wait for the model to update to check the availability again
        pthread_cond_wait( &freeCond, &mon );
    }

    // this is the index value of the start of the space to be allocated
    int indexVal = checkHall(width);
    // start character of the name of the organization
    char startChar = name[0];
    // adds the organization to the hall
    for (int i = 0; i < width; i++) {
        hall[indexVal + i] = startChar;
    }
    numSpacesUsed += width;    
    printf("%s allocated: %s\n", name, hall);

    // Let freeSpace know there are items in the hall now
    pthread_cond_signal( &allocCond );
    pthread_mutex_unlock( &mon );  // Leave the monitor

    return indexVal;


}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &mon );   // Enter the monitor
    // check to make there is something in the hall before we free space
    while(numSpacesUsed == 0) {
        // wait for the model to update to check the used spaces again
        pthread_cond_wait( &allocCond, &mon );
    }
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }
    printf("%s freed: %s\n", name, hall);
    pthread_cond_signal( &freeCond );
    pthread_mutex_unlock( &mon );  // Leave the monitor


}