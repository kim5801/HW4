#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>

// Initializing the monitor lock
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// Initializing the conditional variable that wait for more space
// or signals when space is freed
pthread_cond_t space = PTHREAD_COND_INITIALIZER;

// Character array of the hall
char *hall;

// Size of the hall
int hallSize;

// Initializes the monitor with a hall of size n
void initMonitor( int n ) {
  // Allocates heap space for the hall
  // Note the + 1 is added so the character array
  // can be null terminated and printed out as a String
  hall = (char *)malloc(n + 1);
  // Null terminate last character
  hall[n] = '\0';
  // Initialize each unit of the hall as free (*)
  for (int i = 0; i < n; i++) {
    hall[i] = '*';
  }
  // Set the hall size
  hallSize = n;
}

// Frees the heap space allocated to the monitor
void destroyMonitor() {
  free(hall);
}

// Assigns continuous hall space of width to the given company name
int allocateSpace( char const *name, int width) {
  // Locks the monitor
  pthread_mutex_lock(&lock);
  
  // These variables are used to loop through the hall and decide if
  // there is enough space currently which would make valid = true
  int start = -1;
  int len = 0;
  bool valid = false;
  for (int i = 0; i < hallSize; i++) {
    // When the space is free
    if (hall[i] == '*') {
      // Start new count from space i if needed
      if (start == -1) {
        start = i;
      }
      // Increment count of continuous hall spaces
      len++;
      // If enough spaces, break the loop
      if (len == width) {
        valid = true;
        break;
      }
    }
    // When the space is not free start the count over
    else {
      len = 0;
      start = -1;
    }
  }
  
  // When there is not enough space initially
  if (!valid) {
    // Output that the company name is waiting
    printf("%s waiting: %s\n", name, hall);
    // While there's not enough space, wait for 
    // more space to be freed by another thread and
    // then use the previous method to look for
    // enough space
    while (!valid) {
      pthread_cond_wait(&space, &lock);
      start = -1;
      len = 0;
      for (int i = 0; i < hallSize; i++) {
        if (hall[i] == '*') {
          if (start == -1) {
            start = i;
          }
          len++;
          if (len == width) {
            valid = true;
            break;
          }
        }
        else {
          len = 0;
          start = -1;
        }
      }
    }
  }
  
  // Set the hall spaces from start to width - 1 
  // to the first letter of the company name
  for (int i = start; i < start + width; i++) {
    hall[i] = name[0];
  }
  // Output that the company has been allocated space
  printf("%s allocated: %s\n", name, hall);
  
  // Unlock the monitor and return the start index of
  // the company's allocated space
  pthread_mutex_unlock(&lock);
  return start;
}

// Frees the company's hall spaces
void freeSpace( char const *name, int start, int width ) {
  // Locks the monitor
  pthread_mutex_lock(&lock);
  
  // Sets the indexes of the hall from start to width - 1
  // to free spaces
  for (int i = start; i < start + width; i++) {
    hall[i] = '*';
  }
  
  // Output that the company's space has been freed
  printf("%s freed: %s\n", name, hall);
  
  // Signal to any waiting threads that there
  // is more free space and unlock monitor
  pthread_mutex_unlock(&lock);
  pthread_cond_signal( &space );
}
