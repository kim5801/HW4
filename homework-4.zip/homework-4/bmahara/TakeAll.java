import java.util.Random;

public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  private static class ChefMonitor {
    //initializing boolean variables for all appliances
    private static boolean griddle = true;
    private static boolean mixer = true;
    private static boolean oven = true;
    private static boolean blender = true;
    private static boolean grill = true;
    private static boolean fryer = true;
    private static boolean microwave = true;
    private static boolean coffeeMaker = true;

    //method to acquire appliances when they are free
    private synchronized void mandyAcquire() {
      try {
        while(!(microwave && coffeeMaker)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       microwave = false;
       coffeeMaker = false;
    }

    //method to release appliances 
    private synchronized void mandyRelease() {
      microwave = true;
      coffeeMaker = true;
      notifyAll();
    }
    
    //method to acquire appliances when they are free
    private synchronized void edmundAcquire() {
      try {
        while(!(blender && oven && mixer)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       blender = false;
       oven = false;
       mixer = false;
    }

    private synchronized void edmundRelease() {
      blender = true;
      oven = true;
      mixer = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void napoleanAcquire() {
      try {
        while(!(blender && grill)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       blender = false;
       grill = false;
    }

    private synchronized void napoleanRelease() {
      blender = true;
      grill = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void prudenceAcquire() {
      try {
        while(!(coffeeMaker && microwave && griddle)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       coffeeMaker = false;
       microwave = false;
       griddle = false;
    }

    private synchronized void prudenceRelease() {
      coffeeMaker = true;
      microwave = true;
      griddle = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void kyleAcquire() {
      try {
        while(!(fryer && oven)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       fryer = false;
       oven = false;
       
    }

    private synchronized void kyleRelease() {
      fryer = true;
      oven = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void claireAcquire() {
      try {
        while(!(grill && griddle)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       grill = false;
       griddle = false;
       
    }

    private synchronized void claireRelease() {
      griddle = true;
      grill = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void luciaAcquire() {
      try {
        while(!(griddle && mixer)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       griddle= false;
       mixer = false;
       
    }

    private synchronized void luciaRelease() {
      griddle = true;
      mixer = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void marcosAcquire() {
      try {
        while(!(microwave && fryer && blender)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

       microwave = false;
       fryer = false;
       blender = false;
       
    }

    private synchronized void marcosRelease() {
      microwave = true;
      fryer = true;
      blender = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void roseAcquire() {
      try {
        while(!(fryer && grill)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

      fryer = false;
      grill = false;
       
    }

    private synchronized void roseRelease() {
      fryer = true;
      grill = true;
      notifyAll();
    }

    //method to acquire appliances when they are free
    private synchronized void stephAcquire() {
      try {
        while(!(mixer && coffeeMaker && oven)) wait();
      }
      catch(Exception e) {
        //do nothing
      }

      mixer = false;
      coffeeMaker = false;
      oven = false;
       
    }

    private synchronized void stephRelease() {
      mixer = true;
      coffeeMaker = true;
      oven = true;
      notifyAll();
    }

    
   
  }

  // An object representing the lock on each appliance.
  // Locking the needed objects before cooking prevents two
  // chefs from trying to use the same appliance at the same time.

  private static ChefMonitor monitor = new ChefMonitor();

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {

        monitor.mandyAcquire();
        cook(105);
        monitor.mandyRelease();

        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.edmundAcquire();
        cook(30);
        monitor.edmundRelease();

        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.napoleanAcquire();
        cook(60);
        monitor.napoleanRelease();

        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.prudenceAcquire();
        cook(15);
        monitor.prudenceRelease();

        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.kyleAcquire();
        cook(45);
        monitor.kyleRelease();

        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.claireAcquire();
        cook(15);
        monitor.claireRelease();

        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.luciaAcquire();
        cook(15);
        monitor.luciaRelease();

        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.marcosAcquire();
        cook(60);
        monitor.marcosRelease();

        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.roseAcquire();
        cook(75);
        monitor.roseRelease();

        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        monitor.stephAcquire();
        cook(30);
        monitor.stephRelease();

        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
