#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

//global array that keeps track of each hall's state
char *hallState;

//global variable to keep track of array size
int spaces = 0;
//global variable to keep track of age for that thread
int globalAge = 0;
//checks if age increased
int tracker = 0;

//checks if someone is starving
bool someoneStarving;

//size of array-ages
#define MAX_ALPHABETS 26

//array to keep track of everyone's ages
int ages[MAX_ALPHABETS];

//lock for access to hall states
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the thread, if space isn't available yet.
pthread_cond_t threadBlockCond = PTHREAD_COND_INITIALIZER;


/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    hallState = malloc(sizeof(char) * n);
    spaces = n;

    someoneStarving = false;

    for(int z = 0; z < MAX_ALPHABETS; z++) {
        ages[z] = 0;
    }

    //initially all halls are free
    for(int i = 0; i < n; i++) {
        hallState[i] = '*';
    }

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    //freeing array
    free(hallState);

    //destroy monitor
    pthread_cond_destroy(&threadBlockCond);
    pthread_mutex_destroy(&mon);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

    int personalAge = 0;
    someoneStarving = false;
    
    pthread_mutex_lock(&mon);
    char firstLetter = name[0]; //first letter of organization name
    int start = -1; // starting idx of memory alloced

    int myIdx = firstLetter - 65;

    ages[myIdx] = personalAge;
    

    int available = 0;
    int printedWait = 0;

    RECALC: 
    for(int j = 0; j < spaces; j++) {
        if(hallState[j] == '*') {
            available++;
        }
        else {
            available = 0;
        }
    }

    //searching for thread with age(tb) greater than 100 of age(ta)
    for(int z = 0; z < 26; z++) {
        int x = ages[z];
        if(x - personalAge > 100) {
            someoneStarving = true;
        }
        break;
    }

    

    if(width > available || (someoneStarving) ) { 
        //thread forced to wait to prevent starving and now that has been accomplished
        if(someoneStarving) someoneStarving = false;

        if(globalAge > tracker) {
            personalAge++;
            ages[myIdx] = personalAge;
            tracker = globalAge;
        }
        //no free space
        //creating string that represents hall state in order
        char currAlloc[spaces + 1];
        for(int y = 0; y < spaces; y++) {
            currAlloc[y] = hallState[y];
        }
        currAlloc[spaces] = '\0';
        if(printedWait == 0) {
            printf("%s waiting: %s\n", name, currAlloc);
            printedWait = 1;
        }
        
        pthread_cond_wait(&threadBlockCond, &mon);
        //I was signalled but I'm going back to check if there is actually space for me
        available = 0;
        goto RECALC;
    }

    int h = 0;
    int tempAvail = 0;
    for(h = 0; h < spaces; h++) { //counting free spaces
        if(hallState[h] == '*') {
            tempAvail++;
        }
        else {
            tempAvail = 0;
        }
        if(tempAvail == width) {
            break;
        }
    }

    start = (h + 1) - tempAvail; //getting start idx

    //update hall state
    for(int g = start; g < (start + width); g++) {
        hallState[g] = firstLetter;
    }

    //creating a string that represents hall state
    char updatedAlloc[spaces + 1];
    for(int y = 0; y < spaces; y++) {
        updatedAlloc[y] = hallState[y];
    }
    updatedAlloc[spaces] = '\0';

    printf("%s allocated (%d): %s\n", name, personalAge, updatedAlloc);
    
    pthread_mutex_unlock(&mon);

    globalAge++;
    return start;

}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {

    pthread_mutex_lock(&mon);
    //freeing space
    for(int u = start; u < (start + width); u++) {
        hallState[u] = '*'; //space if free again
    }

    //string rep of hall states after freeing
    char freeAlloc[spaces + 1];
    for(int y = 0; y < spaces; y++) {
        freeAlloc[y] = hallState[y];
    }
    freeAlloc[spaces] = '\0';

    printf("%s freed: %s\n", name, freeAlloc);

    //signal to wake up a thread in case there's free space
    //signal this many times to wake up any threads that are stuck
    for(int y = 0; y < MAX_ALPHABETS; y++)
        pthread_cond_signal(&threadBlockCond);

    pthread_mutex_unlock(&mon);
}