#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>

/*
// Print out an error message and exit
static void fail(char const *message) {
  fprintf(stderr, "%s\n", message);
  exit(1);
}
*/

// Struct representing the monitor
typedef struct monitorStruct {
  // The encapsulated hall in the monitor
  char *hall;
  int len;

  // The largest room span in the hall
  int largest;

  // The number of threads that have returned from allocate
  int count;

  // The oldest thread in the monitor
  int oldest;
} Monitor;

// Global variable representing the monitor
static Monitor *monitor;

// Pthreads mutex for mutual exclusions
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// Condition variable for largest open size
static pthread_cond_t largest = PTHREAD_COND_INITIALIZER;

// Condition variable for threads waiting on the oldest
static pthread_cond_t waiting = PTHREAD_COND_INITIALIZER;

// Print a report for the monitor's current state
void report(char const *name, int age, char *status) {
  // Return if monitor has not been initialized
  if (monitor == NULL) {
    return;
  }

  // Print the name and status
  printf("%s %s", name, status);
  if (age != -1) {
    printf(" (%d)", age);
  }
  printf(": ");

  // Print the status of the hall
  for (int i = 0; i < monitor->len; i++) {
    printf("%c", monitor->hall[i]);
  }
  printf("\n");
}

// Get the largest gap space inside the monitor
int getLargest() {
  int max = 0, maxCount = 0;

  for (int i = 0; i < monitor->len; i++) {
    if (monitor->hall[i] == '*') {
      // If the next index is open, increase the count
      maxCount++;
    } else {
      // Otherwise, reset the count
      maxCount = 0;
    }

    if (maxCount > max) {
      max = maxCount;
    }
  }

  return max;
}

// If the age is 100 less than the oldest age, block
void checkAge(int age) {
  if (age + 100 < monitor->oldest) {
    while (age + 100 < monitor->oldest) {
      pthread_cond_wait(&waiting, &lock);
    }
    pthread_cond_signal(&waiting);
  }
}

/* Monitor implementation */

// Initalize the monitor
void initMonitor(int n) {
  // Malloc variables inside the monitor
  char *hall = (char *) malloc(n * sizeof(char));
  for (int i = 0; i < n; i++) {
    hall[i] = '*';
  }

  // Malloc the monitor
  monitor = (Monitor *) malloc(sizeof(Monitor));
  monitor->hall = hall;
  monitor->len = n;
  monitor->largest = n;
  monitor->count = 0;
  monitor->oldest = 0;
}

// Destroy the monitor by freeing all the variables
void destroyMonitor() {
  free(monitor->hall);
  free(monitor);
}

// Allocate an organization a given amount of space
//  - Waits if no space available
//  - Takes given space if available
//  - Returns left most index of allocated space (-1 on error)
int allocateSpace(char const *name, int width) {
  // Return if the monitor hasn't been created yet
  if (monitor == NULL) {
    return -1;
  }
  bool reported = false;

  // Get the initial age
  int ageOffset = monitor->count, age = 0;

  // Enter the monitor
  pthread_mutex_lock(&lock);

  // Check the base age for the thread
  checkAge(monitor->count - ageOffset);

  // Block until there's a large enough space
  while (monitor->largest < width) {
    if (!reported) {
      report(name, -1, "waiting");
      reported = true;
    }
    pthread_cond_wait(&largest, &lock);

    // Update the threads age
    age = monitor->count - ageOffset;

    // Update the oldest thread's age
    if (age > monitor->oldest) {
      monitor->oldest = age;
    }

    // Check if this thread should block
    checkAge(age);
  }

  // Find the largest gap of open space and allocate it to the organization
  int index, count = 0;
  for (index = 0; index < monitor->len; index++) {
    if (monitor->hall[index] == '*') {
      // If the next index is open, increase the count
      count++;
    } else {
      // Otherwise, reset the count
      count = 0;
    }

    if (count == width) {
      break;
    }
  }

  // Mark the rooms as taken
  for ( ; count > 0; count--) {
    monitor->hall[index--] = name[0];
  }

  // Find the new largest room span
  monitor->largest = getLargest();
  pthread_cond_signal(&largest);

  // Increment the count of threads that have called alloc
  monitor->count++;

  // If this thread is the oldest thread, release the waiting threads
  if (age == monitor->oldest) {
    monitor->oldest = 0;
    pthread_cond_signal(&waiting);
  }

  // Return the left-most index of the newly acquired room
  report(name, age, "allocated");
  pthread_mutex_unlock(&lock);
  return index + 1;
}

// Release the allocated space from the index and size width
//  - Waits if monitor is occupied
void freeSpace(char const *name, int start, int width) {
  // Return if the monitor hasn't been initialized yet
  if (monitor == NULL) {
    return;
  }

  // Mutual exclusion lock
  pthread_mutex_lock(&lock);

  // Release the allocated spaces
  for (int index = 0; index < width; index++) {
    monitor->hall[start + index] = '*';
  }

  monitor->largest = getLargest();
  pthread_cond_signal(&largest);

  // Release the monitor
  report(name, -1, "freed");
  pthread_mutex_unlock(&lock);
}
