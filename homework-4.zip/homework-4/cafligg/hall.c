#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>

char* rooms; //rooms
int room_num; //number of rooms

pthread_mutex_t roomOp; //used to lock in case of operatio on rooms
pthread_cond_t noSpace; //used for waiting for space to free up


void initMonitor( int n ) {
  rooms = (char *) malloc( (n+1) * sizeof(char)); //set rooms to adequate size

  room_num = n; //save the amount of rooms

  for(int i = 0; i < room_num; i++) {
    rooms[i] = '*';
  }

  rooms[n+1] = '\0';

  pthread_mutex_init( &roomOp, NULL ); //setup so we can lock on operations on rooms
  pthread_cond_init( &noSpace, NULL ); 

}


void destroyMonitor() {
  free(rooms); //only dynamically allocated block
}


/*
* private helper method that assigns the rooms to a company
*/
void assignRooms(char name, int start, int end) {
  for(int i = start; i <= end; i++) {
    rooms[i] = name;
  }
}


int allocateSpace( char const *name, int width ) {
  bool waiting = false;

  while(1) {
    if(!waiting) //only lock on first pass because the conditional wait will lock
      pthread_mutex_lock(&roomOp); //because we are checking the list we need to make sure it doesn't change
    
    for(int i = 0; i < room_num; i++) {
      if(rooms[i] == '*') {
        for(int j = i; rooms[j] == '*'; j++) {
          if((j - i) == width-1) { //because these are the indexes we need to check width-1 as j and i are inclusive
            assignRooms(name[0], i, j); //sets the conference hall string
            printf("%s allocated: %s\n", name, rooms);
            pthread_mutex_unlock(&roomOp);
            return i;
          }
        }
      }
    }
    

    if(waiting == false) {
      printf("%s waiting: %s\n", name, rooms);
      waiting = true;
    }

    pthread_cond_wait( &noSpace, &roomOp );  //unlock roomOp, wait for noSpace, lock RoomOp

  }
}


void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock(&roomOp);
  for(int i = 0; i < width; i++) {
    rooms[start+i] = '*';  //reset room
  }
  printf("%s freed: %s\n", name, rooms);
  pthread_mutex_unlock(&roomOp);

  pthread_cond_broadcast( &noSpace );
}

