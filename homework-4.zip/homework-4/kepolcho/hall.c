#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include "hall.h"

/**
 * This program implements the monitor funtions into C
 * @author Kira Polchow (kepolcho@ncsu.edu)
 */

// create the lock used to handle monitors
pthread_mutex_t lock;

// condition variable to signal if it can move forward
pthread_cond_t spaceFreed;

// create conditions for the lock

// have an array that will hold to the 'hall' of threads
char *hall;
int available = 0;
int hallSize = 0;

char *reservationName;

/** 
 * Initialize the monitor as a hall with n spaces that can be 
 * partitioned  off.Also initalize the lock with default settings and necessary
 * conditions.
 */
void initMonitor(int n) {
    //printf("Creating monitor\n");
    // set the initial lock and condition variables to defaul settings
    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&spaceFreed, NULL);
    available = n;
    hallSize = n;
    hall = (char *)calloc(n, sizeof(pthread_t));
    // populate hall as empty
    for (int i = 0; i < n; i++) {
        hall[i] = '*';
    }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    //printf("Destroying monitor\n");
    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&spaceFreed);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace(char const *name, int width) {
    reservationName = (char *)name;
    int ctr = 0;
    
    //printf("Entering main loop\n");
    while (true) {    
        // wait until there might be available spaces
        //printf("Waiting until space available\n");
        pthread_mutex_lock(&lock);
        while (width > available) {
            printf("%s waiting: %s\n", name, hall);
            pthread_cond_wait(&spaceFreed, &lock);
        }

        //printf("Potential spaces available, locking access\n");
        // lock access to the hall
        //pthread_mutex_lock(&lock);
        //printf("mutex locked \n");
        // check if there has been space allocated
        // find open rooms, check if valid size for allocation
        for (int i = 0; i < hallSize; i++) {
            int startVal = i;
            // if *,  it's currently available
            // check if it's a valid starting point
            //printf("Empty space found, checking if continuous spaces\n");
            if (hall[i] == '*') {      
                // reset counter
                ctr = 0;      

                // check if space of width size is correct
                //printf("Accumulating counter...\n");
                while (ctr < width && i + ctr < hallSize && hall[i + ctr] == '*' ) {
                    ctr++;                
                }
                // correct number of consecutive spaces, update hall and
                // available spaces
                //printf("Checking if correct number of spaces\n");
                if (ctr == width) {    
                    available -= width;
                    // update hall   
                    //printf("Updating hall...\n");
                    for (int j = i; j < i + width && j < hallSize; j++) {
                        hall[j] = name[0];
                        // printf("Size: %d, Index: %d, hall[j]: %c\n", hallSize, j, hall[j]);
                    }
                    // print updated hall
                    printf("%s allocated: %s\n", name, hall);
                    // done with accessing hall, unlock it 
                    pthread_mutex_unlock(&lock);  
                    //printf("Start value: %d\n", i - (width - 1));
                    return startVal;
                }                
            }
        }

        pthread_mutex_unlock(&lock);
    }    

    // should never reach this point!
    return 0;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace(char const *name, int start, int width) { 
    // lock access to hall to modify it
    pthread_mutex_lock(&lock);
    for (int i = start; i <= start + width - 1; i++) {
        //printf("i value: %d\n", i);
        hall[i] = '*';    
    }
    // print out organization and the updated hall
    printf("%s freed: %s\n", name, hall);
    // update available spaces
    available += width;
    // unlock access to hall
    pthread_mutex_unlock(&lock);
    // signal there is more space in hall
    pthread_cond_signal(&spaceFreed);
}