#include "hall.h"
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep
#include <stdio.h>

//lock for access to the monitor
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
//condition for when there is not enough space for an organization
pthread_cond_t spaceCond = PTHREAD_COND_INITIALIZER;
char *capacity;
static int len;


void initMonitor(int n) {
    len = n;
    //initializes n spaces of memory
    capacity = (char *) malloc(n * sizeof(char));
    for(int i = 0; i < len; i++) {
        capacity[i] = '*';
    }
}

void destroyMonitor() {
    pthread_cond_destroy(&spaceCond);
    pthread_mutex_destroy(&lock);
}

/**
 * Finds the max number of successive spaces in the capacity array
 * @return int the start index of the free space
 */
int space(int width) {
    int successiveSpaces = 0;
    for (int i = 0; i < len; i++) {
        if (capacity[i] == '*')  {
            successiveSpaces++;
            if (successiveSpaces >= width) {
                return (i - width) + 1;
            }
        }
        else {
            successiveSpaces = 0;
        }
    }
    return -1;
}

int allocateSpace(char const *name, int width) {
    pthread_mutex_lock(&lock);
    if (space(width) == -1) {
        printf("%s waiting: %s\n", name, capacity);
        pthread_cond_wait(&spaceCond, &lock);
    }
    while (space(width) == -1) {
        pthread_cond_wait(&spaceCond, &lock);
    }

    int idx = space(width);
    //use free space
    for(int i = idx; i < idx + width; i++) {
        capacity[i] = name[0];
    }
    printf("%s allocated %s\n", name, capacity);
    pthread_mutex_unlock(&lock);
    return idx;
}

void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock(&lock);
    //free and replace taken memory with *
    for(int i = start; i < start + width; i++) {
        capacity[i] = '*';
    }
    printf("%s freed: %s\n", name, capacity);
    pthread_cond_signal(&spaceCond);
    pthread_mutex_unlock(&lock);
}

