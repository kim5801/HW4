/**
 * hall.c
 * Homework 4 - Problem 2 - CSC 246
 * @author Ian Murray (iwmurray)
 */
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include "hall.h"

/** Size of the array that holds the ages of threads */
#define AGE_CACHE_SIZE 1024

/** Storage for the hall assignments */
char *buffer;

/** Size of the buffer */
size_t buffer_size;

/** Storage for the ages of waiting threads */
int *ages;

/** Lock for accessing hall assignment buffer */
pthread_mutex_t lock;

/** Coondition for blocking for no free slot */
pthread_cond_t cond;


/**
 * Returns the start index if a buffer has a given amount of free space.
 * @param width width too check for
 * @return start index if free space, else -1.
 */
int findFreeSpace( int width ) {
    int consecutiveFreeSpace = 0;
    int startIndex = -1;

    // Loop all spaces looking for a free cavitiy
    for (size_t i = 0; i < buffer_size; i++)
    {
        if(buffer[i] == 0)
            consecutiveFreeSpace++;
        else
            consecutiveFreeSpace = 0;

        // If count break out early
        if(consecutiveFreeSpace >= width) {
            // Set to the starting index of the first free cell
            startIndex = i - width + 1;
            break;
        }
    }

    return startIndex;
}

/**
 * Prints a status string given a name and verb in the following forms,
 * depending on if an age is given is postive or zero.
 * <name> <verb>: <current allocation>
 * <name> <verb> (age): <current allocation>
 * @param name the name to print
 * @param verb the verb to print
 * @param age the age to print
 */
void printStatus( char const *name, char const *verb, int age ) {
    printf("%s %s", name, verb);

    if(age >= 0)
        printf(" (%d): ", age);
    else
        printf(": ");

    // Print allocation
    for (size_t i = 0; i < buffer_size; i++)
    {
        if(buffer[i] == 0)
            printf("*");
        else
            printf("%c", buffer[i]);
    }
    
    printf("\n");
}

/**
 * Returns true if there is any thread who has been waiting much longer (>=100)
 * then this thread.
 * @param ageIndex the index of this thread
 * @return there exists a thread who has been waiting much longer.
 */
bool existsOlderThread( int ageIndex ) {
     for (size_t i = 0; i < AGE_CACHE_SIZE; i++)
        // There is a thread this is:
        // - not us
        // - is allocated
        // - and is more then 100 cycles older then us
        if(i != ageIndex && ages[i] != -1 && ages[i] - ages[ageIndex] >= 100) {
            pthread_cond_signal( &cond ); // Wake up the much older thread
            return true;
        }

    return false;
}

void initMonitor( int n ) {
    // Allocate hall buffer
    buffer = malloc( sizeof(char) * n );
    buffer_size = n;

    // Allocate ages cache
    ages = malloc( sizeof(int) * AGE_CACHE_SIZE );
    for (size_t i = 0; i < AGE_CACHE_SIZE; i++)
        ages[i] = -1;

    // Init pthread mutex/cond
    pthread_mutex_init( &lock, NULL );
    pthread_cond_init( &cond, NULL);
}

void destroyMonitor() {
    free( buffer );
    free( ages );
    buffer_size = 0;
}

int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock( &lock );

    // Assign an waiting age cache value to this thread
    int ageIndex = 0;
    for (; ageIndex < AGE_CACHE_SIZE; ageIndex++)
        if(ages[ageIndex] == -1)
            break;

    ages[ageIndex] = 0;

    // We must wait
    if( findFreeSpace(width) < 0 || existsOlderThread(ageIndex)) {
        printStatus(name, "waiting", -1);

        // Block until free space
        while ( findFreeSpace(width) < 0 || existsOlderThread(ageIndex) )
            pthread_cond_wait( &cond, &lock );
    }

    // Allocate space
    int startAt = findFreeSpace(width);
    for (size_t i = startAt; i < startAt + width; i++)
    {
        buffer[i] = name[0];
    }
    
    printStatus(name, "allocated", ages[ageIndex]);

    // Remove age from waiting age index
    ages[ageIndex] = -1;

    // Age waiting threads
    for (size_t i = 0; i < AGE_CACHE_SIZE; i++)
        if(ages[i] >= 0)
            ages[i]++;

    pthread_mutex_unlock( &lock );
    return startAt;
}

void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &lock );

    // Unallocate space
    for (size_t i = start; i < start + width; i++)
    {
        buffer[i] = 0;
    }

    printStatus(name, "freed", -1);

    pthread_cond_signal( &cond );
    pthread_mutex_unlock( &lock );
}
