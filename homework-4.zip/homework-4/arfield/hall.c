//Hall program that acts as a monitor to reserve space in a hall
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <string.h>
#include <ctype.h>
#include "hall.h"
#include <pthread.h>

//char array that represents the hall
char *hall;

//The width of the Hall, how many slots there are
int hallSize;

//lock for access to hall
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// condition for detecting space changes
pthread_cond_t spaceChange = PTHREAD_COND_INITIALIZER;

/**
 * prints out the current representation of the hall inline and terminates with newline
 */
static void allocationReport() {
  for( int i = 0; i  < hallSize; i++ ) {
    printf( "%c", hall[i] );
  }
  printf("\n");
}

/**
 * Creates new hall with size n
 * Hall is initialized to size n and filled with '*'
 */
void initMonitor( int n ) {
  hallSize = n;
  hall = ( char * ) malloc( hallSize * sizeof(char) );
  memset( hall, '*', hallSize );
}

/**
 * frees the memory used by hall
 */
void destroyMonitor() {
  free( hall );
}

/**
 * attempts to allocate space to name with width
 * 
 */
int allocateSpace( char const *name, int width ) {
  int openSpace = 0;
  int index = 0;
   
  //Loop over hall space until open space is found
  
  pthread_mutex_lock( &mon );
  while ( openSpace < width ) {
    //if we have covered all spaces we need to reset and wait
    if ( index >= hallSize ) {
      index = 0;
      openSpace = 0;
      printf("%s waiting: ", name);
      allocationReport();
      pthread_cond_wait( &spaceChange, &mon );
    }

    //if the space is open add one to open space otherwise reset open space
    
    if ( hall[index] == '*' ) {
      openSpace++;
    } else {
      openSpace = 0;
    }
    
    index++;
  }

  memset( hall + (index - width), name[0], width );
  printf("%s allocated: ", name);
  allocationReport();
  pthread_mutex_unlock( &mon ); 
  
  return index - width;
}

/**
 * sets the hall spaces reserved by name back to '*'
 */
void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock( &mon );
  memset( hall + start, '*', width );
  printf("%s freed: ", name);
  allocationReport();  
  pthread_cond_signal( &spaceChange );
  pthread_mutex_unlock( &mon );
}

