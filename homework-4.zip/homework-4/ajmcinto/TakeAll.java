import java.util.Random;

/**
 * In TakeAll, chefs only acquire their appliances if they can acquire
 * every appliance that they need. 
 * @author Dr. Sturgill, Adam McIntosh
 */
public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  //a lock for checking booleans and setting them
  private static Object checkLock = new Object();

  // booleans for whether each object is in use
  private static boolean griddle = false;
  private static boolean mixer = false;
  private static boolean oven = false;
  private static boolean blender = false;
  private static boolean grill = false;
  private static boolean fryer = false;
  private static boolean microwave = false;
  private static boolean coffeeMaker = false;

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (microwave || coffeeMaker) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          microwave = true;
          coffeeMaker = true;
        }
        cook( 105 );
        //Release the appliances
        synchronized (checkLock) {
          microwave = false;
          coffeeMaker = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (blender || oven || mixer) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          blender = true;
          oven = true;
          mixer = true;
        }
        cook( 30 );
        //Release the appliances
        synchronized (checkLock) {
          blender = false;
          oven = false;
          mixer = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (blender || grill) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          blender = true;
          grill = true;
        }
        cook( 60 );
        //Release the appliances
        synchronized (checkLock) {
          blender = false;
          grill = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (coffeeMaker || microwave || griddle) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          coffeeMaker = true;
          microwave = true;
          griddle = true;
        }
        cook( 15 );
        //Release the appliances
        synchronized (checkLock) {
          coffeeMaker = false;
          microwave = false;
          griddle = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (fryer || oven) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
        }
        cook( 45 );
        //Release the appliances
        synchronized (checkLock) {
          fryer = false;
          oven = false;
          checkLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (grill || griddle) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          grill = true;
          griddle = true;
        }
        cook( 15 );
        //Release the appliances
        synchronized (checkLock) {
          grill = false;
          griddle = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (griddle || mixer) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          griddle = true;
          mixer = true;
        }
        cook( 15 );
        //Release the appliances
        synchronized (checkLock) {
          griddle = false;
          mixer = false;
          checkLock.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (microwave || fryer || blender) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          microwave = true;
          fryer = true;
          blender = true;
        }
        cook( 60 );
        synchronized (checkLock) {
          microwave = false;
          fryer = false;
          blender = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can use its appliances
        synchronized (checkLock) {
          while (fryer || grill) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {
              
            }
          }
          fryer = true;
          grill = true;
        }
        cook( 75 );
        synchronized (checkLock) {
          fryer = false;
          grill = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        //See if the chef can get its appliances
        synchronized (checkLock) {
          while (mixer || coffeeMaker || oven) {
            try {
              checkLock.wait();
            } catch (InterruptedException e) {

            }
          }
          mixer = true;
          coffeeMaker = true;
          oven = true;
        }
        cook( 30 );
        synchronized (checkLock) {
          mixer = false;
          coffeeMaker = false;
          oven = false;
          checkLock.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
