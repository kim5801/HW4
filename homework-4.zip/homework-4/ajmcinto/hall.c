/**
 * @file hall.c
 * Program that implements a monitor for a hall with spaces
 * being shared by organizations. 
 * @author Adam McIntosh
 * 
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <pthread.h>
#include "hall.h"

/** the number of characters in the ASCII table */
#define NUM_CHARACTERS 128

//monitor state
/** lock for access to the monitor */
pthread_mutex_t hallLock;

/** condition for blocking until spaces may become available */
pthread_cond_t spacesCond;

/** the number of spaces */
int length;

/** a pointer to a set of characters representing the spaces */
static char* spaces;

/**
 * Initialize the monitor and allocate heap memory
 * @param n the number of spaces required
 */
void initMonitor( int n ) {

  pthread_mutex_init(&hallLock, NULL);
  pthread_cond_init(&spacesCond, NULL);

  //enter the monitor
  pthread_mutex_lock(&hallLock);

  spaces = (char*) malloc(sizeof(char) * (n + 1));
  //set all spaces to unoccupied
  for (int i = 0; i < n; i++) {
    spaces[i] = '*';
  }
  //null terminate so we can print easily
  spaces[n] = '\0';

  //set the length
  length = n;

  //exit the monitor
  pthread_mutex_unlock(&hallLock);
}

/**
 * Handles a threads request for space in the hall
 * @param name the name of the organization requesting space
 * @param width the width of the space the organization is requesting
 * @return the start index of the space allocated to the organization
 */
int allocateSpace( char const *name, int width ) {
  //the current number of contiguous available spaces
  int contAvailable = 0;
  //the start of our contiguous section of available spaces
  int startIndex = 0;
  //have we found a large enough series of spaces?
  bool found = false;
  //is this the first time we have checked?
  bool first = true;
  //enter the monitor
  pthread_mutex_lock(&hallLock);

  //until we found a space, run this loop
  while (!found) {
    //reset values
    contAvailable = 0;
    startIndex = 0;
    for (int i = 0; i < length; i++) {
      if (!found) {
        // printf("i: %d, name: %s, spaces: %s, cont: %d, start: %d\n", i, name, spaces, contAvailable, startIndex);
        if (contAvailable == 0 && spaces[i] == '*') {
          startIndex = i;
        }
        if (spaces[i] == '*') {
          contAvailable++;
        }
        else {
          contAvailable = 0;
        }
        if (contAvailable == width) {
          found = true;
        }
      }
    }

    //if we didn't find space on this iteration, wait until we are signaled
    if (!found) {
      //if we get here, we did not find an available space
      //print a report if this is the first time we are waiting
      if (first)
        printf("%s waiting: %s\n", name, spaces);
      //block until there may be spaces, give up lock on monitor
      pthread_cond_wait(&spacesCond, &hallLock);
    }
    first = false;
  }

  //fill in the newly allocated spaces
  for (int j = 0; j < width; j++) {
    spaces[startIndex + j] = name[0];
  }

  //print an allocation report
  printf("%s allocated: %s\n", name, spaces);

  //unlock monitor
  pthread_mutex_unlock(&hallLock);

  //return the start index
  return startIndex;
}

/**
 * Gives up the space an organization has been allocated
 * @param name the name of the organization giving up the space
 * @param start the start index of the space being given up 
 * @param width the width of the space being given up
 */
void freeSpace( char const *name, int start, int width ) {
  //enter the monitor
  pthread_mutex_lock(&hallLock);
  //free up spaces from start up to start + width - 1
  for (int i = start; i < start + width; i++) {
    spaces[i] = '*';
  }
  printf("%s freed: %s\n", name, spaces);

  //let other threads know that new spaces are available
  pthread_cond_signal(&spacesCond);

  //exit the monitor
  pthread_mutex_unlock(&hallLock);
}

/**
 * Frees resources used by the monitor
 */
void destroyMonitor() {
  pthread_mutex_destroy(&hallLock);
  pthread_cond_destroy(&spacesCond);
  free(spaces);
}

