#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep
#include <string.h>

#include "hall.h"

#define INIT_SIZE 10

// Lock for monitor
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Thread waiting condition
pthread_cond_t waitForSpace = PTHREAD_COND_INITIALIZER;

static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

typedef struct Hall {
    int empty;
    char *name;
} Hall;

typedef struct HallList {
    int size;
    int amountAbleToAllocate;
    Hall halls[];
} HallList;

static HallList *bigHall;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    bigHall = (HallList *) malloc(sizeof(HallList) + (sizeof(Hall) * n));
    bigHall->size = n;
    bigHall->amountAbleToAllocate = n;
    for(int i = 0; i < n; i++){
        bigHall->halls[i].empty = 0;
        char *emptyName = "empty";
        bigHall->halls[i].name = malloc(strlen(emptyName) + 1);
        strcpy(bigHall->halls[i].name, emptyName);
    }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    for(int i = 0; i < bigHall->size; i++){
        free(bigHall->halls[i].name);
    }
    free(bigHall);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock(&mon);
    int indexStart = 0;
    int waiting = 0;
    while(width > bigHall->amountAbleToAllocate){
        if(waiting == 0){
            printf("%s waiting: ", name);
            for(int i = 0; i < bigHall->size; i++){
                if(bigHall->halls[i].empty == 0){
                    printf("*");
                }
                else{
                    printf("%c", bigHall->halls[i].name[0]);
                }
            }
            printf("\n");
            waiting++;
        }

        pthread_cond_wait(&waitForSpace, &mon);
    }
    for(int i = 0; i < bigHall->size; i++){
        if(bigHall->halls[i].empty == 0){
            int roomsChecked = 0;
            int roomsAvail = 0;
            for(int j = i; j < i + width; j++){
                if(bigHall->halls[j].empty == 0){
                    roomsAvail++;
                }
                roomsChecked++;
            }
            //exits loop sucessfully, found slots
            if(roomsAvail == roomsChecked){
                indexStart = i;
                break;
            }
        }
    }
    for(int i = indexStart; i < indexStart + width; i++){
        if(bigHall->halls[i].empty == 1){
            fail("tried to use occupied room");
        }
        bigHall->halls[i].empty = 1;
        bigHall->halls[i].name = malloc(strlen(name) + 1);
        strcpy(bigHall->halls[i].name, name);

    }
    int newAmountAbleToAllocate = 0;
    int count = 0;
    for(int i = 0; i < bigHall->size; i++){
        if(bigHall->halls[i].empty == 0){
            count++;
            if(count > newAmountAbleToAllocate){
                newAmountAbleToAllocate = count;
            }
        }
        else{
            if(count > newAmountAbleToAllocate){
                newAmountAbleToAllocate = count;
            }
            count = 0;
        }
    }
    bigHall->amountAbleToAllocate = newAmountAbleToAllocate;
    printf("%s allocated: ", name);
    for(int i = 0; i < bigHall->size; i++){
        if(bigHall->halls[i].empty == 0){
            printf("*");
        }
        else{
            printf("%c", bigHall->halls[i].name[0]);
        }
    }
    printf("\n");
    pthread_cond_signal(&waitForSpace);
    pthread_mutex_unlock( &mon );
    return indexStart;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock(&mon);
    for(int i = start; i < start + width; i++){
        bigHall->halls[i].empty = 0;
        free(bigHall->halls[i].name);
        char *emptyName = "empty";
        bigHall->halls[i].name = malloc(strlen(emptyName) + 1);
        strcpy(bigHall->halls[i].name, emptyName);
    }
    int newAmountAbleToAllocate = 0;
    int count = 0;
    for(int i = 0; i < bigHall->size; i++){
        if(bigHall->halls[i].empty == 0){
            count++;
            if(count > newAmountAbleToAllocate){
                newAmountAbleToAllocate = count;
            }
        }
        else{
            if(count > newAmountAbleToAllocate){
                newAmountAbleToAllocate = count;
            }
            count = 0;
        }
    }
    bigHall->amountAbleToAllocate = newAmountAbleToAllocate;
    printf("%s freed: ", name);
    for(int i = 0; i < bigHall->size; i++){
        if(bigHall->halls[i].empty == 0){
            printf("*");
        }
        else{
            printf("%c", bigHall->halls[i].name[0]);
        }
    }
    printf("\n");
    pthread_cond_signal(&waitForSpace);
    pthread_mutex_unlock(&mon);
}

