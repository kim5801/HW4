#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_THREADS 1000000

// variable to hold conference room
char *space;

int length;

// maximum number of spaces to allocate
int maxSpace;

// main lock for mutex
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the consumer, are there some items.
pthread_cond_t spaceCond = PTHREAD_COND_INITIALIZER;

//struct to represent thread information
typedef struct ThreadInfo {
  int id, age;
} ThreadInfo;

//number of completed threads
int allAge = 0;
//id of each thread incremented at start
int idThread = 0;
//number of active threads
int numThreads = 0;
//array to keep thread information
ThreadInfo threads[MAX_THREADS];

void initMonitor(int n) {
  
  maxSpace = n;
  length = n;
  space = (char *) malloc((n + 1) * sizeof(char));

  for (int i = 0; i < n; i++) {
    space[i] = '*';
  }

  space[n] = '\0';
}

void destroyMonitor() {

  free(space);
}

int allocateSpace(char const *name, int width) {
  
  //enter monitor
  pthread_mutex_lock(&mon);

  idThread++;
  int id = idThread, myAge = allAge;
  threads[numThreads].id = id;
  threads[numThreads++].age = myAge;

  if (width > maxSpace || (allAge - threads[0].age) - (allAge - myAge) > 100) {
    printf("%s waiting: %s\n", name, space);
  }
  while (width > maxSpace || (allAge - threads[0].age) - (allAge - myAge) > 100) {
    pthread_cond_wait(&spaceCond, &mon);
    pthread_cond_signal(&spaceCond);
  }

  //fill space
  int nr = 0, start = 0;
  for (int i = 0; i < length; i++) {
    if (space[i] == '*') {
      nr++;
    } else {
      nr = 0;
    }
    if (nr == width) {
      start = i - nr + 1;
      break;
    }
  }
  
  //assign to conference
  for (int i = 0; i < nr; i++) {
    space[start + i] = name[0];
  }
  
  //recalculate maxSpace
  nr = 0;
  maxSpace = 0;
  for (int i = 0; i < length; i++) {
    if (space[i] == '*') {
      nr++;
    } else {
      nr = 0;
    }
    if (nr > maxSpace) {
      maxSpace = nr;
    }
  }
  
  //remove thread
  for (int i = 0; i < numThreads; i++) {
    if (threads[i].id == id) {
      for (int j = i; j < numThreads - 1; j++) {
        threads[j].age = threads[j + 1].age;
        threads[j].id = threads[j + 1].id;
      }
      numThreads--;
      break;
    }
  }
  
  printf("%s allocated (%d): %s\n", name, allAge - myAge, space);

  allAge++;
  
  //exit monitor
  pthread_cond_signal(&spaceCond);
  
  pthread_mutex_unlock(&mon);

  return start;
}

void freeSpace(char const *name, int start, int width) {
  
  pthread_mutex_lock(&mon);

  for (int i = 0; i < width; i++) {
    space[start + i] = '*';
  }

  int nr = 0;
  maxSpace = 0;
  for (int i = 0; i < length; i++) {
    if (space[i] == '*') {
      nr++;
    } else {
      nr = 0;
    }
    if (nr > maxSpace) {
      maxSpace = nr;
    }
  }

  printf("%s freed: %s\n", name, space);
  
  //exit monitor
  pthread_cond_signal(&spaceCond);

  pthread_mutex_unlock(&mon);
}

