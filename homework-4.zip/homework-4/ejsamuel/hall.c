#include "hall.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

/**locks for threads*/
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;


/** condition variables for the available and filled spots */
// pthread_cond_t filled;
pthread_cond_t avail;

/** current hall allocation*/
static char *hall;

/**prints the current status of the hall*/
void printHall() {
    char *temp = hall;
     while(*temp != '\0') {
        printf("%c", *temp);
        temp++;
    }
    
}

/**
 * Checks for available slots with the given width. Returns the index that can start at
 * @param check the width that we are checking the availability
 * @return the index to start at our -1 if not found
 
 */
int checkAvail(int check) {
    char *temp = hall;
    int index = -1;
    int availCounter = 0;
    int indexTracker = 0;
    
     while(*temp != '\0') {
        
        if(*temp == '*') {
            if(availCounter == 0) {
                index = indexTracker;
            }
            availCounter++;
        }
        if(*temp != '*') {
            if(availCounter >= check) {
                
                return index;
            }
            availCounter = 0;
            index = -1;
        }
        indexTracker++;
        temp++;
    }
    if(availCounter < check) {            
        return -1;
    }
    return index;
    //returning index even if not enought
    
}
void initMonitor(int n) {
    hall = (char *)malloc(n * sizeof(char));
    for(int i = 0; i < n; i++) {
        hall[i] = '*';
    }
    // pthread_cond_init(&filled, NULL);
    pthread_cond_init(&avail, NULL);

}

void destroyMonitor() {

    // pthread_cond_destroy(&filled);
    pthread_cond_destroy(&avail);

}

int allocateSpace(char const *name, int width) {
   pthread_mutex_lock(&lock);
    int index = -1;
    index = checkAvail(width);
    if(index == -1) {
        printf("%s waiting: ", name);
        printHall();
        printf("\n");
    }
    while((index = checkAvail(width)) == -1) {
        //block until theres a spot available
        pthread_cond_wait(&avail, &lock);
    }

    int temp = index;
    for(int i = 0; i < width; i++) {

        hall[temp] = name[0];
        temp++;
    }  
    printf("%s allocated: ", name);
    printHall();
    printf("\n");
    pthread_mutex_unlock(&lock);
    return index;
}

void freeSpace(char const *name, int start, int width ) {
    pthread_mutex_lock(&lock);
    for(int i = start; i <= (start + width - 1); i++) {
        hall[i] = '*';
    }
    printf("%s freed: ", name);
    printHall();
    printf("\n");
    pthread_cond_signal(&avail);
    pthread_mutex_unlock(&lock);
}

