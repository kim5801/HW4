#include "hall.h"
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>

#define AVAIL '*'

/** Represents lock to controlling access to the monitor */
pthread_mutex_t lock;
pthread_cond_t halt;
// pthread_cond_t ushouldbefine;
// static int rooms;
static char *spaces;
static int *num;
static bool *freed;

void initMonitor(int n) {
    if(pthread_mutex_init(&lock, NULL) != 0) {
        perror("pthread_mutex_init");
        exit(1);
    }
    spaces = (char *) malloc(n * sizeof(char));
    for(int i = 0; i < n; i++)
        spaces[ i ] = AVAIL;
    num = (int *) malloc(sizeof(int));
    *num = n;
    freed = (bool *) malloc(n * sizeof(bool));
}

void destroyMonitor() {
    free(spaces);
    free(num);
    free(freed);
}

/** Helper function which prints the current allocation of the spaces in a hall */
static void report() {
    for(int i = 0; i < *num; i++)
        printf("%c", spaces[i]);
    printf("\n");
}

// static int check(int width) {
//     bool avail = false;
//     int start = 0;
//     pthread_mutex_lock(&lock); //enter monitor
//         for(int i = 0; i < *num; i++) { //check which spaces are available
//             // printf("%s | outer\n", name);
//             if(spaces[i] == AVAIL && (width + i) <= *num) { //if current space is marked as open...
//                 // report();
//                 // printf("%s | inner\n", name);
//                 for(int j = i; j < width + i && j <= *num; j++) { //check the next spaces to see if they're also available
//                     // printf("%s | %d: %c\n", name, j, spaces[j]);
//                     if(spaces[j] == AVAIL)
//                         avail = true; //if subsequent spaces are also open, update flag to indicate
//                     else {
//                         // printf("%s inner idx: %d\n", name, j);
//                         // report();
//                         avail = false; //otherwise, ensure flag is false
//                         // break; //then exit the rest of this inner loop
//                     }
//                 }
//             }
        
//         if(avail) {
//             start = i;
//             pthread_cond_signal(&halt);
//             break;
//         }
//     }
//     return start;
// }

int allocateSpace( char const *name, int width ) {
    bool avail = false;
    int start = 0; //index of the leftmost space assigned to the thread
    char org = name[0]; //get first letter of the provided organization

    pthread_mutex_lock(&lock); //enter monitor
    // check:
    for(int i = 0; i < *num; i++) { //check which spaces are available
        // printf("%s | outer\n", name);
        if(spaces[i] == AVAIL && (width + i) <= *num) { //if current space is marked as open...
            // report();
            // printf("%s | inner\n", name);
            for(int j = i; j < width + i && j <= *num; j++) { //check the next spaces to see if they're also available
                // printf("%s | %d: %c\n", name, j, spaces[j]);
                if(spaces[j] == AVAIL)
                    avail = true; //if subsequent spaces are also open, update flag to indicate
                else {
                    // printf("%s inner idx: %d\n", name, j);
                    // report();
                    avail = false; //otherwise, ensure flag is false
                    // break; //then exit the rest of this inner loop
                }
            }
        }
        
        if(avail) {
            start = i;
            pthread_cond_signal(&halt);
            break;
        }
    }

    if(!avail) { //if not enough space is available, print waiting message
        // if(anothertry) {
            printf("%s waiting: ", name);
            report();
            // anothertry = false;
        // }
        pthread_cond_wait(&halt, &lock);
        for(int i = start; i < width + start) {
            if(!freed[i]) {
                pthread_cond_wait(&halt, &lock);
            }
        }
        // goto check;
        // start = check(width);
    }
    // while(!avail) //make thread wait  
        // pthread_cond_wait(&halt, &lock);
    // printf("%s | %d\n", name, start);
    for(int i = start; i < width + start; i++) {
        spaces[i] = org;
        freed[i] = false;
    }
    printf("%s allocated: ", name); //print allocation message to signal spaces have been allocated
    report();
    
    pthread_mutex_unlock(&lock); //exit monitor    
    return start;
}

void freeSpace( char const *name, int start, int width ) {
    // printf("%s | freeing\n", name);
    pthread_mutex_lock(&lock); //enter monitor
    for(int i = start; i < start + width; i++)
        spaces[i] = AVAIL;
    printf("%s freed: ", name);
    report();
    pthread_cond_signal(&halt);
    pthread_mutex_unlock(&lock); //exit monitor 
}