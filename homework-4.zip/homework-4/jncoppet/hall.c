#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>
#include "hall.h"

static pthread_mutex_t mon;

static pthread_cond_t cond;

static char *hall;

static int capacity;

static int numUsers;

static bool starved;

struct ThreadStruct {
    pthread_t id;
    int age;
    bool waiting;
    int space;
} typedef User;

static User *users;

// General-purpose fail function.  Print a message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

void printHall() {
    for(int i = 0; i < 10; i++) {
		    printf( "%c", hall[i] );
		}
	  printf("\n");
}

int getContiguousSum() {
    int current = 0;
    int contiguous = 0;
    for(int i = 0; i < capacity; i++) {
		    if(hall[i] == '*') {
				    current++;
				} else {
				    if(current > contiguous) {
						    contiguous = current;
						}
 				    current = 0;
				}
		}
	  if( current > contiguous ) {
		    contiguous = current;
		}
    return contiguous;
}

int getContiguousIndex(int size) {
    if( getContiguousSum() < size ) {
		    fail("No starting index with contiguous sum of <size> \n");
		}
	  int index = 0;
	  int sum = 0;
    bool flag = false;
   
    for(int i = 0; i < capacity; i++) {
		    if( hall[i] == '*') {
		        if( !flag ) {
						    index = i;
					      flag = true;
						}
				    sum++;
			      if( sum == size ) {
						    return index;
						}
				} else {
				    flag = false;
				}
		}
	  return index;
}

void initMonitor( int n ) {
    pthread_cond_init( &cond, NULL);
    pthread_mutex_init( &mon, NULL);
    hall = (char *)malloc( sizeof(char) * n );  
    
    for(int i = 0; i < n; i++) {
        hall[i] = '*';
		}
    capacity = n;
    users = (User *)malloc(sizeof(User) * n);
    numUsers = 0;
    starved = false;
}

void destroyMonitor() {
    free(hall);
}

// Updates the age of a thread
void updateAge( pthread_t id ) {
    bool changed = false;
    for(int i = 0; i < numUsers; i++) {
		    if( users[i].id != id && users[i].waiting ) {
				    users[i].age = users[i].age + 1;
				    if( users[i].age > 100 ) {
						    starved = true;
 		 	          changed = true;
						}
				}
		}
	  if( !changed ) {
		    starved = false;
		}
}

// Reverses whatever waiting previously was to its opposite
void updateWaiting( pthread_t id ) {
    for(int i = 0; i < numUsers; i++) {
		    if( users[i].id == id ) {
				    if( users[i].waiting == false ) {
						    users[i].waiting = true;
						} else {
						    users[i].waiting = false;
						}
				}
		}
}

void initializeUser(pthread_t id, int space) {
    bool exists = false;
    for(int i = 0; i < numUsers; i++) {
		    if( id == users[i].id ) {
				    exists = true; // Used to determine whether the size needs to be changed
	 		      users[i].age = 0; // Resets age to 0
	          users[i].waiting = false; // Resets waiting to false
				}
		}
	  if( !exists ) {
		    if( numUsers + 1 >= capacity ) {
				    users = (User *)realloc( users, numUsers * 2 );
				}  
				users[numUsers].id = id;
	 		  users[numUsers].age = 0;
		    users[numUsers].waiting = false;
		    users[numUsers].space = space;
		    numUsers++;
		} 
} 

int getUserAge(pthread_t id) {
    for(int i = 0; i < numUsers; i++) {
		    if( users[i].id == id ) {
				    return users[i].age; // Finds matching thread IDs and return its age
				}
		}
	  return -1; // Returns -1 if there is an error
}

bool starvation( pthread_t id, int age ) {
    if( !starved ) {
		    return false;
		}
    for(int i = 0; i < numUsers; i++) {
		    if( (users[i].age - age) >= 100) {
            //printf("======================= user[i] age = %d ===== space = %d ===============================\n", users[i].age, users[i].space);
            pthread_cond_signal( &cond );
				    return true;
				}
		}
	  starved = false;
	  return false;
}

int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock( &mon ); 
    //initializeUser( pthread_self(), width ); // Initializes the thread if it is new, nothing if it already exists
    
    if(width > capacity) {
		    fail("Requested more rooms than exist.\n"); // Error if a thread requests more room than possible
		}
		 
	  bool reportFlag = false;
    while( getContiguousSum() < width || starvation( pthread_self(), getUserAge( pthread_self() ))) {
        if( !reportFlag ) {
           // updateWaiting( pthread_self() );
            printf("%s waiting: ", name);
            printHall();
            //printf("|||||||||| AGE = %d WIDTH = %d ||||||||||\n", getUserAge( pthread_self() ), width );
            reportFlag = true;
				}
        pthread_cond_wait( &cond, &mon );
        //printf(">>>>>>>> after wait age: %d >>>> starved %d\n", getUserAge( pthread_self() ), starved);
		}
	  int index = getContiguousIndex(width);
		  
	  for(int i = 0; i < width; i++) {
		    hall[index + i] = name[0];
		}
		 
	 // updateWaiting( pthread_self() ); // Change threads's struct to no longer be waiting
	  //updateAge( pthread_self() ); // Update the age of all the waiitng threads
		  
	  printf("%s allocated (%u): ", name, getUserAge( pthread_self() )); 
    printHall();
	  pthread_mutex_unlock( &mon );
    return index;
}

void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &mon );
    
    // Error checking with parameters
    if( start < 0 || start > capacity ) {
		    fail("freeSpace: invalid starting index\n");
		} else if( width < 0 || width > capacity ) {
		    fail("freeSpace: invalid width\n");
		}
    for(int i = 0; i < width; i++) {
		    hall[start + i] = '*'; // Fixes the current state of the hall
		}
	  printf("%s freed: ", name);
    printHall();
    
    pthread_cond_signal( &cond ); // Signals that a sleeping thread might now have space
    pthread_mutex_unlock( &mon );
}

//int main( int argc, char *argv[] ) {
    //initMonitor(10);
    //printHall();
    //allocateSpace("B", 5);
    //allocateSpace("C", 5);
    //freeSpace("B", 0, 5);
    //allocateSpace("A", 3);
    //freeSpace("C", 5, 5);
    //return 0;
//}