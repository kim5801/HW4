

/**
   @file hall.c
   @author Kush S Faldu (ksfaldu)
   This program provides the functionality for the monitor that is used by the drivers. It's purpose is
   to initialize and destroy the monitor. Furthermore, it also allocates space for the hall and frees it 
   up when it is done using it. 
   
*/


#include <pthread.h>
#include "hall.h"
// mutex lock
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;



/** condition variable */
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;


/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ){
  pthread_mutex_lock( &mon ); // Enter the monitor

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor(){
  pthread_mutex_unlock( &mon ); // Leave the monitor
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ){
  
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ){
  
}

