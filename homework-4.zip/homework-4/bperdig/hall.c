#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>

#define MIN_SIZE 10

/** The monitor that controls the synchronization of the program. */
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

/** Condition variable to make other threads wait when necessary. */
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

/** Array that represents the hall */
char *hall;

/** The age of the organization that has sat in the waiting queue for longest */
int oldest = 0;

/** Initial size for the arrays that store the information about the organizations */
int size = MIN_SIZE;

/** Variable to help resizing the array, stores the previous size of the arrays */
int n = 0;

/** The array of ages of the threads */
int *ages;

/** The array of organization initials. */
char *names;

/** An array indicating which thread can be aged and which can't */
bool *activeThreads;

void initMonitor(int n) {
    hall = (char*) malloc(n * sizeof(char));
    // Fills the array with asterisks, representing an empty slot.
    for (int i = 0; i < n; i++)
        hall[i] = '*';

    ages = (int*) calloc(size, sizeof(int));

    activeThreads = (bool*) malloc (size * sizeof(bool));

    names = (char*) malloc(size * sizeof(char));

    // Initially there are no organizations asking for space, and no organization has asked previously.
    // The * represents an open slot in the organization names array.
    for (int i = 0; i < size; i++) {
        activeThreads[i] = false;
        names[i] = '*';
    }
}

void destroyMonitor() {
    free(hall);
    free(activeThreads);
    free(ages);
    free(names);

    if (pthread_cond_destroy(&cond) != 0 || pthread_mutex_destroy(&mon) != 0) {
        fprintf(stderr, "Failed to destroy monitor\n");
        exit(1);
    }
}

/**
 * Method to realloc the ages. Used to avoid getting trash values when reallocating.
 */
static int* reallocateAges(int* ages, int size) {
    int* newAges = (int*) calloc(size * 2, sizeof(int));
    for (int i = 0; i < size; i++) {
        newAges[i] = ages[i];
    }
    free(ages);
    return newAges;
}

int allocateSpace(char const *name, int width) {

    // How many consecutive free spaces are in the hall in one particular interval.
    int consecutiveSpaces = 0;
    // Used to traverse the array that represents the hall.
    int count = 0;
    // Letter indicating what to put in the hall when space is allocated.
    char owner = name[0];
    // Flag to only allow a single waiting print for each thread.
    bool printed = false;
    // Identifies the current organization to properly update information in the arrays.
    int current = 0;

    // Locks the monitor so threads can't check in the hall while it is being modified
    pthread_mutex_lock(&mon);
    for (int i = 0; i < size; i++) {
        // Current organization has already requested space previously, no need to increase the size of the array of threads.
        if (owner == names[i]) {
            activeThreads[i] = true;
            current = i;
            break;
        }
        // There is extra space in the array of threads, create a new spot for this new organization.
        else if (names[i] == '*') {
            names[i] = owner;
            activeThreads[i] = true;
            ages[i] = 0;
            current = i;
            break;
        }
        // Reached the end of the array of threads without finding a suitable spot.
        // Grow the arrays and assign the first new position to the current organization.
        else if (i == size - 1) {
            n = size;
            ages = reallocateAges(ages, size * 2);
            activeThreads = (bool*) realloc(activeThreads, size * 2);
            names = (char*) realloc(names, size * 2);
            for (int j = n; j < size * 2; j++) {
                activeThreads[j] = false;
                ages[j] = 0;
                names[j] = '*';
            }
            names[n] = owner;
            activeThreads[n] = true;
            current = n;
            size *= 2;
            break;
        }
    }
    while (consecutiveSpaces != width) {
        for (; count < strlen(hall) && consecutiveSpaces != width; count++) {
            // Increase number of consecutive spaces for each asterisk
            if (hall[count] == '*')
                consecutiveSpaces++;
            // Resets the consecutive spaces count if a letter is found
            else
                consecutiveSpaces = 0;
        }

        // Thread could not find any available spot in the hall, reset counters and have it wait.
        // If space could be found, but the current thread is too young compared to the oldest, make it wait anyway.
        if (consecutiveSpaces != width || ages[current] < oldest - 100) {
            if (!printed) {
                printf("%s waiting: %s\n", name, hall);
                printed = true;
            }
            consecutiveSpaces = 0;
            count = 0;
            pthread_cond_wait(&cond, &mon);
        }
    }

    // Thread managed to find an open slot, allocate space to itself.
    for (int i = 0; i < consecutiveSpaces; i++)
        hall[count - consecutiveSpaces + i] = owner;

    printf("%s allocated (%d): %s\n", name, ages[current], hall);

    // Resets the oldest one if the oldest thread managed to get a spot.
    if (ages[current] == oldest)
        oldest = 0;

    //Resets the status of the current organization.
    activeThreads[current] = false;
    ages[current] = 0;

    // Increases the ages of all other active threads, sets the new oldest thread.
    for (int i = 0; i < size; i++) {
        if (activeThreads[i] == true) {
            ages[i]++;
            if (ages[i] > oldest)
                oldest = ages[i];
        }
    }

    // Unlock the monitor so other threads can carry on checking for space.
    pthread_mutex_unlock(&mon);

    return count - consecutiveSpaces;
}

void freeSpace(char const *name, int start, int width) {
    for (int i = 0; i < width; i++)
        hall[start + i] = '*';

    printf("%s freed: %s\n", name, hall);
    pthread_cond_broadcast(&cond);
}
