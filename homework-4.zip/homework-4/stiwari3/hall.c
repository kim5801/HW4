/**
    @file hall.c
    @author Mitthu Tiwari (stiwari3)
    Implements conference hall allocation system using a monitor
    Implemented with help of Linux man pages (from https://man7.org/linux/man-pages/) as well as monitor code 
    given in lecture 6 slides
*/

#include "hall.h"
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

/** Character representing free space in allocation report */
#define FREE_SPACE '*'

/** Number of spaces in hall */
static int numSpaces = 0;

/** Defines space in hall */
typedef struct {
    char *orgName;
    bool taken;
} HallSpace;

/** Collection of spaces to be allocated in memory */
static HallSpace** spaces;

/** Monitor for implementing conference hall allocation system */
pthread_mutex_t monitor = PTHREAD_MUTEX_INITIALIZER;

/** Condition variable for determining whether or not spaces have been allocated for a given thread */
pthread_cond_t spaceAllocated = PTHREAD_COND_INITIALIZER;

/**
    Initializes monitor
    @param n number of spaces conference hall will have
*/

void initMonitor(int n) {
    numSpaces = n;
    spaces = (HallSpace **) malloc(numSpaces * sizeof(HallSpace *));

    for (int i = 0; i < numSpaces; i++) {
        spaces[i] = (HallSpace *) malloc(sizeof(HallSpace));
    }
}

/**
    Destroys monitor and frees up space allocated in memory
*/

void destroyMonitor() {
    for (int i = 0; i < numSpaces; i++) {
        free(spaces[i]);
    }

    free(spaces);
}

/**
    Allocates spaces to organization with given name
    @param name given name of thread representing organization requesting space
    @param width number of spaces organization needs
    @return index of leftmost space allocated
*/

int allocateSpace(char const *name, int width) {
    int start = 0;
    int freeCount = 0;
    bool found = false;
    char allocationReport[numSpaces + 1];

    pthread_mutex_lock(&monitor);
    
    for (int i = 0; i < numSpaces; i++) {
        if (!found) {
            pthread_cond_wait(&spaceAllocated, &monitor);
            for (int j = i; j < i + width; j++) {
                if (!((*(&spaces[j]))->taken)) {
                    freeCount++;
                    (*(&spaces[j]))->taken = true;
                    (*(&spaces[j]))->orgName = name;
                }
            }

            if (freeCount != width) {
                for (int j = i; j < i + width; j++) {
                    (*(&spaces[j]))->taken = false;
                    (*(&spaces[j]))->orgName = NULL;
                }
            } else {
                found = true;
                pthread_cond_signal(&spaceAllocated);
                start = i;
            }
        }
    }

    if (found) {
        printf("%s allocated: ", name);
    } else {
        printf("%s waiting: ", name);
    }

    for (int i = 0; i < numSpaces; i++) {
        if ((*(&spaces[i]))->taken) {
            allocationReport[i] = (*(&spaces[i]))->orgName[0];
        } else {
            allocationReport[i] = FREE_SPACE;
        }
    }

    printf("%s\n", allocationReport);
    pthread_mutex_unlock(&monitor);
    return start;
}

/**
    Frees space allocated to organization with given name
    @param name name of organization whose space is being freed
    @param start index of leftmost space allocated to given organization
    @param width number of spaces allocated to organization
*/

void freeSpace(char const *name, int start, int width) {
    char allocationReport[numSpaces + 1];
    pthread_mutex_lock(&monitor);

    for (int i = start; i < start + width; i++) {
        (*(&spaces[i]))->taken = false;
        (*(&spaces[i]))->orgName = NULL;
    }

    printf("%s freed: ", name);

    for (int i = 0; i < numSpaces; i++) {
        if ((*(&spaces[i]))->taken) {
            allocationReport[i] = (*(&spaces[i]))->orgName[0];
        } else {
            allocationReport[i] = FREE_SPACE;
        }
    }

    printf("%s\n", allocationReport);
    pthread_mutex_unlock(&monitor);
}
