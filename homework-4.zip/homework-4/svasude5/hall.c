#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>

// Mutex to handle the monitor
static pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition to wake threads when there is a possibility of room
static pthread_cond_t addCond = PTHREAD_COND_INITIALIZER;
// The hall representation
static char** hall;
// The length of the hall
static int num = 0;

/** Initializes all the variables for the monitor*/
void initMonitor( int n ) {
    // Lock the mutex
    pthread_mutex_lock(&mon);
    // Initialize the hall
    hall = (char **) malloc(n * sizeof(char *));
    // Set the state of the hall length
    num = n;
    pthread_mutex_unlock(&mon);
}

/** Destroy the monitor. */
void destroyMonitor() {
    // Lock the mutex
    pthread_mutex_lock(&mon);
    // Free each pointer to the organization name if exists
    for (int i = 0; i < num; i++) {
        if (hall[i] != NULL) {
            free(hall[i]);
        }
    }
    // Free the hall
    free(hall);
    // Unlock the mutex
    pthread_mutex_unlock(&mon);
}

/** Allocate space for the organization in the hall if available. */
int allocateSpace( char const *name, int width ) {
    // Lock the mutex
    pthread_mutex_lock(&mon);
    // Create a string copy of the name in the heap
    char *namecpy = (char *) malloc(strlen(name)+1);
    strcpy(namecpy, name);
    // Flag to indicate if the waiting message is printed or not yet
    bool flag = false;
    // Lowest index of the allocation
    int index = 0;
    // Variable to keep track of the count in the inner for loop
    int count = 0;
    // While true until condition is met
    while (true) {
        // Go through each partition in the hall
        for (int i = 0; i < num; i++) {
            // If not used by an organization, increment count
            if (hall[i] == NULL) {
                if (count == 0) {
                    // set the index to the current i
                    index = i;
                }
                count += 1;
            } else {
                count = 0;
            }
            // If there is enough space, break
            if (count == width) {
                break;
            }
        }
        // If there is enough space, continue
        if (count == width) {
            break;
        } else {
            // Else, wait on condition
            count = 0;
            index = 0;
            // If message hasn't been printed, print the waiting message
            if (!flag) {
                printf("%s waiting: ", name);
                // Print the status of the hall
                for (int i = 0; i < num; i++) {
                    if (hall[i] == NULL) {
                        printf("*");
                    } else {
                        printf("%c", hall[i][0]);
                    }
                } 
            printf("\n");
            // Set flag to true
            flag = true;
            }
            // Wait until a organization frees up their space to check again
            pthread_cond_wait( &addCond, &mon );
        }
    }
    // Set the hall to allocate space for the organization by pointing to the name
    for (int i = index; i < index + width; i++) {
        hall[i] = namecpy;
    }
    // Print allocation message
    printf("%s allocated: ", name);
    // Print status of the hall
    for (int i = 0; i < num; i++) {
        if (hall[i] == NULL) {
            printf("*");
        } else {
            printf("%c", hall[i][0]);
        }
    }
    printf("\n");
    // Unlock the mutex and return the index
    pthread_mutex_unlock(&mon);
    return index;
}

/** Deallocate space for the given organization */
void freeSpace( char const *name, int start, int width ) {
    // Lock mutex
    pthread_mutex_lock(&mon);
    // Variable to hold name pointer to free
    char *namecpy;
    // Loop through and set pointers to null
    for (int i = start; i < start+width; i++) {
        namecpy = hall[i];
        hall[i] = NULL;
    }
    // Free the pointer to the org name
    free(namecpy);
    // Print freed message
    printf("%s freed: ", name);
    // Print the status of the hall
    for (int i = 0; i < num; i++) {
        if (hall[i] == NULL) {
            printf("*");
        } else {
            printf("%c", hall[i][0]);
        }
    }
    printf("\n");
    // Awake all thread waiting on the condition
    pthread_cond_broadcast(&addCond);
    // Unlock mutex
    pthread_mutex_unlock(&mon);
}