/**
 * The hall program allocates space for different organizations (threads)
 * using a POSIX mutex (monitor).
 * @file hall.c
 * @author Isaac Dunn (ijdunn)
 */

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/** The monitor (mutex) declaration */
pthread_mutex_t monitor;
/** The monitor (mutex) condition varaible used to allow organizations to try to allocate space */
pthread_cond_t allocateSpaceLock;
/** The monitor (mutex) condition variable used to allow organizations to free their space */
pthread_cond_t freeSpaceLock;
/** The array of rooms declaration (stored as a string for easy printing) */
static char *hall;
/** A static, global flag used to indicate when a thread is currently trying to allocate space */
static bool allocating;

/** 
 * Initialize the monitor as a hall with n spaces that can be partitioned off
 * @param n  The number of spaces in the hall
 */
void initMonitor( int n ) {
  // Initialize monitor (mutex)
  pthread_mutex_init( &monitor, NULL );
  // Initialize condition variables
  pthread_cond_init( &allocateSpaceLock, NULL );
  pthread_cond_init( &freeSpaceLock, NULL );
  // Dynamically allocate the hall array, (+1 for null terminator)
  hall = (char *)malloc( n + 1 );
  // Initialize the array of rooms
  for( int i = 0; i < n; i++ ) {
    hall[ i ] = '*';
  }
  // Add null terminator for easy printing
  hall[ n ] = '\0';
}

/** 
 * Destroy the monitor, freeing any resources it uses
 */
void destroyMonitor() {
  // Destroy the monitor (mutex)
  pthread_mutex_destroy( &monitor );
  // Destroy the condition variables
  pthread_cond_destroy( &allocateSpaceLock );
  pthread_cond_destroy( &freeSpaceLock );
  // Free the hall array
  free( hall );
}

/**
 * This helper function is used called in allocateSpace to check if there is
 * enough continuous space for an organization wanting to reserve width number of rooms.
 * The function returns the left-most index of the room the organization can have if there is
 * enough room, otherwise, the function returns -1 if there is not enough continuous space.
 * @param width  The number of rooms the organization wants to request
 * @returns firstEmpty  The left-most room an organization can fit in, return -1 if they can't fit
 */
int firstIndexFit( int width ) {
  // The number of spaces in the hall
  int hallLen = strlen( hall );
  // To save location of first empty space, in case we find all the spaces we need
  int firstEmpty = -1;
  // Look for the first empty space
  for ( int i = 0; i < hallLen; i++ ) {
    // Empty spaces are the asterisks
    if ( hall[ i ] == '*' ) {
      // Save our location of where we are at
      firstEmpty = i;
      // Counter for number of spaces to see if we match the width
      int spacesCanAllocate = 0;
      // Try to allocate for the spaces we need
      for ( int j = i; j < hallLen; j++ ) {
        // Next space is empty, increment counter since we can allocate
        if ( hall[ j ] == '*' ) {
          spacesCanAllocate++;
          // If we can fully allocate the space, return the first index we can fit in
          if ( spacesCanAllocate == width ) {
            return firstEmpty;
          }
        } else { // This space is used, we can't use it, leave this loop.
          firstEmpty = -1;
          // Change i because we can't fit in that open space
          i = i + width;
          break;
        }
      }
      // Set firstEmpty back to -1 if we did not have enough spaces when we got out of the loop
      firstEmpty = -1;
    }
  }
  // If no space can be allocated, return the sentinel value (-1)
  return firstEmpty;
}

/** 
 * Called when an organization wants to reserve the given number
 * (width) of contiguous spaces in the hall.  Returns the index of
 * the left-most (lowest-numbered) end of the space allocated to the
 * organization.
 * @param name  The string of the name of the organization
 * @param width  The number of rooms that the organization is requesting
 * @returns firstIdx  The index of the left-most room the organization has
 */
int allocateSpace( char const *name, int width ) {
  
  // Enter the monitor
  pthread_mutex_lock( &monitor );

  // Let's see if we can allocate
  int firstIdx = firstIndexFit( width );

  // We can't allocate yet, let's print that out
  if ( firstIdx == -1 ) {
    printf( "%s waiting: %s\n", name, hall );
    // Continue to loop while we still can't allocate
    while ( firstIdx == -1 ) {
      // Keep checking if we can allocate the space, once a space is freed
      // If we can't allocate now, wait until more space might be available
      pthread_cond_wait( &allocateSpaceLock, &monitor );
      // Try to check if we can allocate now
      firstIdx = firstIndexFit( width );
    }
  }

  // We can allocate now
  // I'm trying to allocate, don't let anyone mess with me
  allocating = true;
  // First letter of org to put into array
  char firstLetter = name[ 0 ];
  // Allocate the organization to the hall
  for ( int i = 0; i < width; i++ ) {
    hall[ firstIdx + i ] = firstLetter;
  }
  // Print out the allocation
  printf( "%s allocated: %s\n", name, hall );
  
  // I'm done allocating, let others have the hall
  allocating = false;

  // Allow other organizations to free their spaces
  pthread_cond_signal( &freeSpaceLock );
  // Leave the monitor
  pthread_mutex_unlock( &monitor );

  // Return the first index
  return firstIdx;
}

/** 
 * Relese the allocated spaces from index start up to (and including)
 * index start + width - 1.
 * @param name  The string of the name of the organization
 * @param start  The left-most room the organization has allocated
 * @param width  The number of rooms that the organization has allocated
 */
void freeSpace( char const *name, int start, int width ) {

  // Enter the monitor
  pthread_mutex_lock( &monitor );

  // Don't try to free while someone is allocating
  while ( allocating ) {
    pthread_cond_wait( &freeSpaceLock, &monitor );
  }

  // Time to leave the space
  for ( int i = 0; i < width; i++ ) {
    hall[ start + i ] = '*';
  }
  // Print out the allocation
  printf( "%s freed: %s\n", name, hall );

  // Send signal to allow other threads to try to allocate
  pthread_cond_signal( &allocateSpaceLock );
  // Leave the monitor
  pthread_mutex_unlock( &monitor );
}
