import java.util.Random;

public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  // An object representing the lock on each appliance.
  // Locking the needed objects before cooking prevents two
  // chefs from trying to use the same appliance at the same time.
  /*
  private static Object griddle = new Object();
  private static Object mixer = new Object();
  private static Object oven = new Object();
  private static Object blender = new Object();
  private static Object grill = new Object();
  private static Object fryer = new Object();
  private static Object microwave = new Object();
  private static Object coffeeMaker = new Object();
  */
  private static Object lock = new Object();
  private static boolean griddle = true;
  private static boolean mixer = true;
  private static boolean oven = true;
  private static boolean blender = true;
  private static boolean grill = true;
  private static boolean fryer = true;
  private static boolean microwave = true;
  private static boolean coffeeMaker = true;

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (microwave && coffeeMaker) {
                microwave = false;
                coffeeMaker = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 105 );
        synchronized(lock) {
            microwave = true;
            coffeeMaker = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
            
        }
        
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (blender && oven && mixer) {
                blender = false;
                oven = false;
                mixer = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 30 );
        synchronized(lock) {
            blender = true;
            oven = true;
            mixer = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }
        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (blender && grill) { 
                blender = false;
                grill = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 60 );
        synchronized(lock) {
                blender = true;
                grill = true;
            
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }
        
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (coffeeMaker && microwave && griddle) {
                coffeeMaker = false;
                microwave = false;
                griddle = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 15 );
        synchronized(lock) {
            coffeeMaker = true;
            microwave = true;
            griddle = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }
        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (fryer && oven) {
                fryer = false;
                oven = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 45 );
        synchronized(lock) {
            fryer = true;
            oven = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }

        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (grill && griddle) {
                grill = false;
                griddle = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 15 );
        synchronized(lock) {
            griddle = true;
            grill = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (griddle && mixer) {
                griddle = false;
                mixer = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 15 );
        synchronized(lock) {
            griddle = true;
            mixer = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }

        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (microwave && fryer && blender) {
                microwave = false;
                fryer = false;
                blender = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 60 );
        synchronized(lock) {
            microwave = true;
            fryer = true;
            blender = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }
        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (fryer && grill) {
                fryer = false;
                grill = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 75 );
        synchronized(lock) {
            fryer = true;
            grill = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }

        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( lock ) {
            if (mixer && coffeeMaker && oven) {
                mixer = false;
                coffeeMaker = false;
                oven = false;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        cook( 30 );
        synchronized(lock) {
            mixer = true;
            coffeeMaker = true;
            oven = true;
            try {
                lock.notifyAll();
            } catch (Exception e) {
                continue;
            }
        }

        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
