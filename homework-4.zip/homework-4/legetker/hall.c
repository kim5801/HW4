#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <semaphore.h>
#include <sys/syscall.h>
#include <unistd.h>


struct Reservation {
    /** Organization name */
    char * organization;

    /** True if the space is free*/
    bool free;
};

typedef struct Reservation Reservation;

/* Mutex lock*/
static pthread_mutex_t lock;


/* Condition variable */
pthread_cond_t cond;

/* List of spaces in the hall*/
static Reservation* hall;

static int totalWidth;

char * currentAllocation() {
    char *rtn = (char*) malloc((totalWidth+1)*sizeof(char));
    rtn[totalWidth] = '\0';
    for (int i = 0; i < totalWidth; i++) {
        if (!(hall[i].free)) {
            rtn[i] = hall[i].organization[0];
        } else {
            rtn[i] = '*';
        }
    }
    return rtn;
}

/* Initializes the monitor
* @param n the width of the hall
*/
void initMonitor(int n) {
    pthread_cond_init( &cond, NULL);
    pthread_mutex_init( &lock, NULL );
    hall = malloc(n * sizeof(Reservation));
    totalWidth = n;
    //Availibility initially set to true
    for (int i = 0; i < totalWidth; i++) {
        hall[i].free = true;
    }
    
}

/* Destroys the monitor after we're done
*/
void destroyMonitor() {
    free(hall);
}
/* Allocates space for the organization
*/
int allocateSpace(char *name, int width) {
    int waitCount = 0;
    pthread_mutex_lock( &lock );
    bool spaceFree = false;
    int i = 0;
    while (!spaceFree) {
        i = 0;
        int freeCount = 0;
        for (i = 0; i < totalWidth - width + 1; i++) {
            for (int j = i; j < width + i; j++) {
                if (hall[j].free) {
                    freeCount++;
                    if (freeCount == width) break;
                }
            }
            if (freeCount == width) break;
            freeCount = 0;
        }
         if (freeCount == width) break;
        waitCount++;
        if (waitCount == 1)
            printf("%s waiting: %s\n", name, currentAllocation());
        pthread_cond_wait( &cond, &lock );
    }
    
    for (int j = i; j < width + i; j++) {
        hall[j].free = false;
        hall[j].organization = name;
    }
    
    printf("%s allocated: %s\n", name, currentAllocation());
    pthread_mutex_unlock( &lock );
    return i;
}

void freeSpace(char const *name, int start, int width) {
    for (int i = start; i < width + start; i++) {
        hall[i].free = true;
    }
    printf("%s freed: %s\n", name, currentAllocation());
    pthread_cond_signal( &cond );
}

