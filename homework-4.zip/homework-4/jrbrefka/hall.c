#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int *buffer;
static char *charBuffer;
static int size;
static int maxSpace;

// Lock for access to the buffer.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking, is there enough continuous space available.
pthread_cond_t spaceCond = PTHREAD_COND_INITIALIZER;

/**
  Gives a report of the hall's state
*/
void allocationReport()
{
  for ( int i = 0; i < size; i++ ) {
    if ( buffer[ i ] ) {
      printf("%c", charBuffer[ i ]);
    } else {
      printf("*");
    }
  }
  printf("\n");
}

/**
  Creates a monitor for n rooms
  @param n for the number of rooms
*/
void initMonitor( int n )
{
  buffer = ( int * ) malloc( n * sizeof( int ) );
  charBuffer = ( char * ) malloc( n * sizeof( char ) );
  size = n;
  maxSpace = n;
  
  //make sure the buffer is initialized to zero
  for ( int i = 0; i < n; i++ ) {
    buffer[ i ] = 0;
  }
}


/**
  Destroys a monitor
*/
void destroyMonitor()
{
  free( buffer );
  free( charBuffer );
}

/**
  Allocates space to an organization
  @param name for the name of the organization
  @param width for the width of the space being allocated
*/
int allocateSpace( char const *name, int width )
{
  int allocated= 0;
  int index = 0;
  pthread_mutex_lock( &mon );
  while( !allocated ) {
    if ( width <= maxSpace ) {
      //allocate space
      for (int i = 0; i < size; i++) {
        int enoughSpace = 1;
        for (int j = 0; j < width; j++) {
          if ( buffer[ i + j ] ) {
            enoughSpace = 0;
          }
        }
        if ( enoughSpace ) {
          for ( int j = 0; j < width; j++ ) {
            buffer[ i + j ] = 1;
            charBuffer[ i + j ] = name[ 0 ];
          }
          //make sure to not allocate space more than once
          index = i;
          i = size;
          allocated = 1;
        }
      }
    } else {
      printf("%s waiting: ", name);
      allocationReport();
      pthread_cond_wait( &spaceCond, &mon );
    }
  }
  printf("%s allocated: ", name);
  allocationReport();
  
  //update maxSpace
  maxSpace = 0;
  int max = 0;
  for ( int i = 0; i < size; i++ ) {
    if ( buffer[ i ] ) {
      if ( max > maxSpace ) {
        maxSpace = max;
      }
      max = 0;
    } else {
      max++;
    }
  }
  if ( max > maxSpace ) {
    maxSpace = max;
  }
  
  pthread_mutex_unlock( &mon );
  return index;
}

/**
  Frees the specified space
  @param name the name of the organization
  @param start start index of the space to be freed
  @param width the width of the space being freed
*/
void freeSpace( char const *name, int start, int width )
{
  pthread_mutex_lock( &mon );
  for ( int i = 0; i < width; i++ ) {
    buffer[ i + start ] = 0;
    charBuffer[ i + start ] = '\0';
  }
  
  //update maxSpace
  maxSpace = 0;
  int max = 0;
  for ( int i = 0; i < size; i++ ) {
    if ( buffer[ i ] ) {
      if ( max > maxSpace ) {
        maxSpace = max;
      }
      max = 0;
    } else {
      max++;
    }
  }
  if ( max > maxSpace ) {
    maxSpace = max;
  }
  
  printf("%s freed: ", name);
  allocationReport();
  
  pthread_cond_signal( &spaceCond );
  pthread_mutex_unlock( &mon );
}