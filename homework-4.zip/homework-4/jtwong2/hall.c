#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Lock that only allows one thread to be in the monitor at a time
pthread_mutex_t monitorLock = PTHREAD_MUTEX_INITIALIZER;

// Condition variable that threads requesting rooms wait on if they are unable to immediately recieve space
pthread_cond_t requestSubroom = PTHREAD_COND_INITIALIZER; // TODO: probably split into declaration and init to put it in the initMonitor() function

char *hall;

int hallSize;

// Struct that contains information about threads
typedef struct Threads {
  char *name;
  int age;
  struct Threads *next;
} Threads;

Threads *threads;
int threadCount = 0;

// Retrives the thread from the list of waiting threads
static Threads* getThread(const char *name) {
  Threads* current = threads;
  // Iterate through thread list
  for (int i = 0; i < threadCount; i++) {
    // If the name matches the current thread, then return it
    if (strcmp(name, current->name) == 0) {
      return current;
    }
    current = current->next;
  }

  // Else, the thread does not exist
  return NULL;
}

// Increments all the waiting threads' ages by 1
static void ageAllThreads() {
  Threads* current = threads;
  // For each thread, increase its age by one
  for (int i = 0; i < threadCount; i++) {
    current->age = current->age + 1;
    current = current->next;
  }
}

static void putThread(const char *name) { // Maybe this function should only be called when the thread
//first makes a request, and then we can assume that the thread should be reset to age 0 when this
// function is called, since we can assume that it cannot make two requests before being granted its
// first request
  if (!getThread(name)) { // Thread must not already exist
    // Add thread and init its state
    char *threadName = (char*)malloc(sizeof(char) * strlen(name) + 1);
    strcpy(threadName, name);
    Threads *t = (Threads*)malloc(sizeof(Threads));
    t->age = 0;
    t->name = threadName;
    t->next = threads;

    // Add the newly created thread to the front of the list
    threads = t;
    threadCount++;
  } // Else, the thread already exists, so no need to add it to the list
}

static void removeThread(const char *name) {
  // Special case of the list being empty
  if (!threads) {
    return;
  }

  // Special case of it being the first element in the lsit
  if (strcmp(threads->name, name) == 0) {
    // Delete the thread by freeing its state, and then freeing the thread itself
    free(threads->name);
    Threads *next = threads->next;
    free(threads);
    threads = next;
    threadCount--; // Decrement the thread count
  }

  // Search list for the correct thread
  Threads* current = threads;
  // Iterate through, searching by name for the thread
  for (int i = 1; i < threadCount; i++) {
    if (strcmp(current->next->name, name) == 0) { // If the thread is found, delete it
      // Delete the thread, freeing its memory used
      free(current->next->name);
      Threads *next = current->next->next;
      free(current->next);
      current->next = next;
      threadCount--;
    }
  }
}

// Gets the age of the specified thread
static int getThreadAge(const char *name) {
  return getThread(name)->age;
}

// static void ageThread(const char *name) {
//   Threads *t = getThread(name);
//   t->age = t->age + 1;
// }

// Sets the specified thread's age to 0
static void resetAge(const char *name) {
  Threads *t = getThread(name);
  t->age = 0;
}

// Searches through the list of threads and returns the age of the oldest one
static int getOldestThreadAge() {
  int oldest = 0;
  Threads* current = threads;
  // Iterate through the list
  for (int i = 0; i < threadCount; i++) {
    if (current->age > oldest) { // Search for the oldest thread
      oldest = current->age;
    }

    current = current->next;
  }
  return oldest; // Return the oldest thread age
}

// Creates a monitor with the specified hall size
void initMonitor( int n ) {
  // Create the hall and init its state
  hall = malloc(sizeof(char) * n);
  for (int i = 0; i < n; i++) {
    hall[i] = '*';
  }

  hallSize = n;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  // Free threads list
  Threads *current = threads;
  for (int i = 0; i < threadCount; i++) {
    Threads *next = current->next; // Free resources associated with each thread
    free(current->name);
    free(current);
    current = next;
  }

  // Free the hall itself
  free(hall);

  // Destroy the monitor and condition variable
  pthread_mutex_destroy(&monitorLock);
  pthread_cond_destroy(&requestSubroom);
}

static void printHallOccupancy() {
  for (int i = 0; i < hallSize; i++) {
    printf("%c", hall[i]);
  }
}

// Finds the first space that is at least width wide and return the starting index of that hole. If a hole large enough does not exist, return -1
static int findSpace(int width) {
  int numEmptyInRow = 0;

  for (int i = 0; i < hallSize; i++) {
    if (hall[i] == '*') {
      numEmptyInRow++;

      // Check if the hole is large enough
      if (numEmptyInRow >= width) {
        return i - numEmptyInRow + 1; // -1 because numEmptyInRow is 1-indexed
      }
    } else {
      numEmptyInRow = 0; // Count restarts when the gap ends
    }
  }

  // Else, a gap must not have been found, so return -1 to signify failure
  return -1;
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  pthread_mutex_lock(&monitorLock);
  putThread(name);
  if (findSpace(width) == -1 || getOldestThreadAge() - getThreadAge(name) > 100) { // Executed only once when the thread first tries to reserve space
    printf("%s waiting: ", name);
    printHallOccupancy();
    printf("\n");

    // pthread_cond_wait(&requestSubroom, &monitorLock);
  }
  while (findSpace(width) == -1 || getOldestThreadAge() - getThreadAge(name) > 100) { // TODO: check to make sure this is right
    pthread_cond_wait(&requestSubroom, &monitorLock);
    // ageThread(name);
  }

  int startIdx = findSpace(width);
  if (startIdx != -1) { // If a large enough gap was found
    for (int i = startIdx; i < startIdx + width; i++) {
      hall[i] = name[0]; // First character of the organization's name
    }
  }

  // Print the allocation message
  printf("%s allocated (%d): ", name, getThreadAge(name));
  printHallOccupancy();
  printf("\n");

  // Update the threads
  resetAge(name);
  removeThread(name);
  ageAllThreads();

  // Notify all waiting threads that there might be more space in the monitor
  pthread_cond_broadcast(&requestSubroom);
  pthread_mutex_unlock(&monitorLock);

  return startIdx;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock(&monitorLock);

  // put the subrooms back into the "free spaces" list, merging with neighbors as needed
  for (int i = start; i < start + width; i++) {
    hall[i] = '*';
  }

  printf("%s freed: ", name);
  printHallOccupancy();
  printf("\n");

  pthread_cond_broadcast(&requestSubroom);
  pthread_mutex_unlock(&monitorLock);
}
