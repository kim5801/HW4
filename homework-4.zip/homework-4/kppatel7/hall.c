/**
 * @file hall.c
 * @author Kush Patel kppatel7
 * @brief using monitor to syncronize a representation of a hall with limited spaces
 *        and parties reserving or waiting for a space to open up
 */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hall.h"

/** Mutex lock */
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lock2 = PTHREAD_MUTEX_INITIALIZER;

/** Condition variable for waiting if there is no space currently */
pthread_cond_t condWait;

// hall representation as a string that we can print out as the report
char *hall;

// spaces in hall
int hallSize;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor(int n)
{
    // store size
    hallSize = n;

    hall = malloc(n * sizeof(char) + 1);

    // initialize the hall as empty and initialize condition variable
    for (int i = 0; i < n; i++)
    {
        hall[i] = '*';
    }

    pthread_cond_init(&condWait, NULL);
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
    pthread_cond_destroy(&condWait);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace(char const *name, int width)
{
    bool waitmsgPrinted = false;

    // label representing starting point when a thread is woken up from waiting
start:;

    // make sure no one else can modify hall while we are in it
    pthread_mutex_lock(&lock);

    // count for how many remianing spaces need to be empty to reserve that section of hall
    int count = width;

    // index of the first spot in the hall that the reservation starts at, also return value
    int startingIndex = 0;

    // loop through entire hall
    for (int i = 0; i < hallSize; i++)
    {
        // if the current element is the free space symbol decrement count
        if (hall[i] == '*')
        {
            count--;

            // once count hits zero we know we have enough space for that reservation at this specific spot in hall
            if (count == 0)
            {
                // store the starting point of the space we found thats free
                startingIndex = i - width + 1;

                // get out of the loop
                break;
            }
        }
        // if its not a free space charcter change count back to its max value bc we know there wasent enough concurrent space right now
        else
        {
            count = width;
        }
    }

    // if we are out of the for loop above and count isnt zero, we know we have to wait
    if (count != 0)
    {
        // code to make sure it prints that it is waiting only once
        if (waitmsgPrinted == false)
        {
            printf("%s waiting: %s\n", name, hall);

            // now weve printed once
            waitmsgPrinted = true;
        }

        // wait
        pthread_cond_wait(&condWait, &lock);

        // once we are released temporarily unlock the mutex
        pthread_mutex_unlock(&lock);

        // once we wake up from waiting we have to go back through the for loop and check if there is space again
        goto start;
    }

    // code for changing the hall string to represent which company holds what spots in the hall
    for (int i = startingIndex; i < startingIndex + width; i++)
    {
        pthread_mutex_lock(&lock2);
        hall[i] = name[0];
        pthread_mutex_unlock(&lock2);
    }

    printf("%s allocated: %s\n", name, hall);

    // unlock for other changes to be made
    pthread_mutex_unlock(&lock);

    return startingIndex;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace(char const *name, int start, int width)
{

    // lock monitor so we can change hall
    pthread_mutex_lock(&lock);

    // change the spaces specified back to empty spots
    for (int i = start; i < start + width; i++)
    {
        hall[i] = '*';
    }

    // signal that there is now more space to the threads waiting
    pthread_cond_signal(&condWait);

    printf("%s freed: %s\n", name, hall);

    // unlock hall
    pthread_mutex_unlock(&lock);
}