#include "hall.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

//array representation or rooms
static char *rooms;

//the number of rooms
static int size;

//control access to the monitor
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

//makes threads wait when there is no space for them
static pthread_cond_t wait = PTHREAD_COND_INITIALIZER;

//Finds the first open space >= the width parameter
//returns the starting index of that space
int findOpenSpace(int width){
    //the size of the open space its currently looking at
    int openSpace = 0;
    //the starting index of the open space
    int startingIndex = -1;
    for(int i = 0; i < size; i++){
        //an open space is found
        if(rooms[i] == '*'){
            if(openSpace == 0){
                startingIndex = i;
            }
            openSpace++;
            //if a space big enough is found, retrun the starting index
            if(openSpace == width){
                return startingIndex;
            }
        }
        //reset counters
        else{
            openSpace = 0;
            startingIndex = -1;
        }
    }
    return -1;
}

//prints out the current allocation of rooms with what just happened
//name param shows what company just preformed an action
//status is what action was preformed
void printAllocation(const char * name, const char * status){
    printf("%s %s: ", name, status);
    for(int i = 0; i < size; i++){
        printf("%c", rooms[i]);
    }
    printf("%c", '\n');
}

//sets up memory
void initMonitor(int n){
    size = n;
    //allocate space for array representation of rooms and fill with *
    rooms = (char *)malloc(sizeof(char) * size);
    for(int i = 0; i < size; i++){
        rooms[i] = '*';
    }
}

//freems data in heap
void destroyMonitor(){
    free(rooms);
}

//called when a company wants a set amount of space
//returns starting index of space used
int allocateSpace(char const *name, int width){
    //lock monitor
    pthread_mutex_lock(&lock);
    //find any open space for this company
    int index = findOpenSpace(width);
    //if none is found, make them wait
    if(index == -1){
        printAllocation(name, "waiting");
        while(index == -1){
            pthread_cond_wait(&wait, &lock);
            index = findOpenSpace(width);
        }
    }
    //place orginization
    for(int i = index; i < index + width; i++){
        rooms[i] = name[0];
    }
    printAllocation(name, "allocated");
    pthread_cond_signal(&wait);
    pthread_mutex_unlock(&lock);
    return index;
}

//removes a company's hold on rooms
void freeSpace(char const *name, int start, int width){
    //lock monitor
    pthread_mutex_lock(&lock);
    for(int i = start; i < start + width; i++){
        rooms[i] = '*';
    }
    printAllocation(name, "freed");
    pthread_cond_signal(&wait);
    pthread_mutex_unlock(&lock);
}



