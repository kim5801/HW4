/**
 * @file hall.c
 * @author Drew Cada, aecada2
 * @brief  Meeting Hall monitor. A collection of functions, with an initialization
 *         function to init the state of the whole monitor. 
 * @date 2022-10-27 
 */
#include "hall.h"
#include <limits.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EXIT_FAIL 17

// memory list of the created monitor
static char *memList = NULL;

//the number of threads
int threadCount = 0;

// dynmaically allocated array of all threads' names
static char *names = NULL;

// dynmaically allocated array of all threads' ages
static int *ages = NULL;

// monitor lock threads with
static pthread_mutex_t monitor = PTHREAD_MUTEX_INITIALIZER;

// condition to wait on
static pthread_cond_t wait = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor(int n)
{
    memList = malloc(n + 1);
    memset(memList, '*', n);
    memList[n] = '\0';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
    free(memList);
    free(ages);
    free(names);
}

/**
 * @brief Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization.
 * @param name the name of  the calling thread
 * @param width the width to allocate for
 * @return the index of the lowest-numbered end of the allocated space
 */
int allocateSpace(char const *name, int width)
{

    if (threadCount == 0) { // checks the initial case (if the threadCount is 0) for age checking
        names = malloc(sizeof(char));
        names[0] = name[0];
        ages = malloc(sizeof(int));
        ages[0] = 0;
        threadCount++;
    } else {
        bool newName = true;
        for (size_t i = 0; i < threadCount; i++) {
            if (name[0] == names[i]) {
                newName = false;
                break;
            }
        }
        if (newName) {
            threadCount++;
            // cppcheck-suppress memleakOnRealloc
            names = realloc(names, threadCount * sizeof(char));
            names[threadCount - 1] = name[0];
            // cppcheck-suppress memleakOnRealloc
            ages = realloc(ages, threadCount * sizeof(int));
            ages[threadCount - 1] = 0;
        }
    }

    pthread_mutex_lock(&monitor);
    bool hasWaited = false;
retry:;

    // pthread_mutex_unlock(&monitor);

    for (size_t i = 0; i < threadCount; i++) {
        if (name[0] == names[i]) {
            // printf("DEBUG: age=%d\n", ages[i]);
            for (size_t j = 0; j < threadCount; j++) {
                if (ages[i] + 100 < ages[j]) {
                    ages[i]++;
                    // printf("DEBUG2: age=%d\n", ages[i]);
                    // pthread_mutex_lock(&monitor);
                    pthread_cond_wait(&wait, &monitor);
                    goto retry;
                }
            }
            break;
        }
    }
    // pthread_mutex_lock(&monitor);

    int cnt = 0;

    for (char *ch = memList; *ch; ch++) {
        if (*ch == '*') {
            if (++cnt >= width) {
                memset(ch - width + 1, name[0], width);
                printf("%s allocated: %s\n", name, memList);

                // printf("DEBUG: allocate: start=%ld, width=%d\n",
                //        memList - (ch - width), width + 1);
                for (size_t i = 0; i < threadCount; i++) {
                    if (name[0] == names[i]) {
                        // printf("DEBUG3: age=%d\n", ages[i]);
                        ages[i] = 0;

                    } else {
                        // printf("DEBUG4: name[0]=%c ,names[%zu]=%c\n", name[0],
                        //        i, names[i]);
                    }
                }

                // printf("DEBUG5: threadCount=%d\n", threadCount);
                pthread_mutex_unlock(&monitor);
                return ch - memList - width + 1;
            }
        } else {
            cnt = 0;
        }
    }
    if (!hasWaited) {
        printf("%s waiting: %s\n", name, memList);
        hasWaited = true;
    }
    for (size_t i = 0; i < threadCount; i++) {
        if (name[0] == names[i]) {
            ages[i]++;
            // printf("DEBUG: age=%d\n", ages[i]);
        }
    }
    pthread_cond_wait(&wait, &monitor);
    goto retry;

    exit(EXIT_FAIL);
}

/**
 * @brief  Relese the allocated spaces from index start up to (and including)
 *         index start + width - 1. 
 * 
 * @param name the name of the calling thread
 * @param start the start of the location to free in the memList
 * @param width the width of the section to free
 */
void freeSpace(char const *name, int start, int width)
{

    pthread_mutex_lock(&monitor);

    memset(memList + start, '*', width);

    // printf("DEBUG: free: start=%d, width=%d\n", start - 1, width);

    printf("%s freed: %s\n", name, memList);
    pthread_cond_broadcast(&wait);

    pthread_mutex_unlock(&monitor);
}
