#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include "hall.h"
#include <pthread.h>

static char *spaces; // array to used to represent free or used
static int size; //the size of the hal

pthread_mutex_t lock; //lock for the monitor
pthread_cond_t cond; //condition variable for the monitor

/**
 * @brief Method that creates the monitor all the state
 * 
 * @param n the number of rooms for the hall
 */
void initMonitor(int n) {
    spaces = (char *) calloc( 1+n, sizeof(char)); //get the memory
    size = n;
    pthread_mutex_init(&lock, NULL); //create the mutex and the condition variable
    pthread_cond_init(&cond, NULL);

    for (int i = 0; i < n; i++) { //set all the halls to be free initially
        spaces[i] = '*';
    }
}

/**
 * @brief Destroys the monitor
 * freeing and destroying things.
 */
void destroyMonitor() {
    free(spaces);
    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&cond);
}

/**
 * @brief Helper method that tells how many spaces are free
 * from the starting index
 * @param start the starting index to check from
 * @return int how many empty halls are there
 */
static int getWidth(int start)
{
    int width = 0;
    for (int i = start; i < size; i++)
    {
        if (spaces[i] == '*') //if it is open, increase counter
        {
            width++;
        }
    }
    return width;
}

/**
 * @brief Sets the halls as used
 * 
 * @param start where to start 
 * @param width how many halls are going to be used
 * @param name the name of the organization using the hall
 */
static void setUsed(int start, int width, const char *name) {
    for (int i = start; i < start + width; i++) {
        spaces[i] = name[0];
    }
}

/**
 * @brief Finds if there is an avaliable space for the organization given
 * how much width it needs, return index it starts at if there is space
 * returns -1 if there is not space.
 * @param width the width the organization needs
 * @return int the start index or error index
 */
static int findAvaliable(int width) {
    int yes = 0;
    for (int i = 0; i < size; i++) {
        if (spaces[i] != '*')
        { // if used already, move on
            continue;
        }

        int length = getWidth(i); //find end of current block
        if (width <= length) { //if can fit, return the index
            yes = i;
            return yes;
        } else {
            i = i + length;
        }
    }
    if (yes == 0) {
        return -1; //if no space is found;
    }
    return yes;
}

/**
 * @brief Allocated space to the organization given the width
 * is the main method within the monitor, waits on condition variable
 * if there is not space
 * @param name the name of the organization that wants space
 * @param width the width wanted
 * @return int the start index allocated
 */
int allocateSpace(char const *name, int width) {
    pthread_mutex_lock(&lock);
    int start = 0;
    int length = 0; //how long the current block it is
    int in = findAvaliable(width);

    if (in == -1) {
        printf("%s waiting: %s\n", name, spaces); // this needs to be at end, needs to check all avaliable spaces
    }
    while (in == -1) //while there is not space 
    {
        pthread_cond_wait(&cond, &lock); //wait and update
        in = findAvaliable(width);
    }
    for (int i = 0; i < size; i++){
        if (spaces[i] != '*') { //if used already, move on
            continue;
        }
        start = i; //get start
        length = getWidth(start); //get avaliable width from current start index

        if (width <= length) { //if size fits
            i = start + length; //skip to the to end of current block
            setUsed(start, width, name); //set the rooms as used
            printf("%s allocated: %s\n", name, spaces);
            break;
        }
    }
    pthread_mutex_unlock(&lock);

    return start;
}

/**
 * @brief Frees the space by the organization that called this
 * also part of monitor
 * 
 * @param name name of the organization
 * @param start the start of index that is reserved for this organization
 * @param width the number of halls reserved for the organization
 */
void freeSpace(char const *name, int start, int width) {
    pthread_mutex_lock(&lock);
    for (int i = start; i < start + width; i++) {
        spaces[i] = '*';
    }
    pthread_mutex_unlock(&lock);
    printf("%s freed: %s\n", name, spaces);
    //release all the condition variables
    pthread_cond_broadcast(&cond);
}