#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include "hall.h"


//State for the monitor goes here, all should be static global
//...

//MUTEX lock
static pthread_mutex_t lock;

//Conditional var
static pthread_cond_t add;
//static pthread_cond_t rem;

//keep up with the state of the monitor
//ex: what parts of the hall are in use
static char *buffer;
static _Bool wait;
//static int avail;
static int size;

/** Helper method used to print out the state of the monitor. */
static void report() {
  for(int i = 0; i < size; i++) { //(sizeof(buffer) / sizeof(char))
    if(buffer[i] == 0){
      printf("*") ;
    } else {
      printf("%c", buffer[i]);
    }
  }
  printf("\n");
}

/** Interface for the Meeting Hall monitor.  If I was programming in
    Java or C++, this would all be wrapped up in a class.  Since we're using
    C, it's just a collection of functions, with an initialization
    function to init the state of the whole monitor. */

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
  pthread_mutex_init(&lock, NULL);
  pthread_cond_init(&add, NULL);
  //pthread_cond_init(&rem, NULL);
  buffer = calloc(n, sizeof(char));
  size = n;
  wait = false;
  //avail = n;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  free(buffer);
  pthread_mutex_destroy(&lock);
  pthread_cond_destroy(&add);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  pthread_mutex_lock(&lock);
  int first = -1;
  int cnt = 0;
  _Bool alreadyWait = false;
  while(true) {
    for(int i = 0; i < size; i++) { //(sizeof(buffer) / sizeof(char))
      if(buffer[i] == 0) {
        if(first == -1) {
          first = i;
        }
        cnt++;
      }
    
      if(cnt == width) {
        //found first fit
        //put letters from first to first + width - 1 in the buffer
        //update state of buffer
        for(int i = first; i < (first + width); i++) {
          buffer[i] = name[0];
        }
        
        //avail = avail - width;
        
        //print the message
        printf(name);
        printf(" allocated: ");
        report();
        
        //unlock the monitor
        pthread_mutex_unlock(&lock);
        
        //return first
        return first;
      }
    
      if(buffer[i] != 0) {
        first = -1;
        cnt = 0;
      }
    }
    first = -1;
    cnt = 0;
    wait = true;
    if(!alreadyWait) {
      printf(name);
      printf(" waiting: ");
      report();
      alreadyWait = true;
    }
    while(wait) {
      pthread_cond_wait(&add, &lock);
    }
  }
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock(&lock);
  
  for(int i = start; i < (start + width); i++) {
    buffer[i] = 0;
  }
  printf(name);
    printf(" freed: ");
  report();
  
  //might want to switch the order of these two will see during testing
  //avail = avail + width;
  //pthread_cond_signal( &add );
  //pthread_cond_broadcast( &add );
  wait = false;
  pthread_mutex_unlock(&lock);
  //wait = false;
  //pthread_cond_broadcast( &add );
  pthread_cond_signal( &add );
}