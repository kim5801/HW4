#include "hall.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define FREE '*'
#define FOUND -120

// mutex for controlling access to montior
pthread_mutex_t lock;
// condition for waiting for allocation
pthread_cond_t allocateWait;

char *hall;
int hallSize;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor(int n)
{
    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&allocateWait, NULL);
    hallSize = n;
    hall = (char *)malloc(hallSize * sizeof(char));
    memset(hall, FREE, sizeof(char) * hallSize);
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
    pthread_cond_destroy(&allocateWait);
    pthread_mutex_destroy(&lock);
    free(hall);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace(char const *name, int width)
{
    int loop = 0;
    while (1)
    {
        int start = 0, end = 0;
        pthread_mutex_lock(&lock);
        // Finds subarray within hall that
        // fits the width specified. If one is found
        // 'end' is set to a sentinel value
        while (end < hallSize)
        {
            char current = hall[end];

            if (current == FREE)
            {
                if (end - start + 1 == width)
                {
                    end = FOUND;
                    break;
                }
            }
            else
            {
                while (start < hallSize && start <= end)
                    start++;
            }

            end++;
        }

        if (end == FOUND)
        {
            // fill in hall with space for name
            memset(hall + start, name[0], sizeof(char) * width);
            printf("%s allocated: %s\n", name, hall);
            pthread_mutex_unlock(&lock);
            return start;
        }

        if (loop == 0)
            printf("%s waiting: %s\n", name, hall);
        pthread_cond_wait(&allocateWait, &lock);
        pthread_mutex_unlock(&lock);
        loop++;
    }
}

/** Re1ese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace(char const *name, int start, int width)
{
    memset(hall + start, FREE, sizeof(char) * width);
    printf("%s freed: %s\n", name, hall);
    pthread_cond_signal(&allocateWait);
}