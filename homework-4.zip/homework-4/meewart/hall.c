#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "hall.h"

// Compile drivers with
// gcc -Wall -std=c99 -D_XOPEN_SOURCE=500 hall.c driver1.c -o driver1 -lpthread

static char **allocationArray; // A dynamically allocated array holding the allocated rooms
static pthread_mutex_t roomMonitor = PTHREAD_MUTEX_INITIALIZER; // Monitor for rooms
static int numRooms; // The number of rooms
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER; // Condition variable

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n )
{
    //roomMonitor = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
    //roomMonitor = PTHREAD_MUTEX_INITIALIZER;
    //cond = PTHREAD_COND_INITIALIZER;

    allocationArray = (char **) malloc(n * sizeof(char *));
    numRooms = n;

    for (int i = 0; i < n; i++) {
        allocationArray[i] = (char *) malloc(2 * sizeof(char));
        strcpy(allocationArray[i], "*");
    }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
    //free(roomMonitor);

    for (int i = 0; i < numRooms; i++) {
        free(allocationArray[i]);
    }

    free(allocationArray);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width )
{
    int freeSpaceFound = 0;
    int start = 0;
    bool enoughSpaceFound = false;

    pthread_mutex_lock(&roomMonitor); // Enter monitor

    while (!enoughSpaceFound) {
        // Reset variables
        freeSpaceFound = 0;
        start = 0;
        enoughSpaceFound = false;

        // For each room, look for space
        for (int i = 0; i < numRooms; i++) {
            if (strcmp(allocationArray[i], "*") == 0) { // If the room is empty, increment freeSpaceFound
                freeSpaceFound++;
                // If enough space is found, break out of the loop
                if (freeSpaceFound >= width) {
                    enoughSpaceFound = true;
                    break;
                }
            }
            else {
                // If the room is not empty, reset the amount of space found
                // Set the start to the next index
                freeSpaceFound = 0;
                start = i + 1;
            }
        }

        // If there's not enough space, wait until some space is freed
        if (!enoughSpaceFound) {
            // Print report
            printf("%s waiting: ", name);
            for (int i = 0; i < numRooms; i++) {
                printf("%s", allocationArray[i]);
            }
            printf("\n");

            pthread_cond_wait(&cond, &roomMonitor);
        }
        // If there is enough space found, put the room name in the room array
        else {
            for (int i = start; i < start + width; i++) {
                // Reallocate with enough space for the name and set to name
                //allocationArray[i] = (char *) realloc(allocationArray[i], strlen(name) + 1);
                //strcpy(allocationArray[i], name);
                allocationArray[i][0] = name[0];
            }

            // Print report
            printf("%s allocated: ", name);
            for (int i = 0; i < numRooms; i++) {
                printf("%s", allocationArray[i]);
            }
            printf("\n");
        }
    }
    
    pthread_mutex_unlock(&roomMonitor); // Leave monitor
    return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width )
{
    pthread_mutex_lock(&roomMonitor); // Enter monitor

    // Reset array indeces
    for(int i = start; i < start + width; i++) {
        //allocationArray[i] = (char *) realloc(allocationArray[i], 2 * sizeof(char));
        //allocationArray[i] = strcpy(allocationArray[i], "*");
        allocationArray[i][0] = '*';
    }

    // Print report
    printf("%s freed: ", name);
    for (int i = 0; i < numRooms; i++) {
        printf("%s", allocationArray[i]);
    }
    printf("\n");

    pthread_cond_signal(&cond); // Signal so that a waiting thread can try to find space
    pthread_mutex_unlock(&roomMonitor); // Leave monitor
}
