#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "hall.h"

/** Monitor for protecting critical sections */
pthread_mutex_t mon;

/** Condition variable for making threads wait */
pthread_cond_t cond;

/** List of spaces in hall with length n */
static char *spaces;

/** Total number of spaces in hall */
static int num_spaces = 0;

/** Size of longest continguous unallocated segment */
static int largestHole = 0;

void initMonitor( int n )
{
  pthread_mutex_init( &mon, NULL ); // Initialize the monitor
  pthread_cond_init( &cond, NULL); // Initialize the condition 

  // Allocate an appropriate number of spaces in memory
  spaces = (char *) malloc( n * sizeof( char ) );

  // Initialize globals with initial values
  largestHole = n;
  num_spaces = n;
  for ( int i = 0; i < n; i++ ) {
    spaces[ i ] = '*';
  }
  
}

void destroyMonitor()
{
  // Free allocated memory
  free( spaces );
}

int allocateSpace( char const *name, int width )
{

  pthread_mutex_lock( &mon ); // Enter the monitor.
  if ( largestHole < width ) {	 // Report if there's not a hole big enough
    printf( "%s waiting: %s\n", name, spaces );
  }
  while ( largestHole < width ) { // Block until there's a hole big enough
    pthread_cond_wait( &cond, &mon );
  }
  largestHole = 0;
  
  int index = 0;
  int start = 0;
  int hole_size = 0;

  // Iterate through spaces variable for 
  // contiguous empty segments
  for ( int i = 0; i < num_spaces; i++ ) {

    if ( spaces[ i ] == '*' ) {
      hole_size++;
    } else {
      hole_size = 0;
      index = i + 1;
    }
    
    if ( hole_size >= width ) { // Found a hole big enough

      // Allocate space in the hall
      for ( int j = index; j <= i; j++ ) {
        spaces[ j ] = name[ 0 ];
      }
      start = index;
      break;
    }
  }

  // Find the new largest hole
  hole_size = 0;
  for ( int i = 0; i < num_spaces; i++ ) {
    if ( spaces[ i ] == '*' ) {
      hole_size++;
    } else {
      hole_size = 0;
    }
    if ( hole_size > largestHole ) {
      largestHole = hole_size;
    }
  }

  // Report 
  printf( "%s allocated: %s\n", name, spaces );

  // Let the next thread get a chance to continue
  pthread_cond_signal( &cond );
  pthread_mutex_unlock( &mon ); // Exit the monitor.

  return start;
}

void freeSpace( char const *name, int start, int width )
{
  
  pthread_mutex_lock( &mon ); // Enter the monitor.

  // Free the spaces
  for ( int i = start; i < start + width; i++ ) {
    spaces[ i ] = '*';
  }

  // Find the new largest hole
  int hole_size = 0;
  for ( int i = 0; i < num_spaces; i++ ) {
    if ( spaces[ i ] == '*' ) {
      hole_size++;
    } else {
      hole_size = 0;
    }
    if ( hole_size > largestHole ) {
      largestHole = hole_size;
    }
  }

  // Report
  printf( "%s freed: %s\n", name, spaces );

  // Let threads check if there's room now
  pthread_cond_signal( &cond );
  pthread_mutex_unlock( &mon ); // Exit the monitor.
}
