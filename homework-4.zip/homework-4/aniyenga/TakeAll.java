import java.util.Random;
import java.util.concurrent.Semaphore;

public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  // An object representing the lock on each appliance.
  // Locking the needed objects before cooking prevents two
  // chefs from trying to use the same appliance at the same time.
//   private static Object griddle = new Object();
//   private static Object mixer = new Object();
//   private static Object oven = new Object();
//   private static Object blender = new Object();
//   private static Object grill = new Object();
//   private static Object fryer = new Object();
//   private static Object microwave = new Object();
//   private static Object coffeeMaker = new Object();

private static boolean griddle = false;
private static boolean mixer = false;
private static boolean oven = false;
private static boolean blender = false;
private static boolean grill = false;
private static boolean fryer = false;
private static boolean microwave = false;
private static boolean coffeeMaker = false;

private static Object mutex = new Object();

private static Semaphore sem = new Semaphore(1);
  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( microwave ) {
//           synchronized ( coffeeMaker ) {
//             cook( 105 );
//           }
//         }
		synchronized(mutex) {
			if(microwave) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
				
			}
			if(coffeeMaker) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			microwave = true;
			coffeeMaker = true;
		}

		cook( 105 );
		synchronized(mutex) {
			microwave = false;
			coffeeMaker = false;
			mutex.notifyAll();
			
			
		}
		

		
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( blender ) {
//           synchronized ( oven ) {
//             synchronized ( mixer ) {
//               cook( 30 );
//             }
//           }
//         }
		synchronized(mutex) {
		if(blender) {
			try {
				mutex.wait();
			} catch(Exception e){
			}
		}
		if(oven) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
		}
		if(mixer) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
		}
		blender = true;
		oven = true;
		mixer = true;
		}
		
		cook( 30 );
		synchronized(mutex) {
			mutex.notifyAll();
			blender = false;
			oven = false;
			mixer = false;
		}

        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( blender ) {
//           synchronized ( grill ) {
//             cook( 60 );
//           }
//         }
		synchronized(mutex) {
			if(blender) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
		
			if(grill) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			blender = true;
			grill = true;
		}

		cook( 60 );

		synchronized(mutex) {
			mutex.notifyAll();
			blender = false;
			grill = false;
		}

        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( coffeeMaker ) {
//           synchronized ( microwave ) {
//             synchronized ( griddle ) {
//               cook( 15 );
//             }
//           }
//         }
		synchronized(mutex) {
			if(coffeeMaker) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(microwave) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(griddle) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			coffeeMaker = true;
			microwave = true;
			griddle = true;
		}

		cook( 15 );

		synchronized(mutex) {
			mutex.notifyAll();
			coffeeMaker = false;
			microwave = false;
			griddle = false;
		}

        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( fryer ) {
//           synchronized ( oven ) {
//             cook( 45 );
//           }
//         }
		synchronized(mutex) {
			if(fryer) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(oven) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			fryer = true;
			oven = true;
		}

		cook( 45 );

		synchronized(mutex) {
			mutex.notifyAll();
			fryer = false;
			oven = false;
		}		

        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( grill ) {
//           synchronized ( griddle ) {
//             cook( 15 );
//           }
//         }
		synchronized(mutex) {
			if(grill) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(griddle) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			grill = true;
			griddle = true;
		}

		cook( 15 );

		synchronized(mutex) {
			mutex.notifyAll();
			grill = false;
			griddle = false;
		}

        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( griddle ) {
//           synchronized ( mixer ) {
//             cook( 15 );
//           }
//         }
		synchronized(mutex) {
			if(griddle) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(mixer) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			griddle = true;
			mixer = true;
		}

		cook( 15 );
		synchronized(mutex) {
			mutex.notifyAll();
			griddle = false;
			mixer = false;
		}


        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( microwave ) {
//           synchronized ( fryer ) {
//             synchronized ( blender ) {
//               cook( 60 );
//             }
//           }
//         }
		synchronized(mutex) {
			if(microwave) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(fryer) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(blender) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			microwave = true;
			fryer = true;
			blender = true;
		}

		cook( 60 );
		synchronized(mutex) {
			mutex.notifyAll();
			microwave = false;
			fryer = false;
			blender = false;
		}


        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( fryer ) {
//           synchronized ( grill ) {
//             
//           }
//         }
		synchronized(mutex) {
			if(fryer) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(grill) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			fryer = true;
			grill = true;
		}

		cook( 75 );
		synchronized(mutex) {
			mutex.notifyAll();
			fryer = false;
			grill = false;
		}


        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
//         synchronized ( mixer ) {
//           synchronized ( coffeeMaker ) {
//             synchronized ( oven ) {
//               cook( 30 );
//             }
//           }
//         }
		synchronized(mutex) {
			if(mixer) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(coffeeMaker) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			if(oven) {
				try {
					mutex.wait();
				} catch(Exception e){
				
				}
			}
			mixer = true;
			coffeeMaker = true;
			oven = true;
		}

        cook( 30 );
		synchronized(mutex) {
			mutex.notifyAll();
			mixer = false;
			coffeeMaker = false;
			oven = false;
		}


        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
