#include <pthread.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


//creating mutex monitor variables
pthread_mutex_t mon;
//creating condition variable
static pthread_cond_t cond;

//static pthread_cond_t next;
//creating string that will be allocated/freed
char *arr;

//bool check;

/**
* initializes the monitor
* @param n width of the hall
*/
void initMonitor(int n) {
	//mon 
	//initialize mutex, condition, and array
	pthread_mutex_init(&mon, NULL);
	pthread_cond_init(&cond, NULL);
	//pthread_cond_init(&next, NULL);
	arr = (char *)malloc(n * sizeof(char));
	for(int i = 0; i < n; i++) {
		arr[i] = '*';
	}

}

/**
* Frees allocated memory such as mutex and
* array of halls
*/
void destroyMonitor() {
	pthread_mutex_destroy(&mon);
	free(arr);
}

/**
* allocates the the array with first letter of the threads name for the amount of width
* @param name, name of the thread
* @param width, space needed for the array
* @return leftmost index of the array that is free
*/
int allocateSpace(char const *name, int width) {
	//printf("asdf");
	//printf("enter monitor allocate\n");
	pthread_mutex_lock(&mon);
	int freeSpace;
	char letter = name[0];
	for(int i = 0; arr[i]; i++) {
		if(arr[i] == '*'){
			freeSpace++;
		}
	}
	
	if(freeSpace < width) {
		
		printf("%s waiting %s\n", name, arr);
		//check = true;
// 		while(freeSpace < width) {
// 			pthread_cond_wait(&cond, &mon);
// 		}
		
		pthread_cond_wait(&cond, &mon);
		
	}
	
// 	while(check) {
// 		// printf("1wait cond allocate\n");
// 		pthread_cond_wait(&cond, &mon);
// 		printf("2wait cond allocate\n");
// 		
// 	}

	//check = false;
	int checkWidth = 0;
	int start = 0;
	for(int i = 0; arr[i]; i++) {
		if(arr[i] == '*') {
			arr[i] = letter;
			checkWidth++;
		}
		if(checkWidth == 1) {
			start = i;
		}
		if(checkWidth == width) {
			break;
		}
	}
// 	printf("signal next alloacte\n");
// 	pthread_cond_signal(&next);
	printf("%s allocated %s\n", name, arr);
	pthread_mutex_unlock(&mon);
	//printf("exit monitor allocate");
	return start;
}

/**
* frees space of the array from the thread that was holding onto it
* @param name, name of the thread
* @param start, start index of where the array should be freed
* @param width, space from the array which should be freed
*/
void freeSpace(char const *name, int start, int width) {
	//printf("asdf\n");
	pthread_mutex_lock(&mon);
// 	while(!check) {
// 		//printf("qwerty\n");
// 		pthread_cond_wait(&next, &mon);
// 	}
	//freeing array by inputting the empty symbol
	for(int i = start; i <= (start + width - 1); i++) {
		arr[i] = '*';
	}
	//check = true;
// 	printf("123456\n");
	//signal other condition variable that it can go through allocateSpace
	pthread_cond_signal(&cond);
// 	printf("gabagool\n");
	pthread_mutex_unlock(&mon);
// 	printf("exit monitor\n");
	printf("%s freed %s\n", name, arr);
}