#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep
#include <stdbool.h>
#include "hall.h"

// Lock for allowing one thread to change hall assignments at a time
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// Condition for if there is a space open
pthread_cond_t spaceCond = PTHREAD_COND_INITIALIZER;

// Condition for if conference hall is full
pthread_cond_t fullCond = PTHREAD_COND_INITIALIZER;

// Monitor to be used
static struct Monitor *currHall = NULL;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {

    // Dynamically allocate hall
    currHall = malloc( sizeof( struct Monitor * ) );
    currHall->space = malloc( n * sizeof( char ) );
    currHall->size = n;
    currHall->avail = n;

    // Set each value to a star. When a room is being used, it will be labeled
    // with the indicated letter.
    for ( int i = 0; i < n; i++ ) {
        currHall->space[i] = '*';
    }

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {

    // Free space array
    free( currHall->space );

    // Free struct
    free( currHall );
    
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

    // Enter monitor
    pthread_mutex_lock( &lock );

    // Only print message once
    bool firstPass = true;

    // Block until there are spots available
    while( currHall->avail < width ) {
        if ( firstPass ) {
            printf( "%s waiting: %s\n", name, currHall->space );
            firstPass = false;
        }
        pthread_cond_wait( &spaceCond, &lock );
    }

    // Find space for organizations to use
    int temp = 0, ret = 0;
    for ( int i = 0; i < currHall->size; i++ ) {
        if ( currHall->space[ i ] == '*' ) {
            temp++;
            if ( temp == width ) {
                ret = (i + 1) - width;
            }
        }
        else {
            temp = 0;
        }
    }

    // Assign organizations
    for ( int i = ret; i < ret + width; i++ ) {
        currHall->space[ i ] = name[ 0 ];
        currHall->avail--;
    }

    // Print out report
    printf( "%s allocated: %s\n", name, currHall->space );

    // Wake up those waiting if the hall was empty
    pthread_cond_signal( &fullCond );
    pthread_mutex_unlock( &lock );

    // Return index of start of conference hall
    return ret;

}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {

    // Enter monitor
    pthread_mutex_lock( &lock );

    // Block until there is a room to free
    while( currHall->avail == currHall->size ) {
        pthread_cond_wait( &fullCond, &lock );
    }

    // Remove specified organization from hall
    for ( int i = start; i < start + width; i++ ) {
        currHall->space[ i ] = '*';
        currHall->avail++;
    }

    // Print out report
    printf( "%s freed: %s\n", name, currHall->space );

    // Wake up those waiting if the hall was empty
    pthread_cond_signal( &spaceCond );
    pthread_mutex_unlock( &lock );
    
}


