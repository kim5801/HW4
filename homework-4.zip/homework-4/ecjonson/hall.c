/**
 * @file hall.c
 * @author Evan Jonson (ecjonson)
 * This is my hall.c program! It runs in conjucture with a driver. The hall is a
 * represention of a hall of organizations. As organizations make reservations in the
 * hall, it is divided into chunks. Organizations use a first-fit policy to find space
 * in the hall. The hall is represented as an array of pointers to Chunks. Internally, the
 * hall chunks form a doubly linked list. If the hall is empty, there is a single chunk at
 * hall[ 0 ]. This strategy guarantees that each reservation request only needs to iterate
 * over each chunk until it finds a hole, as opposed to the entire hall. Iterations reduced
 * even further by keeping track of the index of the first hole. I also implemented an aging
 * strategy to prevent starvation, using a singly linked waitlist. My design has a bit more
 * overhead than the more simple approach of implementing the hall as an array of characters,
 * but it should also be much more efficient, especially as the hall size and/or the number
 * of organizations is increased.
 */

#include "hall.h"

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <stdbool.h>
#include <errno.h>

/**
 * A hall chunk! A node of a doubly linked list. Each
 * chunk represents a division of the hall, this can be
 * organizations and holes. The hall is intended to be an
 * array of pointers to hall chunk pointers, which also
 * from a doubly linked list. It's doubly linked to
 * increase efficiency in freeSpace().
 */
typedef struct HallChunk {
    // this chunks index in the hall
    int index;
    // the size/width of the chunk
    int size;
    // a character that represents the organization or hole
    char org;
    // a pointer to the next chunk or NULL
    struct HallChunk *next;
    // a pointer to the previous chunk or NULL
    struct HallChunk *prev;
} Chunk;

/**
 * A node that represents a reservation request in the hall. The
 * waitlist will be a singly linked list of these nodes.
 */
typedef struct ReservationRequest {
    // the age of this reservation request
    int age;
    // true if this request has been marked as old by another
    bool old;
    // a pointer to the next reservation request
    struct ReservationRequest *next;
} Req;

// the hall! A pointer to a chunk pointer. The hall can be used as an
// array of chunks. Note that some indices in the hall will often be NULL.
// this implementation is designed to efficiently access chunks by index 
// in the doubly linked list.
static Chunk **hall;

// tracks the first index to start checking for holes, used to reduce
// iterations when searching the hall for space.
static int first;

// the waitlist! a linked list of reservation requests.
static Req *waitlist;

// a pointer to the monitor
pthread_mutex_t *mon;

// a pointer to the condition variable responsible for blocking when the hall is full
pthread_cond_t *spaceCond;

// a pointer to the condition variable responsible for blocking when another reservation request is old
pthread_cond_t *ageCond;

/**
 * Dynamic hall report function. Used to print a hall message and the
 * hall itself.
 * @param name The name of the organization printing this message.
 * @param type The message type (eg. allocated, waiting, freed)
 */
static void printHallMsg( char const *name, char const *type ) {
    // print the specific message
    printf( "%s %s: ", name, type );

    // the current chunk
    Chunk *h = hall[ 0 ];

    // print the hall
    while ( h ) {
        // print the org width
        for ( int i = 0; i < h->size; ++i )
            printf( "%c", h->org );

        // get the next chunk
        h = h->next;
    }

    printf( "\n" );
}

void initMonitor( int n ) {
    // initialize the hall, an array of chunk pointers
    hall = (Chunk **)malloc( n * sizeof( Chunk * ) );

    // initialize the first hole index
    first = 0;

    // initialze the head of the linked list of chunks, a chunk the size of the hall
    hall[ 0 ] = (Chunk *)malloc( sizeof( Chunk ) );
    hall[ 0 ]->index = 0;
    hall[ 0 ]->size = n;
    hall[ 0 ]->org = '*';
    hall[ 0 ]->next = NULL;
    hall[ 0 ]->prev = NULL;

    // nobody is waiting yet
    waitlist = NULL;

    // set the rest of the hall to NULL
    for ( int i = 1; i < n; ++i )
        hall[ i ] = NULL;

    // allocate space for the monitor
    mon = (pthread_mutex_t *)malloc( sizeof( pthread_mutex_t ) );

    // initialize the monitor
    if ( pthread_mutex_init( mon, NULL ) )
        perror( "Failed to initialize the monitor." );

    // allocate space for the space condition variable
    spaceCond = (pthread_cond_t *)malloc( sizeof( pthread_cond_t ) );

    // intialize the space condition variable
    if ( pthread_cond_init( spaceCond, NULL ) )
        perror( "Failed to initialize a condition variable." );

    // allocate space for the age condition variable
    ageCond = (pthread_cond_t *)malloc( sizeof( pthread_cond_t ) );

    // intialize the space condition variable
    if ( pthread_cond_init( ageCond, NULL ) )
        perror( "Failed to initialize a condition variable." );
}

void destroyMonitor() {
    // destroy the mutex
    if ( pthread_mutex_destroy( mon ) )
        perror( "Failed to destroy the monitor." );

    // destroy the space condition variable
    if ( pthread_cond_destroy( spaceCond ) )
        perror( "Failed to destroy a condition variable." );

    // destroy the age condition variable
    if ( pthread_cond_destroy( ageCond ) )
        perror( "Failed to destroy a condition variable." );
    
    // free the mutex
    free( mon );

    // free the space condition variable
    free( spaceCond );

    // free the age condition variable
    free( ageCond );

    // free the chunks, there should only be one
    free( hall[ 0 ] );

    // free the hall array
    free( hall );
}

/**
 * Searches the hall for a a hole large enough to fit this reservation request and
 * claims it if possible. Uses a first-fit policy, and divides the hall into new
 * chunks if necessary.
 * @param org The first letter of the organization looking for space in the hall.
 * @param width The size/width of the reservation request.
 * @return The front index of the hole found and claimed (in the hall), or -1 if not found
 */
static int findHole( const char org, const int width ) {

    // start looking for holes at the first hole index
    Chunk *c = hall[ first ];

    // used to update the first hole index
    int count = 0;

    // find a large enough hole
    while ( c ) {
        // hole found!
        if ( c->org == '*' ) {
            // used to update the first hole index
            ++count;

            // i fit in the hole! claim it
            if ( c->size >= width ) {
                // not a perfect fit, divide the subspace
                if ( c->size != width ) {
                    // index of the subspace
                    int sub = c->index + width;

                    // create and initialize a new chunk
                    hall[ sub ] = (Chunk *)malloc( sizeof( Chunk ) );
                    hall[ sub ]->index = sub;
                    hall[ sub ]->size = c->size - width;
                    hall[ sub ]->org = '*';
                    hall[ sub ]->next = c->next;
                    hall[ sub ]->prev = c;

                    // update the previous chunks size and next pointer
                    c->size = width;
                    if ( c->next )
                        c->next->prev = hall[ sub ];
                    c->next = hall[ sub ];

                    // update the first hole index to reduce future iterations
                    if ( count == 1 )
                        first = sub;
                }

                // claim the hole
                c->org = org;

                return c->index;
            }
        }

        // check the next chunk
        c = c->next;
    }

    // wait
    return -1;
}

int allocateSpace( char const *name, int width ) {
    // the index of the chunk found
    int index;

    // makes sure threads only report and add to the waitlist the first time they wait
    bool firstIter = true;

    // allocate and initialize a new reservation request node, for the waitlist
    Req *my = (Req *)malloc( sizeof( Req ) );
    my->age = 0;
    my->old = false;

    // used to traverse the waitlist
    Req *l;
    Req *prev = NULL;

    // enter the monitor
    pthread_mutex_lock( mon );

    // find space, make them wait if no space is available
    while ( true ) {

        // check if there's an old reservation request in the waitlist
        l = waitlist;
        while( l ) {
            // they're old! mark them as old, wake everyone up and wait
            if ( my->age + 100 < l->age ) {
                l->old = true;
                pthread_cond_broadcast( spaceCond );
                pthread_cond_wait( ageCond, mon );
            }

            l = l->next;
        }

        // search for a hole in the hall
        if ( (index = findHole( name[ 0 ], width )) != -1 )
            break;

        // on the first iteration, print waiting message and add myself to the head of the waitlist
        if ( firstIter ) {
            printHallMsg( name, "waiting" );
            firstIter = false;
            my->next = waitlist;
            waitlist = my;
        }

        // wait for more space in the hall
        if ( pthread_cond_wait( spaceCond, mon ) )
            perror( "Failed to wait." );
    }

    // i'm old, wake everyone up who's waiting for me
    if ( my->old )
        pthread_cond_broadcast( ageCond );

    // remove myself from the waitlist and age everyone else still waiting
    l = waitlist;
    while ( l ) {
        // found myself, remove the node and free the resources
        if ( my == l ) {
            if ( prev )
                prev->next = l->next;
            else
                waitlist = waitlist->next;
            l = l->next;
            free( my );
            continue;
        }

        // age this reservation request
        l->age += 1;

        // continue
        prev = l;
        l = l->next;
    }

    // print allocated message
    printHallMsg( name, "allocated" );

    // leave the monitor
    pthread_mutex_unlock( mon );

    return index;
}

/**
 * Merge this hole with the next hole. Assumes
 * that this hole and the next hole exist.
 * @param h The hole to merge with its next hole.
 */
static void mergeHoles( Chunk *h ) {
    Chunk *n = h->next->next;
    h->size += h->next->size;
    hall[ h->next->index ] = NULL;
    free( h->next );
    h->next = n;
    if ( n )
        n->prev = h;
}

void freeSpace( char const *name, int start, int width ) {
    // enter the monitor
    pthread_mutex_lock( mon );

    // make this chunk a hole
    hall[ start ]->org = '*';

    // update the first hole index
    if ( start < first )
        first = start;

    // if the next chunk is a hole, merge and free resources
    if ( hall[ start ]->next && hall[ start ]->next->org == '*' )
        mergeHoles( hall[ start ] );

    // if the previous chunk is a hole, merge and free resources
    if ( hall[ start ]->prev && hall[ start ]->prev->org == '*' )
        mergeHoles( hall[ start ]->prev );

    // print freed message
    printHallMsg( name, "freed" );

    // wake up all threads waiting for the condition variable
    pthread_cond_broadcast( spaceCond );

    // leave the monitor
    pthread_mutex_unlock( mon );
}
