#include "hall.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

static int spaces = 0;//Size of the hall
pthread_mutex_t lock;

char *hall = NULL;//Array of characters representing the hall

pthread_cond_t cnd;//Condition variable to signal the threads

//Traverse the hall and return the starting index of the portion of the hall with enough spaces, or -1 if there is no available space for the given size.
static int findSpace(int size) {
    
    int count = 0;
    int start = 0;
    

    for(int i = 0; i < spaces; i++) {
        if(hall[i] != '*') {
            count = 0;
            start = i+1;
        }
        else{
            count++;
        }
        

        if(count == size) {
            
            return start;
        }
        
    }
    
    return -1;
}

//create the monitor and malloc memory for the hall
void initMonitor( int n ){
    
    spaces = n;

    hall = (char*)malloc(sizeof(char) * n+1);
    for(int i = 0; i < n; i++) {
        hall[i] = '*';
    }
    hall[n] = '\0';

    pthread_cond_init(&cnd, NULL);
    pthread_mutex_init( &lock, NULL );
    
}

//Free the memory for the hall, and destory the condition and monitor variables.
void destroyMonitor() {
    free(hall);
    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&cnd);
}

//Use the monitor to allocate space in the hall when there is space available.
//A thread will block in this function if there is not enough space when it is called.
//A thread will be signaled to check for available space when freeSpace is called.
int allocateSpace( char const *name, int width ) {
    
    pthread_mutex_lock( &lock );
    int ind = findSpace(width);
    if(ind == -1) {
        printf("%s waiting: %s\n", name, hall);
        while((ind = findSpace(width)) == -1){
            pthread_cond_wait(&cnd, &lock);
        }     
    }

    int i = ind;
    int j = 0;
    while(j < width) {
        hall[i] = name[0];
        i++;
        j++;
    }
    printf("%s allocated: %s\n", name, hall);
    
    pthread_mutex_unlock( &lock );
    return ind;
}

//Frees the space in the hall allocated at the given start up to the given width
//Signals a waiting thread to check if there is enough space that they want to allocate.
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &lock );
    
    int i = start;
    int j = 0;
    while(j < width) {
        hall[i] = '*';
        i++;
        j++;
    }
    printf("%s freed: %s\n", name, hall);
    
    pthread_cond_signal(&cnd);
    pthread_mutex_unlock( &lock );
}