import java.util.Random;

public class TakeAll {
    /** To tell all the chefs when they can quit running. */
    private static boolean running = true;

    /**
     * Superclass for all chefs. Contains methods to cook and rest and
     * keeps a record of how many dishes were prepared.
     */
    private static class Chef extends Thread {
        /** Number of dishes prepared by this chef. */
        private int dishCount = 0;

        /** Source of randomness for this chef. */
        private Random rand = new Random();

        /**
         * Called after the chef has locked all the required appliances and is
         * ready to cook for about the given number of milliseconds.
         */
        protected void cook(int duration) {
            System.out.printf("%s is cooking\n", getClass().getSimpleName());
            try {
                // Wait for a while (pretend to be cooking)
                Thread.sleep(rand.nextInt(duration / 2) + duration / 2);
            } catch (InterruptedException e) {
            }
            dishCount++;
        }

        /** Called between dishes, to let the chef rest before cooking another dish. */
        protected void rest(int duration) {
            System.out.printf("%s is resting\n", getClass().getSimpleName());
            try {
                // Wait for a while (pretend to be resting)
                Thread.sleep(rand.nextInt(duration / 2) + duration / 2);
            } catch (InterruptedException e) {
            }
        }
    }

    // An object representing the lock on each appliance.
    // Locking the needed objects before cooking prevents two
    // chefs from trying to use the same appliance at the same time.
    // private volatile boolean griddle = false;
    // private volatile boolean mixer = false;
    // private volatile boolean oven = false;
    // private volatile boolean blender = false;
    // private volatile boolean fryer = false;
    // private volatile boolean grill = false;
    // private volatile boolean coffeeMaker = false;
    // private volatile boolean microwave = false;

    /**
     * array that stores all appliances, each slot represents a corresponding
     * appliance
     * griddle = 0
     * mixer = 1
     * oven = 2
     * blender = 3
     * fryer = 4
     * grill = 5
     * coffeeMaker = 6
     * microwave = 7
     */
    private static boolean arr[] = { false, false, false, false, false, false, false, false };

    /**
     * lock variable
     */
    private static block bloke = new block();

    /**
     * The lock variable block
     */
    private static class block {

        /**
         * checks if appliances 1 and 2 are lockable and locks
         * 
         * @param ob1 appliance 1
         * @param ob2 appliance 2
         */
        protected synchronized void lock(int ob1, int ob2) {
            while (arr[ob1] || arr[ob2]) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            arr[ob1] = true;
            arr[ob2] = true;
            return;
        }

        /**
         * checks if appliances 1, 2, 3 are lockable and locks
         * 
         * @param ob1 appliance 1
         * @param ob2 appliance 2
         * @param ob3 appliance 3
         */
        protected synchronized void lock(int ob1, int ob2, int ob3) {
            while (arr[ob1] || arr[ob2] || arr[ob3]) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            arr[ob1] = true;
            arr[ob2] = true;
            arr[ob3] = true;
            return;
        }

        /**
         * unlocks appliances 1 and 2
         * 
         * @param ob1 appliance 1
         * @param ob2 appliance 2
         */
        protected synchronized void unlock(int ob1, int ob2) {
            arr[ob1] = false;
            arr[ob2] = false;
            notifyAll();
            return;
        }

        /**
         * unlocks appliance 1, 2, and 3
         * 
         * @param ob1 appliance 1
         * @param ob2 appliance 2
         * @param ob3 appliance 3
         */
        protected synchronized void unlock(int ob1, int ob2, int ob3) {
            arr[ob1] = false;
            arr[ob2] = false;
            arr[ob3] = false;
            notifyAll();
            return;
        }
    }

    /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
    private static class Mandy extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (microwave) {
                // synchronized (coffeeMaker) {

                // }
                // }
                bloke.lock(6, 7);
                cook(105);
                bloke.unlock(6, 7);

                rest(25);
            }
        }
    }

    /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
    private static class Edmund extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (blender) {
                // synchronized (oven) {
                // synchronized (mixer) {

                // }
                // }
                // }
                bloke.lock(3, 2, 1);
                cook(30);
                bloke.unlock(3, 2, 1);

                rest(25);
            }
        }
    }

    /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
    private static class Napoleon extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (blender) {
                // synchronized (grill) {
                // cook(60);
                // }
                // }

                bloke.lock(3, 4);
                cook(60);
                bloke.unlock(3, 4);

                rest(25);
            }
        }
    }

    /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
    private static class Prudence extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (coffeeMaker) {
                // synchronized (microwave) {
                // synchronized (griddle) {
                // cook(15);
                // }
                // }
                // }

                bloke.lock(7, 6, 0);
                cook(15);
                bloke.unlock(7, 6, 0);

                rest(25);
            }
        }
    }

    /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
    private static class Kyle extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (fryer) {
                // synchronized (oven) {
                // cook(45);
                // }
                // }

                bloke.lock(5, 2);
                cook(45);
                bloke.unlock(5, 2);

                rest(25);
            }
        }
    }

    /** Claire is a chef needing 15 milliseconds to prepare a dish. */
    private static class Claire extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (grill) {
                // synchronized (griddle) {
                // cook(15);
                // }
                // }

                bloke.lock(4, 0);
                cook(15);
                bloke.unlock(4, 0);

                rest(25);
            }
        }
    }

    /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
    private static class Lucia extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (griddle) {
                // synchronized (mixer) {
                // cook(15);
                // }
                // }

                bloke.lock(0, 1);
                cook(15);
                bloke.unlock(0, 1);

                rest(25);
            }
        }
    }

    /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
    private static class Marcos extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (microwave) {
                // synchronized (fryer) {
                // synchronized (blender) {
                // cook(60);
                // }
                // }
                // }

                bloke.lock(6, 5, 3);
                cook(60);
                bloke.unlock(6, 5, 3);

                rest(25);
            }
        }
    }

    /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
    private static class Roslyn extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (fryer) {
                // synchronized (grill) {
                // cook(75);
                // }
                // }

                bloke.lock(5, 4);
                cook(75);
                bloke.unlock(5, 4);

                rest(25);
            }
        }
    }

    /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
    private static class Stephenie extends Chef {
        public void run() {
            while (running) {
                // Get the appliances this chef uses.
                // synchronized (mixer) {
                // synchronized (coffeeMaker) {
                // synchronized (oven) {
                // cook(30);
                // }
                // }
                // }

                bloke.lock(1, 7, 2);
                cook(30);
                bloke.unlock(1, 7, 2);

                rest(25);
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        // Make a thread for each of our chefs.
        Chef chefList[] = {
                new Mandy(),
                new Edmund(),
                new Napoleon(),
                new Prudence(),
                new Kyle(),
                new Claire(),
                new Lucia(),
                new Marcos(),
                new Roslyn(),
                new Stephenie(),
        };

        // Start running all our chefs.
        for (int i = 0; i < chefList.length; i++)
            chefList[i].start();

        // Let the chefs cook for a while, then ask them to stop.
        Thread.sleep(10000);
        running = false;

        // Wait for all our chefs to finish, and collect up how much
        // cooking was done.
        int total = 0;
        for (int i = 0; i < chefList.length; i++) {
            chefList[i].join();
            System.out.printf("%s cooked %d dishes\n",
                    chefList[i].getClass().getSimpleName(),
                    chefList[i].dishCount);
            total += chefList[i].dishCount;
        }
        System.out.printf("Total dishes cooked: %d\n", total);
    }
}
