/**
 * Hall is a monitor for a segmented room that can be rented to different
 * groups.
 * @file hall.c
 * @author Zach Taylor (zstaylor)
 */
#include <pthread.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#include "hall.h"

/** Representation of the hall */
static char* hall;
/** Number of segments in the hall */
static int hallLength;
/** Mutex for accessing the Hall */
static pthread_mutex_t hallAccess = PTHREAD_MUTEX_INITIALIZER;
/** Condition to wait for more space to become available */
static pthread_cond_t notifier = PTHREAD_COND_INITIALIZER;

void initMonitor( int n ) {

    pthread_mutex_lock(&hallAccess);

    //create and initialize hall array
    hall = (char*)malloc(sizeof(char) * n);

    for(int i = 0; i < n; i++) {
        hall[i] = '*';
    }

    hallLength = n;
    pthread_mutex_unlock(&hallAccess);
}

void destroyMonitor () {

    pthread_mutex_lock(&hallAccess);

    pthread_cond_destroy(&notifier);
    free(hall);

    pthread_mutex_unlock(&hallAccess);
    pthread_mutex_destroy(&hallAccess);
}

/**
 * Helper method to get the hall as an allocation report string
 * @return Allocation report
 */
char* allocationReport() {

    char* report = (char*)malloc((sizeof(char) * hallLength) + 1);

    for(int i = 0; i < hallLength; i++) {
        report[i] = hall[i];
    }

    report[hallLength+1] = '\0';
    return report;
}

int allocateSpace( char const *name, int width) {

    pthread_mutex_lock(&hallAccess);
    bool wasWaiting = false;

    while(true) {

        int idxFound = -1;

        int freecount = 0;
        int freestart = 0;
        bool counting = false;
        for(int i = 0; i < hallLength; i++) {

            //if we encounter an empty segment
            if(hall[i] == '*') {

                //adjacent to an occupied segment
                if(!counting)  {

                    //start counting!
                    freestart = i;
                    counting = true;
                }

                //count this free segment
                freecount += 1;

                //check if we have enough segments for the requester
                if(freecount == width) {
                    idxFound = freestart;
                    break;
                }
            }
            else { //we encounter an occupied segment

                if(counting) { //reset counting if we were before
                    counting = false;
                    freecount = 0;
                }
            }
        }

        //space available
        if(idxFound != -1) {

            //mark those sections with the group name
            for(int i = idxFound; i < idxFound+width; i++) {
                strncpy(hall + i, name, 1);
            }

            char* report = allocationReport();
            printf("%s allocated: %s\n", name, report);
            free(report);

            pthread_mutex_unlock(&hallAccess);
            return idxFound;
        }
        else { //need to wait

            if(!wasWaiting) {
                char* report = allocationReport();
                printf("%s waiting: %s\n", name, report);
                free(report);
            }
            wasWaiting = true;
            pthread_cond_wait(&notifier, &hallAccess);
        }
    }

}

void freeSpace( char const *name, int start, int width) {

    pthread_mutex_lock(&hallAccess);

    //replace occupied segments with astericks
    for(int i = start; i < start+width; i++) {
        hall[i] = '*';
    }

    char* report = allocationReport();
    printf("%s freed: %s\n", name, report);
    free(report);

    pthread_mutex_unlock(&hallAccess);
    pthread_cond_broadcast(&notifier); //notify waiting threads new space may be available
}

