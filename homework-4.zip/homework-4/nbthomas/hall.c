/** 
  @file hall.c
  @author Noah Thomas
  Program to represent a collection of halls and their reservations by multiple different organization. Program
  attempts to find the first largest amount of space available and provide them to the organization. Space is
  then freed when a group is finished and program tries to find space for the next waiting company.
  */
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>
#include "hall.h"

/** String representation of the halls and bookings */
static char *spaces;
/** total number of halls */
static int size;
/** monitor lock */
static pthread_mutex_t lock;
/** monitor condition */
static pthread_cond_t alloc;

void initMonitor( int n ) {
    spaces = (char *)malloc((n + 1) * sizeof(char)); //generated a string of size n
    spaces[n] = '\0'; //null termination
    for(int c = 0; c < n; c++) { //mark all spaces empty using *
        spaces[c] = '*';
    }
    size = n; //track size
    pthread_mutex_init(&lock, NULL); //initialize lock
    pthread_cond_init(&alloc, NULL); //initialize condition
}

void destroyMonitor() {
    free(spaces); //release hall representation
}

int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock(&lock); //enter lock
    int start = -1; //value for starting index of free space
    int count = 0; //current count of free spaces
    bool freed = false; //checks if a organization was waiting

    for(int i = 0; i < size; i++) { //traverse string

        if(spaces[i] == '*' && start == -1) { //starts valid space seraching
            start = i;
            count++;
        } else if(spaces[i] == '*') { //continue searching
            count++;
        } else { //resets search
            start = -1;
            count = 0;
        }

        if(count == width) { //stop search when first space large enough is found
            break;
        } else if(count != width && i == size - 1) { //if no large enough space found, reset
            start = -1;
            count = 0;
        }
    }

    while (start == -1) { //if not free space found
        if(!freed)
            printf("%s waiting: %s\n", name, spaces); //waiting report
        pthread_cond_wait(&alloc, &lock); //wait
        freed = true; //released from wait
        for(int i = 0; i < size; i++) {

            if(spaces[i] == '*' && start == -1) {
                start = i;
                count++;
            } else if(spaces[i] == '*') {
                count++;
            } else {
                start = -1;
                count = 0;
            }

            if(count == width) {
                break;
            } else if(count != width && i == size - 1) {
                start = -1;
                count = 0;
            }
        }
    }

    for(int s = 0; s < width; s++) { //update if space available
        spaces[start + s] = name[0];
    }

    printf("%s allocated: %s\n", name, spaces); //allocation report

    pthread_mutex_unlock(&lock); //exit monitor

    return start; //return starting index for company
}

void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock(&lock); //enter lock
    for(int fs = start; fs < start + width; fs++) { //go to starting position and free allocation
        spaces[fs] = '*';
    }

    printf("%s freed: %s\n", name, spaces); //freed report

    pthread_mutex_unlock(&lock); //leave monitor

    pthread_cond_broadcast(&alloc); //notify other threads
}