#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for usleep
#include <string.h>    // for strcmp

#include "hall.h"

void initMonitor(int n) 
{

}

void destoryMonitor() 
{

}

int allocateSpace( char const *name, int width )
{
    return 0;
}

void freeSpace( char const *name, int start, int width )
{

}