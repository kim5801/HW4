#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "hall.h"

// The monitor lock
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Condition for blocking threads waiting for space(s) in the hall
pthread_cond_t space = PTHREAD_COND_INITIALIZER;

// The array of characters representing spaces
char * spaces;

// The number of spaces in the hall
int totalSpaces;

// The total number of allocated threads
int totalThreadsAllocated = 0;

// The age of the oldest thread currently running
int oldestThreadAge = 0;

/**
 * @brief Get the current allocation
 * 
 * @return char* a string
 */
char * getCurrentAllocation() {
    char * currentAllocation;
    currentAllocation = (char *) malloc(sizeof(char) * (totalSpaces + 1));
    
    for (int i = 0; i < totalSpaces; i++) {
        currentAllocation[i] = spaces[i] == 0? '*': spaces[i];
    }
    currentAllocation[totalSpaces] = '\0';
    return currentAllocation;
}

void initMonitor( int n ) {
    // Record the total number of spaces in the hall in a global variable
    totalSpaces = n;

    // Allocate space for the array of characters representing spaces
    spaces = (char *) malloc(sizeof(char) * n);
}

void destroyMonitor() {
    // Free the spaces array
    free(spaces);

    // Destroy the condition(s) then the monitor
    pthread_cond_destroy(&space);
    pthread_mutex_destroy(&mon);
}

int allocateSpace( char const *name, int width ) {
    // Keep track of the thread's age - it resets on every call to this method
    int age = 0;

    // Keep track of whether you've printed an allocation statement yet -
    // Only one waiting statement should be printed per thread per attempt at allocation
    bool waitingStringPrinted = false;

    int threadsAllocated = totalThreadsAllocated;

    // Enter the monitor
    pthread_mutex_lock(&mon);
    while (1) {
        // Update your age - the age for any thread that hasn't waited is 0
        if (waitingStringPrinted) {
            age = totalThreadsAllocated - threadsAllocated;
        } else {
            age = 0;
        }

        // Update the global variable value for oldest thread if this thread is now the oldest
        if (age > oldestThreadAge) {
            oldestThreadAge = age;
        }

        // Only look for a space if there isn't a thread whose age is over 100 greater than yours
        if (oldestThreadAge - age <= 100) {
            // Iterate through the array - if space is available, give it to the calling org
            int availableContigSpaces = 0;
            for (int i = 0; i < totalSpaces; i++) {
                if (spaces[i] == 0) {
                    availableContigSpaces++;
                } else {
                    availableContigSpaces = 0;
                }
                if (availableContigSpaces == width) {
                    // Allocate the space - enough contiguous spaces are available
                    char orgFirstChar = name[0];
                    int firstSpaceAllocated = i - availableContigSpaces + 1;
                    for (int j = firstSpaceAllocated; j <= i; j++) {
                        spaces[j] = orgFirstChar;
                    }
                    // Print a message indicating allocation has occurred
                    printf("%s allocated (%d): %s\n", name, age, getCurrentAllocation());

                    // Reset the oldest age if it was yours
                    if (oldestThreadAge == age) {
                        oldestThreadAge = 0;
                    }

                    // Increment the global variable indicating you are about to return from the method
                    totalThreadsAllocated++;

                    // Give up your lock on the monitor and return
                    pthread_mutex_unlock(&mon);
                    return firstSpaceAllocated;
                }
            }
        }
        
        // Print a line indicating that this thread is waiting
        if (waitingStringPrinted == false) {
            printf("%s waiting: %s\n", name, getCurrentAllocation());
            waitingStringPrinted = true;
            // Make note of how many threads have been allocated before you start waiting
            threadsAllocated = totalThreadsAllocated;
        }

        // Wait to be woken up 
        pthread_cond_wait(&space, &mon);
    }
    // This shouldn't ever happen.
    printf("%s gave up.\n", name);
    return -1; 
}

void freeSpace( char const *name, int start, int width ) {
    // Enter the monitor
    pthread_mutex_lock(&mon);

    for (int i = start; i < start + width; i++) {
        // Set the characters which were previously occupied by the calling thread to 0
        spaces[i] = 0;
    }

    // Print a string in the format "{name} freed: {current allocation}"
    printf("%s freed: %s\n", name, getCurrentAllocation());

    // Wake up all threads waiting to see if spaces are available
    pthread_cond_broadcast(&space);

    // Give up your lock on the monitor
    pthread_mutex_unlock(&mon);
}
