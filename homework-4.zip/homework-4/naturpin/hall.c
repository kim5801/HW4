#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// The maximum size for a thread's name
#define STRING_SIZE 30

// The list of names used to report back which are occupied
static char ** hall;

// The size of the hall
static int size;

// Monitor used for locking and unlocking critical sections
static pthread_mutex_t mon;

// Condition variable used to control waiting threads
static pthread_cond_t wait;

// Global flag for whether or not a thread has exceeded the maximum age
static bool exceedsAge = false;

// Condition variable used to prioritize aged threads
static pthread_cond_t waitAge;

// A private function used to write hall (freed and waiting) reports
static void writeMessage(char const * name, char * message) {
    // Allocate some space for the report string
    char * hallReport = (char *)malloc(size * sizeof(char));

    // Fill the string with the first character of every name
    for (int i = 0; i < size; i++) {
        hallReport[i] = hall[i][0];
    }

    // Print the report
    printf("%s %s: %s\n", name, message, hallReport);

    // Free the report string memory
    free(hallReport);
}

// A private function used to write hall allocation reports.
// It's the same as the function above, but also reports the age of the thread
static void writeAllocMessage(char const * name, char * message, int age) {
    // Allocate some space for the report string
    char * hallReport = (char *)malloc(size * sizeof(char));

    // Fill the string with the first character of every name
    for (int i = 0; i < size; i++) {
        hallReport[i] = hall[i][0];
    }

    // Print the report
    printf("%s %s (%d): %s\n", name, message, age, hallReport);

    // Free the report string memory
    free(hallReport);
}

void initMonitor( int n ) {
    // Allocate memory to the overall hall and save its size
    hall = (char **)malloc(n * sizeof(char *));
    size = n;
    
    // Allocate memory for each room to store names
    for (int i = 0; i < n; i++) {
        hall[i] = (char *)malloc(STRING_SIZE * sizeof(char));
        strcpy(hall[i], "*\0");
    }

    // Initialize monitor and condition variable
    pthread_mutex_init(&mon, NULL);
    pthread_cond_init(&wait, NULL);
    pthread_cond_init(&waitAge, NULL);
}

void destroyMonitor() {
    // Free each room
    for (int i = 0; i < size; i++) {
        free(hall[i]);
    }

    // Free the hall itself
    free(hall);
}


int allocateSpace( char const *name, int width ) {

    // Enter the critical section
    pthread_mutex_lock(&mon);

    // Counts the number of available rooms in the current hole
    int freeCount = 0;

    // Stores the starting index of the current hole
    int index;

    // Whether or not the thread has been allocated space in the hall
    bool allocated = false;

    // Whether or not the thread is already waiting
    bool waiting = false;

    // Start the thread's age at zero
    int age = 0;

    // If any thread exceeds the maximum age, wait until it's done
    while (exceedsAge) {
        pthread_cond_wait(&waitAge, &mon);
    }

    while (!allocated) {

        // Look through all the rooms
        for (int i = 0; i < size; i++) {
            // Check the next room. Since all names must start with a different letter, 
            // just check the first letter.
            char c = hall[i][0];

            // If the room is empty...
            if (c == '*') {
                // That's one more free, contiguous room
                freeCount++;

                if (freeCount == 1) {
                    // If this is the start of the hole, save the index. We will need it later
                    index = i;
                }

                // If we've found a suitable hole...
                if (freeCount == width) {
                    // Claim it by putting the name on those rooms
                    for (int j = index; j < index + width; j++) {
                        strcpy(hall[j], name);
                    }

                    // Mark that we're done
                    allocated = true;

                    // And exit the loop so we don't overwrite our index
                    goto done;
                }
            } else {
                // If it's not empty, then the hole was too small. Try the next one
                freeCount = 0;
            }

        }

        // If we looked at all the holes and couldn't find one big enough, just wait
        if (!allocated) {

            // If the thread has just started waiting, make a report
            if (!waiting) {
                writeMessage(name, "waiting");
                waiting = true;
            }

            // Wait
            pthread_cond_wait(&wait, &mon);

            // When we're done waiting, age up
            age++;

            // If we've exceeded the maximum age, mark the flag so new threads wait
            if (age > 100) {
                exceedsAge = true;
            }

            // Reset this thread's variables and go again
            freeCount = 0;
            index = 0;
            allocated = false;
        }
    }

    done: ;

    // Exit the critical section
    pthread_mutex_unlock(&mon);

    // When we've found a hole, report and return
    writeAllocMessage(name, "allocated", age);
    return index;

}

void freeSpace( char const *name, int start, int width ) {

    // Enter the critical section
    pthread_mutex_lock(&mon);

    // Replace all the rooms taken up by name with empty rooms
    for (int i = start; i < start + width; i++) {
        strcpy(hall[i], "*\0");
    }

    // Let everyone know there's a new hole
    pthread_cond_broadcast(&wait);

    // When aged threads are freed, reset the flag and tell all the threads waiting for it to go
    exceedsAge = false;
    pthread_cond_broadcast(&waitAge);

    // Exit the critical section
    pthread_mutex_unlock(&mon);

    // When we've freed up a hole, report
    writeMessage(name, "freed");

}
