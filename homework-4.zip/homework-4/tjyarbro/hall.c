#include "hall.h"

// Citing help from Osama Albahrani for this #define (see Piazza Post @344)
// Start of section where help was received
#define _GNU_SOURCE 1
// End of section where help was received

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/syscall.h>

pthread_mutex_t lock;

pthread_cond_t needSpace;

pthread_cond_t waitForOld;

char* rooms;

int numRooms;

int numThreads;

long* threadIDS;

bool* waitingOnSpace;

int* numberOfWaits;

// initialze the monitor, rooms, and numRooms
void initMonitor(int n) {

    // initialize the monitor
    pthread_mutex_init(&lock, NULL);

    // initialize the needSpace condition variable
    pthread_cond_init(&needSpace, NULL);

    // initialize the waitForOld coniditon variable
    pthread_cond_init(&waitForOld, NULL);

    // initialize numRooms
    numRooms = n;

    // give rooms space (plus one for a null terminator)
    rooms = malloc((n + 1) * sizeof(char));

    // initialize all rooms to open
    for(int i = 0; i < n; i++) {
        rooms[i] = '*';
    }

    // initialize the null terminator
    rooms[n] = '\0';

    // initialize the number of threads
    numThreads = 0;

    // initialize threadIDS
    threadIDS = malloc(0);

    // initialize waiting
    waitingOnSpace = malloc(0);

    // initialize numberOfWaits
    numberOfWaits = malloc(0);

}

// destory the monitor and free rooms, threadIDS, waitingOnSpace, and numberOfWaits
void destroyMonitor() {

    free(rooms);

    free(threadIDS);

    free(waitingOnSpace);

    free(numberOfWaits);

    pthread_mutex_destroy(&lock);

}

bool enoughSpace(int width) {

    // see if there is enough contiguous space to allocate the request

    int contigSpace = 0;

    int maxContigSpace = 0;

    // for all rooms
    for(int i = 0; i < numRooms; i++) {

        // if the room is open
        if(rooms[i] == '*') {
            contigSpace++;
        }

        // if the room is not open
        else {

            // update maxContigSpace if needed
            if(contigSpace > maxContigSpace) {
                maxContigSpace = contigSpace;
            }

            // reset contigSpace
            contigSpace = 0;

        }

    }

    // possible all rooms were open

    // update maxContigSpace if needed
    if(contigSpace > maxContigSpace) {
        maxContigSpace = contigSpace;
    }

    // if there is enough space
    if(maxContigSpace >= width) {
        return true;
    }

    // if there is not enough space
    else {
        return false;
    }

}

void allocateArrayPos(long threadID) {

    // keep track of if this thread already has a space in the array
    bool hasPlace = false;

    // for all values
    for(int i = 0; !hasPlace && i < numThreads; i++) {

        if(threadIDS[i] == threadID) {

            // this thread is in the array
            hasPlace = true;

        }

    }

    // if a new place is needed
    if(!hasPlace) {

        // increment the number of threads and allocate space
        numThreads++;

        threadIDS = realloc(threadIDS, numThreads * sizeof(long));
        waitingOnSpace = realloc(waitingOnSpace, numThreads * sizeof(bool));
        numberOfWaits = realloc(numberOfWaits, numThreads * sizeof(int));

        // fill in the information for the new thread
        threadIDS[numThreads - 1] = threadID;
        waitingOnSpace[numThreads - 1] = false;
        numberOfWaits[numThreads - 1] = 0;

    }

}

// checks if there is another thread waiting on space and has waited more than 100 times than this thread
bool oldIsWaiting(long threadID) {

    // flag to stop loop early
    bool found = false;

    // number of waits of the calling thread
    int myWaits;

    for(int i = 0; !found && i < numThreads; i++) {

        // if this is my slot in the array
        if(threadIDS[i] == threadID) {

            myWaits = numberOfWaits[i];

            found = true;

        }

    }

    // flag to see if this thread should wait for an older thread
    bool shouldWaitOnOld = false;

    for(int i = 0; !shouldWaitOnOld && i < numThreads; i++) {

        if(threadIDS[i] != threadID && waitingOnSpace[i] && (numberOfWaits[i] - myWaits > 100)) {

            shouldWaitOnOld = true;

        }

    }

    return shouldWaitOnOld;

}

int allocateSpace(char const *name, int width) {

    // enter the monitor
    pthread_mutex_lock(&lock);

    // local instance of this threads TID so it does not have to system call every time it is needed
    long myTID = syscall(__NR_gettid);

    // get a place in the monitor array if you do not have one
    allocateArrayPos(myTID);

    // keeps track of if the thread had to wait
    bool hadToWait = false;

    // see if this thread should wait on an old thread
    while(oldIsWaiting(myTID)) {

        pthread_cond_wait(&waitForOld, &lock);

        myTID = syscall(__NR_gettid);

    }
    
    while(!enoughSpace(width)) {

        // first time the thread had to wait
        if(!hadToWait) {
            printf("%s waiting: %s\n", name, rooms);
            fflush(stdout);
        }

        // find yourself the first time you have to wait and set your waiting status to true
        for(int i = 0; !hadToWait && i < numThreads; i++) {
            
            // if this is my spot in the array
            if(threadIDS[i] == myTID) {
                
                // this thread is waiting
                waitingOnSpace[i] = true;

                // this thread did have to wait
                hadToWait = true;

            }

        }

        pthread_cond_wait(&needSpace, &lock);

        myTID = syscall(__NR_gettid);

    }

    // there is enough space now

    // find the lowest index available

    // keeps track of the first index of each open space
    // gets reset if the contigous space is too small
    int idx = -1;

    int contigSpace = 0;

    // for all rooms
    for(int i = 0; i < numRooms; i++) {

        // if the room is free
        if(rooms[i] == '*') {

            // if idx is -1, it needs to keep track of index i,
            // as this marks an open space
            if(idx == -1) {
                idx = i;
            }

            contigSpace++;

            // could probably use == here
            if(contigSpace >= width) {
                    
                // "allocate" the rooms

                for(int j = idx; j - idx < width; j++) {

                    // rooms marked by first letter of company name
                    rooms[j] = name[0];

                }

                // flag to stop loop early
                bool found = false;

                // number of times this thread waited
                int numWaits;

                // get the number of waits required for this thread and update its waiting status to false
                for(int i = 0; !found && i < numThreads; i++) {

                    if(threadIDS[i] == myTID) {

                        numWaits = numberOfWaits[i];

                        // now reset numumberOfWaits
                        numberOfWaits[i] = 0;

                        // no longer waiting
                        waitingOnSpace[i] = false;

                        found = true;

                    }

                }

                // increment the number of wait threads for all threads waiting
                for(int i = 0; i < numThreads; i++) {

                    // if not this thread and waiting increment waiting time
                    if(threadIDS[i] != myTID && waitingOnSpace[i]) {
                        
                        numberOfWaits[i] = numberOfWaits[i] + 1;

                    }

                }
                
                printf("%s allocated (%d): %s\n", name, numWaits, rooms);
                fflush(stdout);

                // leave the monitor
                pthread_mutex_unlock(&lock);

                return idx;

            }

        }

        // the room is not free
        else {

            // reset contigSpace and idx
            idx = -1;
            contigSpace = 0;

        }

    }

    // leave the monitor
    pthread_mutex_unlock(&lock);

    // should never get here, there should always be enough space
    return idx;

}

void freeSpace(char const *name, int start, int width) {

    // enter the monitor
    pthread_mutex_lock(&lock);

    // "free" the rooms

    for(int i = start; i - start < width; i++) {

        rooms[i] = '*';

    }

    printf("%s freed: %s\n", name, rooms);

    // wake up everyone to see if they can get their requested space
    pthread_cond_broadcast(&waitForOld);
    pthread_cond_broadcast(&needSpace);

    // leave the monitor
    pthread_mutex_unlock(&lock);

}

