/**
 * @file hall.c
 * @author Daniel Buchanan (dsbuchan)
 * Manages rooms for a hall, allocating space for different names when requesting, then freeing that space
 * when they are done.
 */
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

/** Mutex for controlling access to the monitor*/
static pthread_mutex_t lock;
/** Condition vairable that acts as consumer */
static pthread_cond_t wait;
/** Keeps track of the max age of all threads*/
static int maxAge;
/** Stores the number of spaces in the hall*/
static int size;
/** stores the capacity*/
static int capacity;
/** Represents hall made up of n spaces*/
static char * hall;


/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n )
{
  pthread_mutex_init( &lock, NULL );
  pthread_cond_init(&wait, NULL);
  //pthread_cond_init(&makeSpace, NULL);
  hall = (char *)malloc((n + 1)*  sizeof(char));
  size = 0;
  maxAge = 0;
  capacity = n;
  // initialize all values to '*' charaters
  for(int i = 0; i < capacity; i++){
    hall[i] = '*';
  }
  hall[n + 1] = '\0';
  
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
  pthread_cond_destroy(&wait);
  free(hall);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width )
{
  // enter the monitor
  pthread_mutex_lock( &lock );
  // starting index
  int start = -1;
  // find space that meets the required width
  int space = 0;
  // if the thread could not find space
  int noSpace = 0;
  // age of the thread
  int age = 0;

  while(space < width){
    // wait to examine rooms
    // if difference is greater than 100 between threads, the thread with the greater age goes first
    while(size + width > capacity || noSpace || age + 100 < maxAge ){
      if(start == -1){
        start = 0;
        printf("%s waiting: %s\n", name, hall);
      }
      pthread_cond_wait(&wait, &lock);
      // after first wait is resolved, check again if there is space
      noSpace = 0;
      age++;
      if(age > maxAge){
        maxAge = age;
      }
     
    }
    noSpace = 0;
    start = 0;
    // inner loop to go through all rooms in hall
    for(int i = 0; i < capacity; i++){
      // empty room, increment space
      if(hall[i] == '*'){
        space++;
        // enough space for the event, can now exit loops
        if(space >= width){
          
          // here, need to make sure that characters are marked in hall
          for(int k = start; k < start + width; k++){
            hall[k] = name[0];
            size++;
          }
          printf("%s allocated (%d): %s\n", name, age, hall);
          // reset max age
          if(age >= maxAge){
            maxAge = 0;
          }
          // signal another waiting thread
          pthread_cond_signal(&wait);
          pthread_mutex_unlock( &lock );
          return start;
        }
      } else {
        start = i + 1;
        space = 0;
      }
    }
    // thread will enter waiting state when it restarts the loop
    noSpace = 1;
  }
  
  // also need to print that the space was allocated
  printf("%s allocated (%d): %s\n", name, age, hall);
  pthread_cond_signal(&wait);
  pthread_mutex_unlock( &lock );
  return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width )
{
  // enter monitor
  pthread_mutex_lock( &lock );
  
  // need to pass the value of the freed spaced back to the monitor
  while( size == 0){
    pthread_cond_wait(&wait, &lock);
  }
    
  // set all occupied spaces back to empty
  for(int i = start; i < start + width; i++){
    hall[i] = '*';
    size--;
  }
  printf("%s freed: %s\n", name, hall);
  // signal all waiting threads
  pthread_cond_broadcast(&wait);
  // exit the monitor
  pthread_mutex_unlock( &lock );
}