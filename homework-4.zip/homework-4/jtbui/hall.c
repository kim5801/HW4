#include "hall.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#define EMPTY '*'

//monitor
static pthread_mutex_t hallMonitor;
//condition for monitor
static pthread_cond_t monitorWatch1;

//the hall
static char *hall;
//width of the hall
static int hallWidth;
//list for widths different consumers need
static int *widthNeeded;
//list adjacent to widthNeeded that lets the consumer know if the space they need is available
static bool *hallAvailable;

void initMonitor(int n) {
    pthread_mutex_init(&hallMonitor, NULL);
    pthread_cond_init(&monitorWatch1, NULL);

    hall = (char *)malloc(n * sizeof(char));
    widthNeeded = (int *)malloc(n * sizeof(int));
    hallAvailable = (bool *)malloc(n * sizeof(bool));
    for (int i = 0; i < n; ++i) {
        hall[i] = EMPTY;
        widthNeeded[i] = 0;
        hallAvailable[i] = true;
    }
    hallWidth = n;
}

void destroyMonitor() {
    free(hall);
    free(widthNeeded);
    free(hallAvailable);
    pthread_mutex_destroy(&hallMonitor);
    pthread_cond_destroy(&monitorWatch1);
}

int allocateSpace(char const *name, int width) {
    //enter monitor
    pthread_mutex_lock(&hallMonitor);
    //how many spaces available
    int space = 0;
    //start of the available continuous space
    int start = 0;

    //trying to find if there are any available spaces large enough
    for (int i = 0; i < hallWidth; ++i) {
        if (hall[i] == EMPTY) { //space is available
            //if first of continuous spaces
            if (space == 0) { 
                start = i;
            }
            ++space;

            //there are enough spaces
            if (space >= width) {
                //mark as unavailable now
                for (int j = start; j < start + width; ++j) {
                    hall[j] = name[0];
                }

                printf("%s allocated: %s\n", name, hall);

                pthread_mutex_unlock(&hallMonitor);
                return start;
            }
        }
        else { //space is unavailable
            space = 0;
            start = 0;
        }
    }

    space = 0;

    //the queue number of the thread waiting
    int queueNum = 0;

    //no available spaces large enough
    for (int i = 0; i < hallWidth; ++i) {
        if (hallAvailable[i]) {
            queueNum = i;
            hallAvailable[i] = false;
            widthNeeded[i] = width;
            break;
        }
    }

    printf("%s waiting: %s\n", name, hall);

    //conditional wait until there is enough spaces
    while (!hallAvailable[queueNum]) {
        pthread_cond_wait(&monitorWatch1, &hallMonitor);
    }

    //find the start of the available space
    for (int i = 0; i < hallWidth; ++i) {
        if (hall[i] == EMPTY) {
            if (space == 0) {
                start = i;
            }
            ++space;

            //found the space large enough
            if (space >= width) {
                break;
            }
        }
        else {
            space = 0;
            start = 0;
        }
    }

    //changing to occupied space
    for (int i = start; i < start + width; ++i) {
            hall[i] = name[0];
    }

    printf("%s allocated: %s\n", name, hall);

    //exit monitor
    pthread_mutex_unlock(&hallMonitor);

    return start;
}

void freeSpace(char const *name, int start, int width) {
    //entering monitor
    pthread_mutex_lock(&hallMonitor);

    //freeing
    for (int i = start; i < start + width; ++i) {
        hall[i] = EMPTY;
    }

    printf("%s freed: %s\n", name, hall);

    int freedSoFar = 0;
    bool found = false;

    //finding the first thread that is waiting on enough space
    for (int i = 0; i < hallWidth; ++i) {
        if (hall[i] == EMPTY) {
            ++freedSoFar;
        }
        else {
            freedSoFar = 0;
        }
        for (int j = 0; j < hallWidth; ++j) {
            if (widthNeeded[j] != 0 && freedSoFar >= widthNeeded[j]) {
                hallAvailable[j] = true;
                widthNeeded[j] = 0;
                found = true;
                break;
            }
        }
        if (found) {
            break;
        }
    }

    //wake others waiting for a free space
    pthread_cond_signal(&monitorWatch1);

    //exit monitor
    pthread_mutex_unlock(&hallMonitor);
}
