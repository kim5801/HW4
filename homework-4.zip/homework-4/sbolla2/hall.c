/**
 * Allocates different spaces of a hall to customers.
 * Gives the first largest spot in the hall that fits the customers needs.
 * @file hall.c
 * @author Sania Bolla (sbolla2)
 * @date 2022-10-30
 * 
 */
#include "hall.h"
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdio.h>

// Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter06/BufferFromSlides.c

/** Which spaces of the room are free (*) and which are taken by a customer (customer first letter) */
char* room;
/** Which slots are full (false) and which are open(true) */
bool* full;
/** *Size of the hall */
int size;
/** Lock for accessing room and full array */
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/** Condition for telling the other threads that space has been added back to the hall */
pthread_cond_t moreSpace = PTHREAD_COND_INITIALIZER;
/** Whether a space can be allocated to a customer or not */
bool canAllocate = false;

void initMonitor( int n ) {
    // Storing the size of the hall into a size global variable to be used throughout the file
    size = n;
    // Allocate space for the room array
    room = (char*)malloc(n * sizeof(char));
    // Allocate space for the full array
    full = (bool*)malloc(n * sizeof(bool));
    // Lock the access into the two arrays (full and room)
    pthread_mutex_lock( &lock );
    for (int i = 0; i < n; i++) {
        room[i] = '*';
    }
    for (int i = 0; i < n; i++) {
        full[ i ] = false;
    }
    // Unlock the access into the two arrays (full and room)
    pthread_mutex_unlock( &lock );
    // Signal to other threads that all the space in the room has been added
    pthread_cond_signal(&moreSpace);
}

/**
 * @brief Checks if the width that a customer is requesting is available in the hall or not
 * 
 * @param width the requested size from the hall
 * @return true if there is a width amount of space available
 * @return false if there is not the required space available
 */
bool availableAllocation (int width) {
    // Whether there is space to allocate
    bool result = false;
    // COunting how many spaces in a room are available (false = not taken)
    int falseCount = 0;
    for (int i = 0; i < size; i++) {
        if (full[i] == false) {
            falseCount++;
        } else if (full[i] == true){
            falseCount = 0;
        }
        // A space of width size has been found
        if (falseCount == width) {
            result = true;
            break;
        }
    }
    return result;
}

/**
 * @brief Finds the left most value of the space that's being allocated to the hall
 * 
 * @param width the requested size from the hall
 * @return int left is the left most value of the space being allocated
 */
int leftVal(int width) {
    // The starting index of the space that's allocated away
    int left = 0;
    int fCount = 0;
    for (int i = 0; i < size; i++) {
        if (full[i] == false && fCount == 0) {
            left = i;
            fCount++;
        } else if (full[i] == true){
            fCount = 0;
        }
        // A space has been found so we don't need to continue
        if (fCount == width) {
            break;
        }
    }
    return left;
}
int allocateSpace( char const *name, int width ) {
    // Lock the access into the two arrays (full and room)
    pthread_mutex_lock( &lock );
    // Check if there is space of allocate
    bool go = availableAllocation(width);
    // If there is not space, print that the customer is waiting
    if (!go) {
        printf("%s waiting: ", name);
        for (int i = 0; i < size; i++){
            printf("%c", room[i]);
        }
        printf("\n");
    }
    // While there is no space, wait for a signal
    while (!availableAllocation(width)) {
        pthread_cond_wait(&moreSpace, &lock);
    }
    // Change the values of the full and room array to indicate space is being taken
    int left = leftVal(width);
    for (int i = left; i < (left + width); i++) {
        full[i] = true;
        room[i] = name[0];
    }
    // Print the statement about what has been allocated and to who
    printf("%s allocated: ", name);
    for (int i = 0; i < size; i++){
        printf("%c", room[i]);
    }
    printf("\n");
    // Unlock the access into the two arrays (full and room)
    pthread_mutex_unlock( &lock );
    return left;
}

void freeSpace( char const *name, int start, int width ) {
    // Lock the access into the two arrays (full and room)
    pthread_mutex_lock( &lock );
    // Free the space that was being used by the thread
    for (int i = start; i < (start + width); i++) {
        room[i] = '*';
        full[i] = false;
    }
    // Print the statment that shows what the state of the hall looks like now
    printf("%s freed: ", name);
    for (int i = 0; i < size; i++){
        printf("%c", room[i]);
    }
    printf("\n");
    // Signal that space has now been added
    pthread_cond_signal(&moreSpace);
    // Unlock the access into the two arrays (full and room)
    pthread_mutex_unlock( &lock );
}

void destroyMonitor() {
    // Free the room and full array
    free(room);
    free(full);
}
