import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 * Chefs will allocate all their needed appliances at once and will only 
 * be able to take them if they are all available.
 * 
 * Using Synchronization Slides
 * @author starter file given on Moodle
 * @author Sania Bolla
 * 
 */
public class TakeAll {
    /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  /**
   * My Monitor that sets up all the booleans for appliances.
   * There are methods to take and return all the appliances
   * There are mthods for each chef so that they can take and return all there materials at once.
   */
  private static class MyMonitor {
    private static boolean griddle = true;
    private static boolean mixer = true;
    private static boolean oven = true;
    private static boolean blender = true;
    private static boolean grill = true;
    private static boolean fryer = true;
    private static boolean microwave = true;
    private static boolean coffeeMaker = true;

    // Take Griddle
    public synchronized void takeGriddle () {
        griddle = false;
    }
    // Return Griddle
    public synchronized void returnGriddle() {
        griddle = true;
    }
    // Take Mixer
    public synchronized void takeMixer () {
        mixer = false;
    }
    // Return Mixer
    public synchronized void returnMixer() {
        mixer = true;
    }
    // Take Oven
    public synchronized void takeOven () {
        oven = false;
    }
    // Return Oven
    public synchronized void returnOven() {
        oven = true;
    }
    // Take Blender
    public synchronized void takeBlender () {
        blender = false;
    }
    // Return Blender
    public synchronized void returnBlender() {
        blender = true;
    }
    // Take Grill
    public synchronized void takeGrill() {
        grill = false;
    }
    // Return Grill
    public synchronized void returnGrill() {
        grill = true;
    }
    // Take Fryer
    public synchronized void takeFryer () {
        fryer = false;
    }
    // Return Fryer
    public synchronized void returnFryer() {
        fryer = true;
    }
    // Take Microwave
    public synchronized void takeMicrowave () {
        microwave = false;
    }
    // Return Microwave
    public synchronized void returnMicrowave() {
        microwave = true;
    }
    // Take CoffeeMaker
    public synchronized void takeCoffeeMaker() {
        coffeeMaker = false;
    }
    // Return CoffeeMaker
    public synchronized void returnCoffeeMaker() {
        coffeeMaker = true;
    }
    // Mandy takes appliances she needs
    public synchronized void MandyTake() {
        while ( microwave == false && coffeeMaker == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeMicrowave();
        takeCoffeeMaker();
    }
    // Mandy returns the appliances she took
    public synchronized void MandyReturn() {
        returnMicrowave();
        returnCoffeeMaker();
        notifyAll();
    }
    // Edmund takes appliances he needs
    public synchronized void EdmundTake() {
        while ( blender == false && oven == false &&  mixer == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeBlender();
        takeOven();
        takeMixer();
    }
    // Edmund returns the appliances he took
    public synchronized void EdmundReturn() {
        returnBlender();
        returnOven();
        returnMixer();
        notifyAll();
    }
    // Napolean takes appliances he needs
    public synchronized void NapoleonTake() {
        while ( blender == false && grill == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeBlender();
        takeGrill();
    }
    // Napolean returns the appliances he took
    public synchronized void NapoleonReturn() {
        returnBlender();
        returnGrill();
        notifyAll();
    }
    // Prudence takes appliances he needs
    public synchronized void PrudenceTake() {
        while ( coffeeMaker == false && microwave == false && griddle == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeCoffeeMaker();
        takeMicrowave();
        takeGriddle();
    }
    // Prudence returns the appliances he took
    public synchronized void PrudenceReturn() {
        returnCoffeeMaker();
        returnMicrowave();
        returnGriddle();
        notifyAll();
    }
    // Kyle takes appliances he needs
    public synchronized void KyleTake() {
        while ( fryer == false && oven == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeFryer();
        takeOven();
    }
    // Kyle returns the appliances he took
    public synchronized void KyleReturn() {
        returnFryer();
        returnOven();
        notifyAll();
    }
    // Claire takes appliances she needs
    public synchronized void ClaireTake() {
        while ( grill == false && griddle == false ) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeGrill();
        takeGriddle();
    }
    // Claire returns the appliances she took
    public synchronized void ClaireReturn() {
        returnGrill();
        returnGriddle();
        notifyAll();
    }
    // Lucia takes appliances she needs
    public synchronized void LuciaTake() {
        while ( griddle == false && mixer == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeGriddle();
        takeMixer();
    }
    // Lucia returns the appliances she took
    public synchronized void LuciaReturn() {
        returnGriddle();
        returnMixer();
        notifyAll();
    }
    // Marcos takes appliances he needs
    public synchronized void MarcosTake() {
        while ( microwave == false && fryer == false && blender == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeMicrowave();
        takeFryer();
        takeBlender();
    }
    // Marcos returns the appliances he took
    public synchronized void MarcosReturn() {
        returnMicrowave();
        returnFryer();
        returnBlender();
        notifyAll();
    }
    // Roslyn takes appliances she needs
    public synchronized void RoslynTake() {
        while ( fryer == false && grill == false) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeFryer();
        takeGrill();
    }
    // Roslyn returns the appliances she took
    public synchronized void RoslynReturn() {
        returnFryer();
        returnGrill();
        notifyAll();
    }
    // Stephanie takes appliances she needs
    public synchronized void StephenieTake() {
        while ( mixer == false && coffeeMaker == false && oven == false ) {
            try {
                wait();
            } catch ( InterruptedException e ) {
            }
        }
        takeMixer();
        takeCoffeeMaker();
        takeOven();
    }
    // Stephanie returns the appliances she took
    public synchronized void StephenieReturn() {
        returnMixer();
        returnCoffeeMaker();
        returnOven();
        notifyAll();
    }
  }

  private static MyMonitor monitor = new MyMonitor();
  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.MandyTake();
        cook( 105 );
        monitor.MandyReturn();
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.EdmundTake();
        cook( 30 );
        monitor.EdmundReturn();

        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.NapoleonTake();
        cook( 60 );
        monitor.NapoleonReturn();
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.PrudenceTake();
        cook( 15 );
        monitor.PrudenceReturn();
        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.KyleTake();
        cook( 45 );
        monitor.KyleReturn();
        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.ClaireTake();
        cook( 15 );
        monitor.ClaireReturn();
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.LuciaTake();
        cook( 15 );
        monitor.LuciaReturn();
        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.MarcosTake();
        cook( 60 );
        monitor.MarcosReturn();
        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.RoslynTake();
        cook( 75 );
        monitor.RoslynReturn();
        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        monitor.StephenieTake();
        cook( 30 );
        monitor.StephenieReturn();
        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
