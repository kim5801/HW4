/**
  @file hall.c
  @author Erin Grouge
  This program simulates a conference hall allocation system. It manages reservations for spaces in the hall,
  provided space when available or making threads wait until there is space for their reservation. 
 */
#include "hall.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

/** The mutex used to lock the monitor */
static pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;
/** The condition variable used to block and signal threads */
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
/** The hall representation */
static char *hall;
/** The length of the hall */
static int len;
/** Indicater of no space available in the hall. */
#define NO_SPACE -1

/** Initialize the monitor as a hall with n spaces that can be partitioned off. 
    @param n the amount of spaces in the hall
*/
void initMonitor( int n ){
    // Allocate the hall for n spaces + 1 null terminater
    hall = (char *)malloc((n + 1) * sizeof(char));
    // Initialize each hall to the empty character '*'
    for(int i = 0; i < n; i++){
        hall[i] = '*';
    }
    // Null terminate the string
    hall[n] = '\0';
    // Store the length
    len = n;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor(){
    pthread_mutex_destroy(&mut);
    pthread_cond_destroy(&cond);
    free(hall);
}

/** Checks for available space. Returns -1 is none is available or the index of the 
    available space. 
    @param width the length of space needed
    @return index the index of the space available.
 */
static int checkSpace(int width){
    int index = NO_SPACE;
    int space = 0;

    // Iterate through the hall checking for consecutive spaces that are of desired width
    for(int i = 0; i < len; i++){
        // If empty, increment consecutive spaces found
        if(hall[i] == '*'){
            space += 1;
        } 
        // If non empty, start over
        else {
            space = 0;
        }
        // If enough space is found, break out of loop
        if(space >= width){
            // Mark the index of the beginning of the space.
            index = i - width + 1;
            break;
        }
    }
    // Return the index of the space
    return index;
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. 
    @param name the name of the organization reserving the space   
    @param width the amount of space desired
    @return index the starting index of the space
 */
int allocateSpace( char const *name, int width ){
    pthread_mutex_lock(&mut); // Lock the mutex.

    // Find space for the new allocation.
    int index = checkSpace(width);

    // If no space available, report waiting.
    if(index == NO_SPACE){
        printf("%s waiting: %s\n", name, hall);
    }

    // While space isn't available, wait on condition variable. Check again when signaled. 
    while(index == NO_SPACE){
        pthread_cond_wait(&cond, &mut);
        index = checkSpace(width);
    }

    // Once index has been found for space, perform the reservation.
    // Get initial for hall reservation
    char initial = name[0];

    // Update hall
    for(int i = 0; i < width; i++){
        hall[index + i] = initial;
    }

    // Report new allocation.
    printf("%s allocated: %s\n", name, hall);

    pthread_mutex_unlock(&mut); // Unlock the mutex.
    return index;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. 
    @param name the organization with the space
    @param start the starting index of the space
    @param width the amount of space to free. 
 */
void freeSpace( char const *name, int start, int width ){
    pthread_mutex_lock(&mut); // Lock the mutex.

    // Indicate the spaces are now empty.
    for(int i = 0; i < width; i++){
        hall[start + i] = '*';
    }

    // Report the new current allocation.
    printf("%s freed: %s\n", name, hall);

    // Signal to a thread that space has been freed.
    pthread_cond_signal(&cond);
    pthread_mutex_unlock(&mut); // Unlock the mutex.
}