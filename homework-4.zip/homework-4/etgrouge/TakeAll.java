import java.util.Random;

/**
  @author Dr. Sturgill
  @author Erin Grouge
  This program simulates 10 chefs cooking simultaneously with 8 appliances, using boolean flags
  and an object to prevent deadlock and race conditions. 
 */
public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  // A boolean variable representing the lock on each appliance.
  // Locking the needed appliances before cooking prevents two
  // chefs from trying to use the same appliance at the same time.
  // true == available and false == in use
  private static boolean griddle = true;
  private static boolean mixer = true;
  private static boolean oven = true;
  private static boolean blender = true;
  private static boolean grill = true;
  private static boolean fryer = true;
  private static boolean microwave = true;
  private static boolean coffeeMaker = true;
  // Object that acts like a lock for synchronization.
  private static Object sync = new Object();

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(microwave && coffeeMaker)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          microwave = false;
          coffeeMaker = false;
        }

        // Cook the meal
        cook( 105 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          microwave = true;
          coffeeMaker = true;
          sync.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(blender && oven && mixer)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          blender = false;
          oven = false;
          mixer = false;
        }

        // Cook the meal
        cook( 30 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          blender = true;
          oven = true;
          mixer = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(blender && grill)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          blender = false;
          grill = false;
        }

        // Cook the meal
        cook( 60 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          blender = true;
          grill = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(coffeeMaker && microwave && griddle)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          coffeeMaker = false;
          microwave = false;
          griddle = false;
        }

        // Cook the meal
        cook( 15 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          coffeeMaker = true;
          microwave = true;
          griddle = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(fryer && oven)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          fryer = false;
          oven = false;
        }

        // Cook the meal
        cook( 45 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          fryer = true;
          oven = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(grill && griddle)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          grill = false;
          griddle = false;
        }

        // Cook the meal
        cook( 15 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          grill = true;
          griddle = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(mixer && griddle)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          mixer = false;
          griddle = false;
        }

        // Cook the meal
        cook( 15 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          mixer = true;
          griddle = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(fryer && microwave && blender)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          fryer = false;
          microwave = false;
          blender = false;
        }

        // Cook the meal
        cook( 60 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          fryer = true;
          microwave = true;
          blender = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(grill && fryer)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          grill = false;
          fryer = false;
        }

        // Cook the meal
        cook( 75 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          grill = true;
          fryer = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( sync ) {
          // While the appliances are not available, wait
          while(!(mixer && coffeeMaker && oven)){
            try{
              sync.wait();
            } catch (InterruptedException e){
              System.out.println("Failed to wait.");
              System.exit(1);
            }
          }
          // Once they are available, mark as in use.
          mixer = false;
          coffeeMaker = false;
          oven = false;
        }

        // Cook the meal
        cook( 30 );

        // Mark as available and notify all other chefs. 
        synchronized ( sync ) {
          mixer = true;
          coffeeMaker = true;
          oven = true;
          sync.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
