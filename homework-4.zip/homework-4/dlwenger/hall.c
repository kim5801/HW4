/**
 * @file hall.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * Source file for the hall monitor which allocates and frees space from the hall.
 * 
 */
#include "hall.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/syscall.h>
#include <pthread.h>

char * hall;
int hallSize;
pthread_mutex_t monitor = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;


void initMonitor(int n)
{
    hallSize = n;
    hall = (char *)malloc((n + 1) * sizeof(char));
    memset(hall, '*', n);
    hall[n] = '\0';
}

void destroyMonitor()
{
    free(hall);
    pthread_mutex_destroy(&monitor);
    pthread_cond_destroy(&cond);
}
/**
 * checks if there is enough space to fit a group with a certain width in the hall.
 * 
 * @param width the width of the group
 * @return int index of starting location the group can be fit in or -1 if the group cannot be fit.
 */
static int spaceCheck(int width) {
    int currentFreeSize = 0;
    for (int i = 0; i < hallSize; i++) {
        if ( hall[i] == '*') {currentFreeSize++;}
        else {
            currentFreeSize = 0;
        }
        if (currentFreeSize == width){
            
            return i + 1 - currentFreeSize;
        }
    }
    return -1;
}

int allocateSpace(char const *name, int width)
{
    pthread_mutex_lock(&monitor);
    int start = spaceCheck(width);
    if (start == -1) {
        printf("%s waiting: %s\n", name, hall);
    }
    while (start == -1) {
        
        pthread_cond_wait(&cond, &monitor);
        start = spaceCheck(width);
    }
    
    for (int j = start; j < start + width; j++){
        hall[j] = name[0];
    }
    printf("%s allocated: %s\n", name, hall);
    pthread_mutex_unlock(&monitor);
    return start;

}

void freeSpace(char const *name, int start, int width)
{
    pthread_mutex_lock(&monitor);
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }
    printf("%s freed: %s\n", name, hall);
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&monitor);

}
