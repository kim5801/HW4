/** 
    @file hall.c
    @author Caleb Rollins (ccrollin)
    This program simulates a large event center that has a giant hall
    that has n individual spaces that make up the hall. Given a hall of length n
    (specified by the user at run-time) it can be split up into smaller section based on dividers
    that can be added or removed between the various spaces. An organization can ask
    for a space by requesting how many m spaces they need in order to have a meeting.
    Once an organization is done using their m spaces they can release it back to the pool
    of other available spaces to fulfill the requests of other organizations that are waiting
    for a meeting space.
*/

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>

// Here we have our static global variables that maintain state about the hall at any given time

// A variable to keep track of how many spaces in the hall at a certain time are filled up
static int numFilled;

// A variable to keep track of how many n spaces this instance of a hall contains
static int nSpaces;

// A string that represents the current allocation status of the spaces to organizations
// If a space is empty then it is denoted with an '*' character while if a space is occupied
// it is denoted with the first character of the name of the organization that has it
static char *allocation;

// We maintain one central lock for mutual exclusion when threads attempt to access
// critical areas of the code that need to maintain synchronization
static pthread_mutex_t monitorLock;

// We maintain two monitor condition variables to signal other threads
// or make a thread wait based off the condition value
static pthread_cond_t openCondition; // A condition variable for when there is now open space
static pthread_cond_t filledCondition; // A condition variable for when there is now a filled space

// Initialize the monitor as a hall with n spaces that can be partitioned off
// State for numFilled, nSpaces, and the allocation string are setup here in
// addition to the typical monitor constructs of a mutex (binary semaphore) and
// condition variables
void initMonitor( int n )
{
    numFilled = 0;
    nSpaces = n;
    allocation = ( char * ) malloc( sizeof( char ) * ( n + 1 ));
    for ( int i = 0; i < n; i++ ) {
        *( allocation + i ) = '*';
    }
    *( allocation + n ) = '\0';
    pthread_mutex_init( &monitorLock, NULL );
    pthread_cond_init( &openCondition, NULL );
    pthread_cond_init( &filledCondition, NULL );
}

// Destroy the monitor, freeing resources it uses
// Here we specifically free the dynamic heap memory for our
// allocation string, the mutex, and the two condition variables
void destroyMonitor()
{
    free( allocation );
    pthread_mutex_destroy( &monitorLock ); // Found on linux man pages, section 3
    pthread_cond_destroy( &openCondition ); // Found on linux man pages, section 3
    pthread_cond_destroy( &filledCondition ); // Found on linux man pages, section 3
}

// This is a simple helper method that will check our allocation string
// for if a vacated space exists that can accommodate a request of m size (width variable)
// We return true if a space that can be filled exists or false if the opposite is true
// This function also takes to a pointer that is set to be the starting index of the segment that
// is identified to be available
static bool spaceExists( int width, int *startIdx )
{
    bool sequenceFound = true;
    for ( int i = 0; i < strlen( allocation ); i++ ) {
        for ( int j = i; j < i + width; j++ ) {
            if ( *( allocation + j ) != '*' ) {
                sequenceFound = false;
                break;
            }
        }
        if ( sequenceFound ) {
            *startIdx = i;
            break;
        }
        if ( i != strlen( allocation ) - 1 ) {
            sequenceFound = true;
        }
    }
    return sequenceFound;
}

// Called when an organization wants to reserve the given number m (width) of contiguous
// spaces in the hall. This function returns the index of the left-most (lowest-numbered)
// end of the space allocated to the organization
int allocateSpace( char const *name, int width )
{
    pthread_mutex_lock( &monitorLock );

    int startIdx;
    int timesWaiting = 0;

    // Block until we find an open slot
    while ( numFilled == nSpaces || !( spaceExists( width, &startIdx ))) {
        if ( timesWaiting == 0 ) {
            printf( "%s waiting: %s\n", name, allocation );
        }
        pthread_cond_wait( &openCondition, &monitorLock );
        timesWaiting++;
    }

    // Allocate an organization in the hall
    for ( int i = startIdx; i < startIdx + width; i++ ) {
        *( allocation + i ) = *name;
    }
    numFilled += width;
    printf( "%s allocated: %s\n", name, allocation );

    // Wake anyone waiting on a filled slot
    pthread_cond_signal( &filledCondition );
    pthread_mutex_unlock( &monitorLock );
    return startIdx;
}

// In this function we release the allocated spaces from the index
// held by the start variable up to and including index of value start + width - 1
void freeSpace( char const *name, int start, int width )
{
    pthread_mutex_lock( &monitorLock );

    // Block until an organization is done to free a slot
    while ( numFilled == 0 ) {
        pthread_cond_wait( &filledCondition, &monitorLock );
    }

    // Remove organization from their space
    for ( int i = start; i < start + width; i++ ) {
        *( allocation + i ) = '*';
    }
    numFilled -= width;

    // Wake anyone waiting on an available slot
    pthread_cond_signal( &openCondition );
    pthread_mutex_unlock( &monitorLock );
    printf( "%s freed: %s\n", name, allocation );
}
