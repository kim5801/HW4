import java.util.Random;

// This is a different version of our starter Kitchen.java that was provided.
// In this java program each chef quickly checks that they can take all the appliances they
// need in order to produce a dish (ie. the appliances are not in use by another chef)
// Then, if the chef can take all the appliances they need at that time (they are all free) they
// start cooking. If one or more of the appliances a chef needs is in use, the thread will block until it is available.
// If the only metric of concern is maximizing the number of dishes prepared, then this is the best
// synchronization solution of the three programs we made in this homework assignment.
public class TakeAll {
	
	/** To tell all the chefs when they can quit running. */
	private static boolean running = true;

	/** Superclass for all chefs.  Contains methods to cook and rest and keeps a record of how many dishes were prepared. */
	private static class Chef extends Thread {
		
		/** Number of dishes prepared by this chef. */
		private int dishCount = 0;

		/** Source of randomness for this chef. */
		private Random rand = new Random();

		/** Called after the chef has locked all the required appliances and is ready to cook for about the given number of milliseconds. */
		protected void cook( int duration ) {
			System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
			try {
				// Wait for a while (pretend to be cooking)
				Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
			}
			catch ( InterruptedException e ) {
			}
			dishCount++;
		}

		/** Called between dishes, to let the chef rest before cooking another dish. */
		protected void rest( int duration ) {
			System.out.printf( "%s is resting\n", getClass().getSimpleName() );
			try {
				// Wait for a while (pretend to be resting)
				Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
			}
			catch ( InterruptedException e ) {
			}
		}
	}

	// A set of booleans representing if each appliance is in use.
	// Changing the needed booleans before cooking prevents two
	// chefs from trying to use the same appliance at the same time.
	private static boolean griddle;
	private static boolean mixer;
	private static boolean oven;
	private static boolean blender;
	private static boolean grill;
	private static boolean fryer;
	private static boolean microwave;
	private static boolean coffeeMaker;

	// An object to provide a lock on monitor for synchronization code
	private static Object checkAppliances = new Object();

	/** Mandy is a chef needing 105 milliseconds to prepare a dish. */
	private static class Mandy extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
				    // If the appliances it needs are in use then wait until both are free
					while (microwave || coffeeMaker) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
						    // not in use. Then and only then do we continue. Otherwise we go back
						    // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
					// values to true to indicate to others that might want these appliances that they are now in use
					microwave = true;
					coffeeMaker = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 105 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
				// to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					microwave = false;
					coffeeMaker = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Edmund is a chef needing 30 milliseconds to prepare a dish. */
	private static class Edmund extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
				    // If the appliances it needs are in use then wait until both are free
					while (blender || oven || mixer) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
						    // not in use. Then and only then do we continue. Otherwise we go back
						    // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
					// values to true to indicate to others that might want these appliances that they are now in use
					blender = true;
					oven = true;
					mixer = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 30 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
                // to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					blender = false;
					oven = false;
					mixer = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
	private static class Napoleon extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
				    // If the appliances it needs are in use then wait until both are free
					while (blender || grill) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
                            // not in use. Then and only then do we continue. Otherwise we go back
                            // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
                    // values to true to indicate to others that might want these appliances that they are now in use
					blender = true;
					grill = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 60 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
                // to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					blender = false;
					grill = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Prudence is a chef needing 15 milliseconds to prepare a dish. */
	private static class Prudence extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
				    // If the appliances it needs are in use then wait until both are free
					while (coffeeMaker || microwave || griddle) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
                            // not in use. Then and only then do we continue. Otherwise we go back
                            // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
                    // values to true to indicate to others that might want these appliances that they are now in use
					coffeeMaker = true;
					microwave = true;
					griddle = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 15 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
                // to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					coffeeMaker = false;
					microwave = false;
					griddle = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Kyle is a chef needing 45 milliseconds to prepare a dish. */
	private static class Kyle extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
					// If the appliances it needs are in use then wait until both are free
					while (fryer || oven) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
                        	// not in use. Then and only then do we continue. Otherwise we go back
                        	// to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
                    // values to true to indicate to others that might want these appliances that they are now in use
					fryer = true;
					oven = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 45 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
                // to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					fryer = false;
					oven = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Claire is a chef needing 15 milliseconds to prepare a dish. */
	private static class Claire extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
					// If the appliances it needs are in use then wait until both are free
					while (grill || griddle) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
                        	// not in use. Then and only then do we continue. Otherwise we go back
                        	// to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
                    // values to true to indicate to others that might want these appliances that they are now in use
					grill = true;
					griddle = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 15 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
				// to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					grill = false;
					griddle = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Lucia is a chef needing 15 milliseconds to prepare a dish. */
	private static class Lucia extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
					// If the appliances it needs are in use then wait until both are free
					while (griddle || mixer) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
                        	// not in use. Then and only then do we continue. Otherwise we go back
                        	// to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
                    // values to true to indicate to others that might want these appliances that they are now in use
					griddle = true;
					mixer = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 15 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
                // to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					griddle = false;
					mixer = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Marcos is a chef needing 60 milliseconds to prepare a dish. */
	private static class Marcos extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
				    // If the appliances it needs are in use then wait until both are free
					while (microwave || fryer || blender) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
						    // not in use. Then and only then do we continue. Otherwise we go back
						    // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
					// values to true to indicate to others that might want these appliances that they are now in use
					microwave = true;
					fryer = true;
					blender = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 60 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
				// to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					microwave = false;
					fryer = false;
					blender = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
	private static class Roslyn extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
					// If the appliances it needs are in use then wait until both are free
					while (fryer || grill) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
						    // not in use. Then and only then do we continue. Otherwise we go back
						    // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
					// values to true to indicate to others that might want these appliances that they are now in use
					fryer = true;
					grill = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 75 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
				// to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					fryer = false;
					grill = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	/** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
	private static class Stephenie extends Chef {
		public void run() {
			while ( running ) {
				// Get the appliances this chef uses.
				synchronized (checkAppliances) {
				    // If the appliances it needs are in use then wait until both are free
					while (mixer || coffeeMaker || oven) {
						try {
						    // Once we are woken up we check that the needed appliances are ALL
						    // not in use. Then and only then do we continue. Otherwise we go back
						    // to sleep waiting for another notify
							checkAppliances.wait();
						}
						catch (InterruptedException e) {
						}
					}
					// Once ALL the needed appliances are available then we change their boolean
					// values to true to indicate to others that might want these appliances that they are now in use
					mixer = true;
					coffeeMaker = true;
					oven = true;
				}
				// Start cooking now that we have the appliances we need
				cook( 30 );

				// After we are done cooking then we can give up the appliances so we set their boolean values
				// to false to let others waiting on the appliances know that they are now available for use
				synchronized (checkAppliances) {
					mixer = false;
					coffeeMaker = false;
					oven = false;
					// We now wake up all waiting threads so they can check if they can now proceed
					checkAppliances.notifyAll();
				}
				rest( 25 );
			}
		}
	}

	public static void main( String[] args ) throws InterruptedException {
		// Make a thread for each of our chefs.
		Chef chefList[] = {
				new Mandy(),
				new Edmund(),
				new Napoleon(),
				new Prudence(),
				new Kyle(),
				new Claire(),
				new Lucia(),
				new Marcos(),
				new Roslyn(),
				new Stephenie(),
		};

		// Start running all our chefs.
		for ( int i = 0; i < chefList.length; i++ ) {
			chefList[ i ].start();
		}

		// Let the chefs cook for a while, then ask them to stop.
		Thread.sleep( 10000 );
		running = false;

		// Wait for all our chefs to finish, and collect up how much
		// cooking was done.
		int total = 0;
		for ( int i = 0; i < chefList.length; i++ ) {
			chefList[ i ].join();
			System.out.printf( "%s cooked %d dishes\n",
					chefList[ i ].getClass().getSimpleName(),
					chefList[ i ].dishCount );
			total += chefList[ i ].dishCount;
		}
		System.out.printf( "Total dishes cooked: %d\n", total );
	}
}
