//Import header and needed libraries
#include "hall.h"
#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>

//Char array hold a representation of the hall;
static char *hallArr;
//Mutex used to prevent two threads from editing at the same time
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
//Condition used to wait threads that cannot fit at the moment
static pthread_cond_t wait = PTHREAD_COND_INITIALIZER;

// Static method to get the start of a space where a thread with the given width
// could fit, returns -1 if the thread cannot fit
static int getStart(int width)
{
  int open = 0;
  int start = -1;
  //Iterates through hallArr, finding continuous empty spaces
  for (int i = 0; hallArr[i]; i++) {
    if (hallArr[i] == '*') {
      if (start == -1) {
        start = i;
      }
      open++;
    } else {
      open = 0;
      start = -1;
    }
    //Breaks if the number of open spaces is large enough
    if (open >= width) {
      break;
    }
  }
  //Ensures that the number of open spaces is large enough when the loop ends
  if (open < width) {
    start = -1;
  }

  //Returns the position the thread should start at
  return start;
}

//Method to start the monitor
void initMonitor(int n)
{
  //Dynamically allocates the hallArr to given size plus 1
  hallArr = (char *)calloc(n + 1, sizeof(char));
  //Set the array to characters signifying empty space.
  for (int i = 0; i < n; i++) {
    hallArr[i] = '*';
  }
  //Null terminator at the end to ensure it can be printed as a string
  hallArr[n] = '\0';
}

void destroyMonitor()
{
  //Free the dynamically allocated array
  free(hallArr);
  //Destroy the mutex and conditions
  pthread_mutex_destroy(&lock);
  pthread_cond_destroy(&wait);
}

int allocateSpace(char const *name, int width)
{
  //Lock as the array may be edited
  pthread_mutex_lock(&lock);

  //See if the thread can fit
  int start = getStart(width);
  if (start == -1) {
    //Print waiting message
    printf("%s waiting: %s \n", name, hallArr);
    //Ensure that the thread can fit when unblocked
    while (start == -1) {
      pthread_cond_wait(&wait, &lock);
      start = getStart(width);
    }
  }

  //Set the spaces used to the first letter of the given name
  for (int i = 0; i < width; i++) {
    hallArr[i + start] = name[0];
  }
  //Print the string showing the allocation
  printf("%s allocated: %s \n", name, hallArr);
  //Unlock as changes to the hallArr are finished
  pthread_mutex_unlock(&lock);
  //Return the location where the thread was placed
  return start;
}

// Method to free space taken up by one thread and notify waiting threads
void freeSpace(char const *name, int start, int width)
{
  //Lock as the array will be edited
  pthread_mutex_lock(&lock);
  //Set the room starting at start to start + width - 1 to empty
  for (int i = 0; i < width; i++) {
    hallArr[i + start] = '*';
  }
  //Print message showing the freed space
  printf("%s freed: %s \n", name, hallArr);
  //Unlock as changes to the hallArr are finished
  pthread_mutex_unlock(&lock);
  //Notify thread waiting for space that space was freed up
  pthread_cond_broadcast(&wait);
}