#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hall.h"

pthread_mutex_t monitor;
pthread_cond_t space;
char *hallway;

void initMonitor( int n ) {
    pthread_mutex_init( &monitor, NULL );
    pthread_cond_init( &space, NULL );
    hallway = (char *)malloc( n );
    for(int i = 0; i < n; i++) {
        hallway[i] = '*';
    }
}

void destroyMonitor() {
    pthread_mutex_destroy( &monitor );
    pthread_cond_destroy( &space );
}

int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock( &monitor );
    char *sample = (char *)malloc(width);
    for(int i = 0; i < width; i++) {
        sample[i] = '*';
    }
    char *result = strstr(hallway, sample);
    int start = 0;
    if(result == NULL) {
        printf("%s waiting: %s\n", name, hallway );
        pthread_cond_wait( &space, &monitor );
    } else {
        start = result - hallway;
    }
    
    for(int i = start; i < start + width; i++) {
        hallway[i] = name[0];
    }
    printf("%s allocated: %s\n", name, hallway );
    pthread_mutex_unlock( &monitor );
    return start;
}

void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &monitor );
    for(int i = start; i < (start + width); i++ ) {
        hallway[i] = '*';
    }
    printf("%s freed: %s\n", name, hallway );
    pthread_mutex_unlock( &monitor );
    pthread_cond_signal( &space );
}


