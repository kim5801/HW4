#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include<time.h>

// Creating a dynamically allocated list that represents the buffer for shared memory
char* hall;
/* Size of shared buffer */
int size = 0;

int first = 0; // First full slot in the buffer 
int num = 0; // number of full elements in buffer

// Lock for access to the buffer.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Condition for blocking the producer, are there empty slots.
pthread_cond_t slotsCond = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
	size = n;
	//Allocate memory based on n for the buffer
	//Buffer is an array of chars, bc organizations are chars
	hall = (char*)malloc(sizeof(char) * (size + 1));
	//Set each spot to * to indicate they are free
	for (int i = 0; i < size; i++ ) {
		hall[i] = '*';
	}
	hall[size] = '\0';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
   free(hall);
}

/**
 * Find the shortest substring of empty spots with minimum
 * length of width given.
 *
 * Returns the starting index of substring.
 */
static int findShortest(char const *hall, int width) {

	char word[width+1];
	for (int i = 0; i < width; i++ ) {
		word[i] = '*';
	}
	word[width] = '\0';
	
	char *ptr = strstr(hall, word);

	return ptr - hall;
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

	char word[width+1];
	for (int i = 0; i < width; i++ ) {
		word[i] = '*';
	}
	word[width] = '\0';

	pthread_mutex_lock( &mon );   // Enter the monitor		

	// Block until there's a slot with at least width *
	while ( strstr(hall, word) == NULL ) {
		//Print message to indicate waiting for space
		printf("%s waiting: %s\n", name, hall);
		pthread_cond_wait( &slotsCond, &mon );		
	}
	// Wake any organizations waiting for a space
	pthread_cond_signal( &slotsCond );
	
	//Find start of smallest substring of empty spots
	int start = findShortest(hall, width);

	// Allocate the spaces for organizations
	for (int i = 0; i < width; i++ ) {
		hall[start + i] = name[0];
	}
	printf("%s allocated: %s\n", name, hall);
	
	pthread_mutex_unlock( &mon );  // Leave the monitor
	
	return start;
}

/** Release the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {

	pthread_mutex_lock( &mon );   // Enter the monitor		

	// Allocate the spaces for organizations
	for (int i = start; i < start + width; i++ ) {
		hall[i] = '*';
	}
	
	// Wake any organizations waiting for a space
	pthread_cond_signal( &slotsCond );
	printf("%s freed: %s\n", name, hall);
	
	pthread_mutex_unlock( &mon );  // Leave the monitor
}