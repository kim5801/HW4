#include <stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<stdbool.h>

// Pointer to character array representing hall
static char *hall;
// Size of the hall
static int size;
// Lock for access to the hall
static pthread_mutex_t monitor = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking until an appropriately sized section in the hall is free
static pthread_cond_t sizeCond = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned off. */
void initMonitor( int n ) {
  // Allocate enough space for our hall of size n, with a null terminator
  hall = (char *)malloc(sizeof(char) * (n + 1) );
  // Set our size variable
  size = n;
  // Set all our hall spaces to our free symbol, '*'
  for (int i = 0; i < n; i++ ) {
    hall[i] = '*';
  }
  // Add our null terminator
  hall[n] = '\0';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  // Free the hall that we malloc-ed earlier
  free( hall );
  // Destroy our mutex/monitor
  pthread_mutex_destroy( &monitor );
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  // Character to put in the hall, indicating reservations
  char reserve = name[0];
  // Start index
  int start = 0;
  // Total contiguous free spaces we've found
  int contiguous = 0;
  // Boolean for if we've printed the waiting message already
  bool printed = false;
  // Enter the monitor
  pthread_mutex_lock( &monitor );
  // While we have fewer contiguous free spaces than the width
  while( contiguous < width ) {
    // Start the temp beginning index at an invalid number
    int tempStart = -1;
    // Iterate through the hall, checking for free spaces
    for( int i = 0; i < size; i++ ) {
      // If this is a free space and we haven't found a start yet, this is it!
      if( (hall[i] == '*') && (tempStart == -1) ) {
        // Set the temp starting point
        tempStart = i;
        // If this space is enough to satisfy our width, we can get out here
        if( contiguous + 1 >= width ) {
          // Set the start index
          start = tempStart;
          // Increment the contiguous count
          contiguous++;
          // Bye!
          break;
        }
        // Otherwise, increment contiguous
        contiguous++;
      }
      // If this is a free spot and we've already found where it starts, go here
      else if( hall[i] == '*' ) {
        // If this space is enough to satisfy our width, we can get out here
        if( contiguous + 1 >= width ) {
          // Set the start index
          start = tempStart;
          // Increment the contiguous count
          contiguous++;
          // Bye!
          break;
        }
        // Otherwise, increment contiguous
        contiguous++;
      }
      // If it's not free, we may have broken our streak, let's reset everything
      else {
        tempStart = -1;
        contiguous = 0;
      }
    }
    // If we have enough contiguous free space, exit here
    if( contiguous >= width ) {
      break;
    }
    // If we haven't already printed the waiting message, let's do it
    if( !printed ) {
      printf( "%s waiting: %s\n", name, hall );
      // Set the boolean so we don't do it again
      printed = true;
    }
    // Wait for a signal about free space
    pthread_cond_wait( &sizeCond, &monitor );
  }
  // Let's reserve the spaces now, from start up until start + width (not including)
  for( int j = start; j < (start + width); j++ ) {
    // Set the space to the first character in the group's name
    hall[j] = reserve;
  }
  // Print the allocation message
  printf( "%s allocated: %s\n", name, hall );
  // Exit the monitor
  pthread_mutex_unlock( &monitor );
  // Return the start index
  return start;
}

/** Release the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  // Enter the monitor
  pthread_mutex_lock( &monitor );
  // Iterate through the hall, from start up until start + width (not including)
  for( int i = start; i < (start + width); i++ ) {
    // Set it back to the free symbol
    hall[i] = '*';
  }
  // Print the freed message
  printf( "%s freed: %s\n", name, hall );
  // Signal the other threads to try and get some space
  pthread_cond_signal( &sizeCond );
  // Exit the monitor
  pthread_mutex_unlock( &monitor );
}
