/**
 * @file hall.c
 * @author Ethan Treece (eltreece)
 * 
 * This program keeps track of a hallway containing n rooms which can
 * be seperated or opened up with partitions in between. Conferences are
 * scheduled which request a certain amount of rooms and can use those rooms
 * as long as they want. Conferences will free the rooms once they are done,
 * they must wait until a consecutive number of the requested rooms are available
 * in the hall.
 * 
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>

// array of chars keeping track of hall
static char *hall;

// number of rooms in hall
static int size = 0;

// number of rooms currently occupied
static int occupied = 0;

// // Lock for access to the buffer.
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t notFull = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    hall = malloc(n * sizeof(char));
    size = n;
    for (int i = 0; i < size; i++) {
        hall[i] = '*';
    }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free(hall);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    
    pthread_mutex_lock(&mutex);
    if (size - occupied < width) {
        printf("%s waiting: %s\n", name, hall);
    }
    while (size - occupied < width) {
        pthread_cond_wait(&notFull, &mutex);
    }
    int count = 0;
    while (1) {
        for (int i = 0; i < size; i++) {
            
            if (hall[i] == '*') {
                count++;
            } else {
                count = 0;
            }
            if (count == width) {
                int start = i - width + 1;
                for (int j = start; j < start + width; j++) {
                    hall[j] = name[0];
                }
                printf("%s allocated: %s\n", name, hall);
                occupied += width;
                pthread_mutex_unlock(&mutex);
                return start;
            }
        }
    }
    printf("failure: %s\n", name);
    pthread_mutex_unlock(&mutex);
    return 0;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock(&mutex);
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }
    occupied -= width;
    printf("%s freed: %s\n", name, hall);
    pthread_cond_signal(&notFull);
    pthread_mutex_unlock(&mutex);
}