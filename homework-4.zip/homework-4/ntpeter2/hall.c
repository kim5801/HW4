/**
 * program for allocating space within a character array
 * different organizations may require different space, and this
 * program will wait until there is sufficient space, then it will be 
 * allocated
 * @author Nolan Peters
 * @file hall.c
 */
#include "hall.h"
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdbool.h>

char *hall; // array of characters or the "hall"
pthread_mutex_t lock; // lock to ensure mutual exclusion
static int largestSpace = 0; // keeps track of the largest open space at any time
static int size = 0; // size of hall
pthread_cond_t checkAgain = PTHREAD_COND_INITIALIZER; // condition variable to notify any organizations when space is freed


// updates the largest free space within the hall
void updateLargestSpace() {
    int tempResult = 0;
    int result = 0;
    for (int i = 0; i < size; i++) {
        if (hall[i] == '*') {
            tempResult++;
        } else {
            if (tempResult > result) {
                result = tempResult;
            }
            tempResult = 0;
        }
        
    }
    
    if (tempResult > result) {
        result = tempResult;
    }
    
    largestSpace = result;
}

/**
 * initializes montior and hall of size n
 * @param n size of hall to be created
 */
void initMonitor( int n ) {
    hall = malloc( n + 1 );
    hall[n] = '\0';

    for (int i = 0; i < n; i++) {
        hall[i] = '*';
    }
    
    largestSpace = n;
    size = n;
    pthread_mutex_init( &lock, NULL );
}

//destroys hall
void destroyMonitor() {
    free( hall );
}

/**
 * allocates space for an organization
 * @param name name of organization
 * @param width amount of space needed
 * @return first index where organization is allocated
 */
int allocateSpace( char const *name, int width ) {

    int printvar = 0;
    bool spaceFound = true;
    
    pthread_mutex_lock( &lock );
    while( width > largestSpace ) {
        if (printvar == 0) {
            printf("%s waiting: %s\n", name, hall);
            printvar++;
        }
        pthread_cond_wait( &checkAgain, &lock );
    }
    
    
    for (int i = 0; i < size; i++) {
        if (hall[i] == '*') {
            spaceFound = true;
            for (int j = 1; j < width; j++) {
                if (hall[i + j] != '*') {
                    i += j;
                    spaceFound = false;
                    break;
                }
           
            }
            
            if (!spaceFound) {
                continue;
            }
            
            for (int k = i; k < i + width; k++) {
                hall[k] = name[0];
            }
            
            printf("%s allocated: %s\n", name, hall);
            updateLargestSpace();
            pthread_mutex_unlock( &lock );
            return i;
        }
    }
    
    pthread_mutex_unlock( &lock );
    return -1;

}

/**
 * frees space when an organization is done
 * @param name name of organization
 * @param start location of organization
 * @param width size of space allocated
 */
void freeSpace( char const *name, int start, int width ) {

    pthread_mutex_lock( &lock );
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }
    
    updateLargestSpace();
    printf("%s freed: %s\n", name, hall);
    pthread_cond_signal( &checkAgain );
    pthread_mutex_unlock( &lock );
}
