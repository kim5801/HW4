#include "hall.h"
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdio.h>

#define MAX_AGE_DISPARITY 99

//storage for the hall
static char *hall;

//total number of rooms
static int numRooms;

static int oldestThreadAge = 0;

// Lock for access to the hall.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the room allocator
pthread_cond_t allocateCond = PTHREAD_COND_INITIALIZER;


void initMonitor( int n ) {
    hall = (char *)malloc( (n + 1) * sizeof(char) );
    for (int i = 0; i < n; i++) {
        hall[i] = '*';
    }
    hall[n] = '\0';
    numRooms = n;
}

//free the struct
void destroyMonitor() {
    free(hall);
}

//returns the start index of a space that is at least the parameter width.
//if a big enough space cannot be found, -1 is returned.
int findSpace(int width) {
    int currNumContig = 0;
    for (int i = 0; i < numRooms; i++) {
        if (hall[i] == '*') {
            currNumContig++;
        } else { //number of contiguous empty rooms stops at this room
            currNumContig = 0; //reset the current number of contiguous rooms
        }

        if (currNumContig == width) {
            return i - currNumContig + 1;
        }
    }
    return -1;
}

int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock(&mon);
    
    int threadAge = 0;
    //attempt to find a large enough space
    int allocationSpace = findSpace(width);
    while ((allocationSpace == -1) || oldestThreadAge - threadAge > MAX_AGE_DISPARITY) {
        if (threadAge == 0) { //print the first time we enter
            printf("%s waiting: %s\n", name, hall); //need this
        }
        pthread_cond_wait(&allocateCond, &mon);
        threadAge++; //another thread released this one so increment age **THIS DOESNT WORKS SINCE IT IS ACTUALLY THE RELEASE THAT IS SIGNALLING, NOT ANOTHER ALLOCATE
        if (threadAge > oldestThreadAge) {
            oldestThreadAge = threadAge;
        }
        allocationSpace = findSpace(width); //try to find the largest space again
    }
    for (int i = allocationSpace; i < allocationSpace + width; i++) {
        hall[i] = name[0];
    }
    printf("%s allocated (%d): %s\n", name, threadAge, hall); //need this
    
    pthread_mutex_unlock(&mon);
    return allocationSpace;
}

void freeSpace( char const *name, int start, int width ) {
    //lock to change the hall
    pthread_mutex_lock(&mon);
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }
    printf("%s freed: %s\n", name, hall); //need this

    //signal cuz there is potentially enough space to allocate
    pthread_cond_signal(&allocateCond);

    pthread_mutex_unlock(&mon);
}