#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// Lock for access to the buffer.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking if there is currently no slot big enough
pthread_cond_t widthCond = PTHREAD_COND_INITIALIZER;

char * hall;
int hallSize;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    hall = (char *)malloc(sizeof(char) * n);
    hallSize = n;
    for(int i = 0; i < n; i++) 
        hall[i] = '*';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free(hall);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    pthread_mutex_lock(&mon);
    int freeSize = 0;
    int i;
    while(freeSize < width) {
        freeSize = 0;
        for(i = 0; i < hallSize; i++) {
            if(hall[i] == '*') {
                freeSize++;
                if(freeSize >= width) {
                    i++;
                    break;
                }
            } else {
                freeSize = 0;
            }
        }
        if(freeSize < width) {
            printf("%s waiting: %s\n", name, hall);
            pthread_cond_wait(&widthCond, &mon);
        }
    } 
    for(int j = i; j > i - width; j--)
        hall[j] = name[0];
    printf("%s allocated: %s\n", name, hall);
    pthread_mutex_unlock(&mon);
    return i - width + 1;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock(&mon);
    for(int i = start; i < start + width; i++)
        hall[i] = '*';
    printf("%s freed: %s\n", name, hall);
    pthread_cond_signal(&widthCond);
    pthread_mutex_unlock(&mon);
}
