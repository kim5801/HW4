/**
 * @file hall.c
 * @author Christina Albores (ccalbore)
 * @brief The partitions in the hall can be used to break it up into separate spaces.
 * So it can be used by multiple organizations at the same time, each using a
 * one or more of the spaces, with partitions between them. This program creates the
 * the monitor, destroys the monitor, allocates space for a given organization, and frees
 * space held by an organization. It prevents deadlocks by using condition variables and a mutex.
 * @date 2022-10-27
 * 
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "hall.h"

// Lock for access to the buffer.
static pthread_mutex_t monitor;
// Condition for blocking the consumer, are there organizations to be freed.
static pthread_cond_t freedSpace;
// Condition for blocking the producer, is there space for the organization.
static pthread_cond_t allocedSpace;
// The buffer that holds the current organization
static char *hall = NULL;
// The size of the hall
static int hallSize;
// The number of spaces available
static int maxSpaceAvail;


/**
 * @brief This function initializes the monitor, allocating the hall and initializing the
 * condition variables and mutex. It also sets the static global maxSpaceAvail and hallSize.
 * It also fills the hall with '*' chars, indicating free spaces.
 * 
 * @param n the total width of the hall, the number of spaces it contains.
 */
void initMonitor( int n )
{
    // Initalize the mutex to default
    pthread_mutex_init(&monitor, NULL);
    // Initalize the condition variable for freed space to default
    pthread_cond_init(&freedSpace, NULL);
    // Initalize the condition variable for allocated space to default
    pthread_cond_init(&allocedSpace, NULL);
    // Set the number of spaces available to starting size
    maxSpaceAvail = n;
    // Set the starting size static global variable
    hallSize = n;

    // Malloc the hall string to hold size n chars
    hall = (char *)malloc(n * sizeof(char));

    // Fill the string with '*'
    for (int i = 0; i < n; i++) {
        hall[i] = '*';
    }
}


/**
 * @brief Destroys the monitor, freeing the mutex, condition variables and
 * hall string. 
 */
void destroyMonitor()
{
    // Destroy the mutex
    pthread_mutex_destroy(&monitor);
    // Destroy the condition variable for freed space
    pthread_cond_destroy(&freedSpace);
    // Destroy the condition variable for allocated space
    pthread_cond_destroy(&allocedSpace);
    // Free the hall string
    free(hall);
}

/**
 * @brief Helper function that takes in the requested width and returns the index of
 *  the left-most (lowest-numbered) end of the space allocated to the organization.
 * 
 * @param width the requested given number (width) of contiguous spaces in the hall
 * @return int startIndex the starting index of the organization in the hall
 */
int checkWidthSpace(int width)
{
    // Set the size counter to 0
    int sizeCount = 0;
    // Set the start index to -1
    int startIndex = -1;
    // For each char in hall, find the requested width and return the starting index  
    for (int i = 0; i < hallSize; i++) {
        if (hall[i] == '*') {
            sizeCount++;
            if (sizeCount == width) {
                startIndex = i - (width - 1);
                break;
            }
        } else {
            // Reset the size count if incounter non-'*'
            sizeCount = 0;
        }
    }
    return startIndex;
}

/**
 * @brief Updates the maxSpaceAvail variable after allocation or freeing.
 */
void updateMaxSpaceAvail()
{
    // Set the size counter to 0
    int sizeCount = 0;
    // Set the maz size counter to 0
    int maxSize = 0;
    // For each char in hall, find the biggest space available in the string
    for (int i = 0; i < hallSize; i++) {
        if (hall[i] == '*') {
            sizeCount++;
            if (sizeCount >= maxSize) {
                maxSize = sizeCount;
            }
        } else {
            sizeCount = 0;
        }
    }
    // Update the maxSpaceAvail to the max size
    maxSpaceAvail = maxSize;
}

/**
 * @brief Called when an organization wants to reserve the given number (width) of contiguous spaces in the hall.
 * Returns the index of the left-most (lowest-numbered) end of the space allocated to the organization. 
 * 
 * @param name the name of the organization
 * @param width the requested given number (width) of contiguous spaces in the hall
 * @return int start the starting index of the organization in the hall
 */
int allocateSpace( char const *name, int width )
{
    // Enter the monitor
    pthread_mutex_lock( &monitor );

    // Checks if the organization is already waiting
    int waitingIdx = 0;
    
    while (maxSpaceAvail < width) {
        if (waitingIdx == 0) {
            printf("%s waiting: %s\n", name, hall);
            waitingIdx++;
        }
        // Block until there's a freed space that fits the size
        pthread_cond_wait( &freedSpace, &monitor );
    }
    // Get the starting index
    int start = checkWidthSpace(width);

    // Set the organization in the hall
    for (int i = start; i < width + start; i++) {
        hall[i] = name[0];
    }
    // Update the maxSpaceAvail
    updateMaxSpaceAvail();

    printf("%s allocated: %s\n", name, hall);

    // Signal allocated. Wake any consumers waiting on an allocated space
    pthread_cond_signal( &allocedSpace );
    // Leave the monitor
    pthread_mutex_unlock( &monitor );
    return start;
}

/**
 * @brief Releses the allocated spaces from index start up to (and including) index start + width - 1.
 * 
 * @param start the index of the leftmost space allocated to the thread
 * @param name the name of the thread’s organization
 * @param width the number of contiguous spaces allocated to the thread
 */
void freeSpace( char const *name, int start, int width )
{
    // Enter the monitor.
    pthread_mutex_lock( &monitor );
    // While there are no allocated spaces
    while ((hallSize - maxSpaceAvail) == 0) {
        // block until there's an allocated space
        pthread_cond_wait( &allocedSpace, &monitor );
    }
    // The end of the organization's space
    int n = width + start;
    for (int i = start; i < n; i++) {
        hall[i] = '*';
    }
    // Update the maxSpaceAvail
    updateMaxSpaceAvail();
    printf("%s freed: %s\n", name, hall);

    // Signal allocated. Wake any producers waiting on a freed space
    pthread_cond_signal( &freedSpace );
    // Leave the monitor
    pthread_mutex_unlock( &monitor );
}
