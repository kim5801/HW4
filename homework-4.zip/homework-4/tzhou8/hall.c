/**
 * @file hall.c
 * @author Tong Zhou
 * @date 2022-10-28
 * 
 * This program use POSIX mutex and condition variables to implement 
 * part of a simulation of conference hall allocation system.
 * 
 */

#include <stdio.h>
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <unistd.h>    // for sleep/usleep

/** Array to store memory and simulate a conference hall */
char *hallArr;

/** Array to store the contiguous space available at each index of the hallArray.
    This array simplifies implementation and ensures our functions run at O(n) time complexity. */
int *available;

/** Size of the conference hall */
int size;

/** Maximum avaliable contiguous space in the hall */
int max;

/** lock for accessing the critical section */
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/** condition for lock to wait */
pthread_cond_t addCond = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {

    hallArr = (char *)malloc( sizeof(char) * n );
    available = (int *)malloc( sizeof(int) * n );
    size = n;

    for(int i = 0; i < n; i++) {

        hallArr[i] = '*';
        available[i] = n - i;

    }

    max = n;
    
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {

    free(hallArr);
    free(available);

}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

    pthread_mutex_lock( &mutex );   // Enter the monitor
    int start = -1;

    int printOnce = 0;

    // Wait until theres space in the hall
    while(max < width) {

        if(printOnce == 0) {

            //printf("max: %d\n", max);
            printf("%s waiting: %.*s\n", name, size, hallArr);
            printOnce++;
        }


        pthread_cond_wait( &addCond, &mutex );
    }

    for(int i = 0; i < size; i++) {

        if(available[i] >= width) {
            start = i;
            break;
        }

    }

    // Subtract all previous availablity by the width
    for(int i = 0; i < start; i++) {

        if(available[i] != 0) {
            available[i] -= width;
        }

    }

    // Subtract max by width to account for new added space
    max -= width; 

    // Change the availability of allocated space to 0, allocate memory to the hall
    for(int i = start; i < start + width; i++) {

        hallArr[i] = name[0];
        available[i] = 0;
    }

    // Since we subtracted max by width, only possible greater maxs are after the start idx
    for(int i = start + width; i < size; i++) {    // These last three for loops combined is 1 complete iteration of the array, O(n)

        //printf(" %d", available[i]);
        if(available[i] > max) {
            max = available[i];
        }

    }


    pthread_cond_signal( &addCond );
    pthread_mutex_unlock( &mutex ); 
    printf("%s allocated: %.*s\n", name, size, hallArr);

    return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {

    pthread_mutex_lock( &mutex ); 
    for(int i = start; i < start + width; i++) {

        hallArr[i] = '*';
        available[i] = -1;
    }

    //counter to reassign availability
    int counter = 1;

    for(int i = size - 1; i >= 0; i--) {

        //reassign availability of each index to the array
        if(available[i] != 0) {
            available[i] = counter;
            counter++;
        }
        else
        {
            counter = 1;
        }

        if(available[i] > max) {
            max = available[i];
        }


    }

    pthread_cond_signal( &addCond );
    pthread_mutex_unlock( &mutex ); 
    printf("%s freed: %.*s\n", name, size, hallArr);
}