#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "hall.h"
#include <stdbool.h>
#include <pthread.h>


//locks the monitor when a thread asks for spaces to be allocated
pthread_mutex_t lock;

//condition variable when a thread has to wait for enough contiguous space to open up
pthread_cond_t waitCond;

//char pointer to the first space in the hall
char *hall;

//number of spaces the hall contains
int hallSpaces;

void initMonitor( int n ) {  
  pthread_mutex_init( &lock, NULL ); //initialize mutex lock
  pthread_cond_init( &waitCond, NULL ); //initialize condition variable
  hallSpaces = n;
  
  hall = ( char * )malloc( sizeof( char ) * n );
  for ( int i = 0; i < n; i++ ) {
    hall[ i ] = '*'; // '*' indicates a free space
  }
}

void destroyMonitor() {
  free( hall );
}

int allocateSpace( char const *name, int width ) { 
 
 
  int start; // marks start of free spaces
  int end;   // marks end of free spaces
  int count; // count how many contiguous free spaces there are
  bool foundFree = false;
  
  bool hasWaited = false;
  while ( !foundFree ) {
    pthread_mutex_lock( &lock );
    start = 0;
    count = 0;
    
    for( int i = 0; i < hallSpaces; i++ ) {
               
      if ( hall[ i ] == '*' ) { // if a space is free count it        
        if ( count == 0 ) { //first freed space is marked as start of partition
          start = i;
        }
        count++;
      } else { // reset spaces        
        count = 0;
      }      
      if ( count == width ) { // found the first wide enough contiguous space
        foundFree = true;
        end = i;
        break;
      }       
    }
      
    //looked through hall and found nothing wide enough
    //wait for a space to free up and check again    
    if( !foundFree ) {    
      if( !hasWaited ) { //waiting message should only print once
        printf( "%s waiting: %s\n", name, hall );
        hasWaited = true;
      } 
      pthread_cond_wait( &waitCond, &lock );   
                
    }
    pthread_mutex_unlock( &lock );    
            
  }
  
  for ( int i = start; i < end + 1; i++ ) { // marking rooms as in use 
    hall[ i ] = name[ 0 ]; 
  }  
  
  printf( "%s allocated: %s\n", name, hall );  
  
  return start;
}

void freeSpace( char const *name, int start, int width ) {
  for ( int i = start; i < ( start + width ); i++ ) { //mark all of the spaces previously in use as freed
    hall[ i ] = '*';
    pthread_cond_broadcast( &waitCond ); //as soon as a room opens up, alert all the threads waiting
  }
  
  printf( "%s freed: %s\n", name, hall );
 
}
