#include "hall.h"
#include <stdbool.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/** Mutex lock for the monitor */
pthread_mutex_t monitorAccess;
/** Condition variable for thread waiting */
pthread_cond_t spaceWait;

/** Pointer for the array holding the spaces being allocated */
char *spaceArray;
/** Number of spaces in the array */
int numSpaces = 0;

/**
  * Initializes the memory needed for hall space and
  * the array used to track the status of the available
  * spaces
  * @param n spaces needed for the hall
  */
void initMonitor(int n)
{
  pthread_mutex_init( &monitorAccess, NULL );
  pthread_cond_init( &spaceWait, NULL );
  numSpaces = n;
  // Dynamically allocated array
  spaceArray = ( char* )malloc( n * sizeof( char ) );
  for ( int i = 0; i < n; i++ ) {
    spaceArray[ i ] = '*';
  }
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
  free( spaceArray );
}

/**
 * Finds the largest contiguous space available 
 * that can be allocated
 * @return the largest number of spaces available
 */
int largestSpace() 
{
  int max = 0;
  for ( int i = 0; i < numSpaces; i++ ) {
    int currentSpaces = 0;
    if ( spaceArray[ i ] == '*' ) {
      currentSpaces++;
      for ( int j = i + 1; j < numSpaces; j++ ) {
        if ( spaceArray[ j ] != '*' ) {
          break;
        }
        currentSpaces++;
        // Checks and updates max each time the space count is incremented
        max = currentSpaces > max ? currentSpaces : max;
      }
    }
  }
  return max;
}

/** 
  * Called when an organization wants to reserve the given number
  * (width) of contiguous spaces in the hall.  Returns the index of
  * the left-most (lowest-numbered) end of the space allocated to the
  * organization. 
  * @param name organization name for which space is being allocated
  * @param width spaces needed
  * @return index of the left-most allocated space
  */
int allocateSpace(char const *name, int width)
{
  int start = 0;
  pthread_mutex_lock( &monitorAccess );
  char organization = name[0];
  // Tracks whether the wait statement has already been printed
  bool printed = false;
  // Makes a thread wait if there aren't enough spaces for allocation
  while ( largestSpace() < width ) {
    if ( !printed ) {
      printf( "%s waiting: %s\n", name, spaceArray );
      printed = true;
    }
    pthread_cond_wait( &spaceWait, &monitorAccess );
  }
  // Updates the allocated spaces for the organization
  for ( int i = 0; i < numSpaces; i++ ) {
    bool found = true;
    if ( spaceArray[ i ] == '*' ) {
      start = i;
      // Checks that space is being allocated in correct position
      int idx = i;
      for ( int j = 0; j < width; j++ ) {
        if ( spaceArray[ idx++ ] != '*' ) {
          found = false;
        }
      }
      // Assigns spaces once position is verified
      idx = i;
      if ( found ) {
        for ( int j = 0; j < width; j++ ) {
          spaceArray[ idx++ ] = organization;
        }
        printf( "%s allocated: %s\n", name, spaceArray );
        break;
      }
    }
  }
  pthread_mutex_unlock( &monitorAccess );
  return start;
}

/** 
 * Relese the allocated spaces from index start up to (and including)
  * index start + width - 1. Prints out report of updated space allocation. 
  * @param name organization name
  * @param start start index
  * @param width number of spaces being released 
  */
void freeSpace(char const *name, int start, int width)
{
  for ( int i = start; i < start + width; i++ ) {
    spaceArray[ i ] = '*';
  }
  // Allows thread to check for more allocated space
  pthread_cond_broadcast( &spaceWait );
  printf( "%s freed: %s\n", name, spaceArray );
}