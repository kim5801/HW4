
#include <pthread.h>   // for pthreads
#include <stdlib.h>    // for exit
#include <stdbool.h>   // for bool
#include <unistd.h>    // for sleep
#include <stdio.h>

//stores the contents
static char *currAllocation;
//the number of spaces in currAllocation (above)
static int spaces;
// Lock for access to the 
static pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the consumer, are there some items.
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;


/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
  currAllocation = (char *)malloc(sizeof(char) * n + 1 );
  //null termintor helps
  currAllocation[n+1] = '\0';
  //all spaces are open at startup -> *
  for (int i = 0; i < n; i++) {
    currAllocation[i] = '*';
  }
  spaces = n;
  
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {

  //clear anything that was needed for the heap
  free(currAllocation);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall. Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  
  pthread_mutex_lock( &mon );   // Enter the monitor
  // to find if we will need to wait or not
  bool isAvaliable = false;
  bool isContinious = true;
  bool isMaxTooLarge = true;
  
  int start = 0; //will be returned
  
  //keep wait until is valid
  while ( !isAvaliable ) {
  
    for (int i = 0; i < spaces; i++) {
      //a possible starting index is empty
      if ( currAllocation[i] == '*' ) {
        //this is inclusive- max index
        int maxIndexToCheck = i + width - 1;
      
        //yes will fit in
        if ( maxIndexToCheck < spaces ) {
          isMaxTooLarge = false;
          for (int j = i; j <= maxIndexToCheck; j++) {
            if ( currAllocation[j] != '*' ) {
              isContinious = false;
              break; //break out of this inner loop
            }
          }
        } 
        
        //is valid
        if ( isContinious && !isMaxTooLarge ) {
          isAvaliable = true;
        }
        
        //save to global 
        if ( isAvaliable ) {
          start = i;
          char var = name[0];
          
          for ( int iAllocate = start; iAllocate <= maxIndexToCheck; iAllocate++ ) {
            currAllocation[iAllocate] = var;
          }
          break;//break out of outer loop
        }
      } // if
    } // for outer
    
    if ( !isAvaliable ) {
      printf("%s waiting: %s\n", name, currAllocation);
    
      pthread_cond_wait( &cond, &mon );

    }
  } // while -will block before going to next iteration
  
  printf("%s allocated: %s\n", name, currAllocation);
  pthread_mutex_unlock( &mon );  // Leave the monitor
  
  return start;
}



/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace ( char const *name, int start, int width ) {

  pthread_mutex_lock( &mon );   // Enter the monitor
  for ( int i = start; i <= start + width - 1; i++ ) {
    currAllocation[i] = '*';
  }
  
  printf("%s freed: %s\n", name, currAllocation);
  // Wake any consumers waiting on an item.
  pthread_cond_signal( &cond );
  pthread_mutex_unlock( &mon );  // Leave the monitor
  
  
}
