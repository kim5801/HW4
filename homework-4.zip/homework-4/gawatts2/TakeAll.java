import java.util.Random;

public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private  int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }




  //true if are avaliable to use
  private static boolean isGriddleA = true;
  private static boolean isMixerA = true;
  private static boolean isOvenA = true;
  private static boolean isBlenderA = true;
  private static boolean isGrillA = true;
  private static boolean isFryerA = true;
  private static boolean isMicrowaveA = true;
  private static boolean isCoffeemakerA = true;


  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {

          while ( !isMicrowaveA || !isCoffeemakerA  ) {
            try {
              this.wait();
            } catch ( InterruptedException e) {
            }
          }
          isMicrowaveA = false;
          isCoffeemakerA = false;
        }
        cook( 105 );
        synchronized ( this ) {
          isMicrowaveA = true;
          isCoffeemakerA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isBlenderA || !isOvenA || !isMixerA  ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isBlenderA = false;
            isOvenA = false;
            isMixerA = false;
        }
        cook( 30 );
        synchronized ( this ) {
          isBlenderA = true;
          isOvenA = true;
          isMixerA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    public void run() {
      while ( running ) {

        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isBlenderA || !isGrillA  ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isBlenderA = false;
            isGrillA = false;
        }
        cook( 60 );
        synchronized ( this ) {
          isBlenderA = true;
          isGrillA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isCoffeemakerA || !isMicrowaveA || !isGriddleA ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isCoffeemakerA = false;
            isMicrowaveA = false;
            isGriddleA = false;
        }
        cook( 15 );
        synchronized ( this ) {
          isCoffeemakerA = true;
          isMicrowaveA = true;
          isGriddleA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isFryerA || !isOvenA ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isFryerA = false;
            isOvenA = false;
        }
        cook(45);
        synchronized ( this ) {
          isFryerA = true;
          isOvenA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    public void run() {
      while ( running ) {

        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isGrillA || !isGriddleA ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isGrillA = false;
            isGriddleA = false;
        }
        cook( 15 );
        synchronized ( this ) {
          isGrillA = true;
          isGriddleA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isGriddleA || !isMixerA  ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isGriddleA = false;
            isMixerA = false;
        }
        cook( 15 );
        synchronized ( this ) {
          isGriddleA = true;
          isMixerA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isMicrowaveA || !isFryerA || !isBlenderA  ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isMicrowaveA = false;
            isFryerA = false;
            isBlenderA = false;
        }
        cook( 60 );
        synchronized ( this ) {
          isMicrowaveA = true;
          isFryerA = true;
          isBlenderA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.
        synchronized ( this ) {
            while ( !isFryerA || !isGrillA ) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isFryerA = false;
            isGrillA = false;
        }
        cook( 75 );
        synchronized ( this ) {
          isFryerA = true;
          isGrillA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    public void run() {
      while ( running ) {
        // Get the appliances this chef uses.

        synchronized ( this ) {
            while ( !isMixerA || !isCoffeemakerA || !isOvenA) {
              try {
                this.wait();
              } catch ( InterruptedException e) {
              }
            }
            isMixerA = false;
            isCoffeemakerA = false;
            isOvenA = false;
        }
        cook( 30 );
        synchronized ( this ) {
          isMixerA = true;
          isCoffeemakerA = true;
          isOvenA = true;
          this.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
