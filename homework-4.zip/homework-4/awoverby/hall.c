/**
  @file hall.c
  @author Andrew W Overby (awoverby)
  This program acts as a monitor for the distribution of segments of a hall for different organizations.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>

// List of bool values marking a segment's availability.
bool *avail;
// List of char values representing the owner of a segment.
char *owners;
// Number of segments.
int segments = 0;
// Mutex for the monitor.
pthread_mutex_t mutex;
// Condition for entrance to allocateSpace().
pthread_cond_t allocCond;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
  pthread_mutex_init( &mutex, NULL );
  pthread_cond_init( &allocCond, NULL );
  avail = (bool *) malloc( sizeof( bool ) * n );
  for ( int i = 0; i < n; i++ ) {
    avail[ i ] = true;
  }
  owners = (char *) malloc( sizeof( char ) * n );
  for ( int i = 0; i < n; i++ ) {
    owners[ i ] = '*';
  }
  segments = n;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
  free( avail );
  free( owners );
  pthread_cond_destroy( &allocCond );
  pthread_mutex_destroy( &mutex );
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  bool canAlloc = false;
  bool firstCheck = true;
  int start = -1;
  pthread_mutex_lock( &mutex );
  while ( !canAlloc ) {
    // Check if there is a space meeting the requirements.
    int availStreak = 0;
    for ( int i = 0; i < segments; i++ ) {
      if ( avail[ i ] ) {
        availStreak++;
      } else {
        availStreak = 0;
      }
      if ( availStreak == width ) {
        canAlloc = true;
        start = i - width + 1;
        break;
      }
    }
    // If there isn't, wait and print if it's your first time.
    if ( !canAlloc ) {
      if ( firstCheck ) {
        printf( "%s waiting: %s\n", name, owners );
        firstCheck = false;
      }
      pthread_cond_wait( &allocCond, &mutex );
    }
  }
  // If there is space, claim it.
  for ( int i = start; i < start + width; i++ ) {
    avail[ i ] = false;
    owners[ i ] = name[ 0 ];
  }
  printf( "%s allocated: %s\n", name, owners );
  pthread_mutex_unlock( &mutex );
  return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
  pthread_mutex_lock( &mutex );
  // Release your space and allow a waiting thread to check again.
  for ( int i = start; i < start + width; i++ ) {
    avail[ i ] = true;
    owners[ i ] = '*';
  }
  printf( "%s freed: %s\n", name, owners );
  pthread_cond_signal( &allocCond );
  pthread_mutex_unlock( &mutex );
}