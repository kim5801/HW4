/**
* @file hall.c
* @author dsmathur
* This file includes all the operations of
* a hall scenario where different threads
* want to use a specific width of the hall
* and they can free the space when finished
* so other threads can use them.
*/

#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

 
/** The character array used for holding the spaces */
char *arrayuse;

/** Monitor used in the program*/
pthread_mutex_t mon;
 
/** The condition variable used in the program*/
pthread_cond_t freeCond;
 
/**
* This function initialized the monitor , allocating any
* heap memory it requires and initializes the state where
* required.
* @param n the width of the hall
*/
void initMonitor(int n){
    // Initializing the monitor
    pthread_mutex_init(&mon,NULL);
    //Initializing the condition variable
    pthread_cond_init(&freeCond,NULL);
     
    //Mallocing space for the character array to be used
    arrayuse = (char*) malloc(sizeof(char) * n);
     
    //Initializing the array to just hold stars
    for(int i = 0 ; i < n;i++){
        arrayuse[i] = '*';
    }
}

/**
* This function is called after the monitor is done
* It frees the array used by the program
*/
void destroyMonitor (){
    free(arrayuse);
}

/**
* A thread calls this function when it wants to use a space in the hall.
* If there is no space available , this function will make the thread wait
* until it can have the space it needs.
* @param name the name of the organization
* @param width  the width of the hall
* @return start the index at which the allocation began
*/
int allocateSpace(char const * name , int width){
    //Entering into the monitor lock
    pthread_mutex_lock(&mon);
   
    //Variable to keep track of the start index for the program
    int start = 0;
    int count  = 0;
    bool set = 0;
     
    //Go through the list and search for the required
    // number of spaces available in the array
    for(int i  = 0;  i< strlen(arrayuse); i++){
        //If the character is a "*" that indicates there is
        //free space present
        if(arrayuse[i] == '*'){
            //If the count is zero, we need
            // to reassign the start variable
            if(count == 0){
                start = i;
            }
            count++;
        }
        //If the character was not a "*", we need to
        // restart with the value of count at zero
        else{
            count = 0;
        }
        //If the count has reached the desired width ,
        // it indicates those spaces are present
        if(count == width){
            set = 1;
            break;
        }
    }
   
    //If the boolean variable was not set , that means the
    // spaces were not found. Hence we need to make the
    // function wait until it gets those spaces
    if(!set){
        //A print statement to indicate that it is waiting for space
        printf("%s waiting: %s\n",name,arrayuse);
        count = 0;
       
        //Perform the same loop as above until the
        // count is equal to the proposed width
        while(count != width){
            //Wait till a signal is received, that is when some
            // space is freed
            pthread_cond_wait(&freeCond, &mon);
            start = 0;
            for(int  i = 0 ; i < strlen(arrayuse);i++){
                //If the character is a "*" that indicates there is
                //free space present
                if(arrayuse[i] =='*'){
                    if(count == 0){
                        start = i;
                    }
                    count++;
                }
                //If the character was not a "*", we need to
                // restart with the value of count at zero
                else{
                    count = 0;
                }
                //If the count is equal to the desired width,
                // break off from the loop
                if(count  == width){
                    break;
                }
            }
        }
    }
   
    //To keep track of when the required width has been reached
    int track = 0;
    for(int i = start; i < strlen(arrayuse) ;i++){
        if(track == width){
            break;
        }
        //Replace the "*" characters with the first letter
        // of the name of the organization
        arrayuse[i] = *name;
        track++;
    }
     
    //Release the lock from the monitor
    pthread_mutex_unlock(&mon);
   
    //A print statement to indicate that the width has been allocated
    printf("%s allocated: %s\n",name,arrayuse);
    return start;
}

/**
* A thread calls this function when it is done using the
* space it was given in the previous call to allocateSpace()
* @param name the name of the organization
* @param the width , the number of spaces to be freed
* @param start the index from which to start the free process
*/
void freeSpace(char const * name , int start , int width){
    //Start the monito lock
    pthread_mutex_lock(&mon);
    //Keep track of when the required width has been reached
    int track = 0;
    for(int i = start ; i < strlen(arrayuse);i++){
        if(track == width){
            break;
        }
        track++;
        //Replace the characters with the "*" as space has been freed
        arrayuse[i] = '*';
    }
      
    // To throw a signal that space has been freed so it can used for
    // other calls
    pthread_cond_signal(&freeCond);
    //A print statement to indicate that space has been freed
    printf("%s freed: %s\n",name, arrayuse);
   
    
   
    //Release the lock from the monitor
    pthread_mutex_unlock(&mon);
}

