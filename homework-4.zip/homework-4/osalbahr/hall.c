/**
 * @file hall.c
 * @author Osama Albahrani (osalbahr)
 * @brief reservation system, each organization can reserve
 *        any number of arbitrary-length contiguous rooms
 *
 * Options, if defined:
 * DEBUG      - print more stuff as needed
 * STARVE     - disable anti-starvation
 * DENY       - immediately return the organization away (making it think it went through)
 * ONE        - let one organization at a time, as if there is no space
 *              (effectively, anti-starvation with bound = 0. sort of)
 * LINKEDLIST - use a (doubly) linked list
 */

#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifndef STARVE
// Print out an error message and exit.
static void fail( char const *message )
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
#endif

// my monitor, protects all global variables
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// make an organization wait because there is on space
static pthread_cond_t space = PTHREAD_COND_INITIALIZER;


// helps with debugging
#ifdef DEBUG
#define REPORTI( X ) printf( "%s = %d\n", #X, X )
#define REPORTS( X ) printf( "%s = %s\n", #X, X )
#define REPORT3( X, Y, Z ) printf( "%s = %d, %s = %d, %s = %d\n", #X, X, #Y, Y, #Z, Z )
// report org if it is aging
#define REPORTORG( ORG ) ORG ? printf( "name = %s, age = %d\n", ORG->name, ORG->age ) : printf( "NULL\n" )
// report an org being nice
#define REPORTNICE( ORG ) printf( "%s being nice (age = %d, max = %d)\n", name, ORG->age, max );
// report all orgs in linked list
#define REPORTORGS( ORGS ) \
for ( Org *org = ORGS; org; org = org->next ) \
  printf( "prev = " ), REPORTORG( org->prev ), \
  printf( "org = " ), REPORTORG( org ), \
  printf( "next = "), REPORTORG( org->next )
#else
#define REPORTI( X )
#define REPORTS( X )
#define REPORT3( X, Y, Z )
#define REPORTORG( ORG )
#define REPORTNICE( ORG )
#define REPORTORGS( ORGS )
#endif

// organization struct
#ifndef STARVE
struct OrgStruct {
#ifdef DEBUG
  // organization's name
  char *name;
  // organization's width
  int width;
#endif
  // organization's age
  int age;
#ifdef LINKEDLIST
  // organization's prev
  struct OrgStruct *prev;
  // organization's next
  struct OrgStruct *next;
#else
  // organization's waitingOrgs index
  int idx;
#endif
};
typedef struct OrgStruct Org;
#endif

// hall struct
typedef struct HallStruct {
  // number of rooms
  int n;

  // number of total empty rooms
  int space;

  // Allocation string
  char *allocation;

#ifndef STARVE
  // capacity of waiting list
  int capacity;

  // number of orgs in waiting list
  int size;
#ifdef LINKEDLIST
  // store waiting orgs, to age them
  Org *waitingOrgs;
#else
  // store waiting orgs, to age them
  Org **waitingOrgs;
#endif

#endif
} Hall;

// Status of everything in the hall
static Hall *hall;

/** Initialize the monitor as a hall with n spaces that can be partitioned
  off. */
void initMonitor( int n )
{
  hall = calloc( 1, sizeof( Hall ) );
  hall->n = n;
  hall->space = n;
  hall->allocation = malloc( ( n + 1 ) * sizeof( char ) );
  for ( int i = 0; i < n; i++ )
    hall->allocation[ i ] = '*';
  hall->allocation[ n ] = '\0';
}

#ifndef STARVE
static void freeOrg( Org *org )
{
  if ( org == NULL )
    return;
#ifdef DEBUG
  free( org->name );
#endif
  free( org );
}

// only applicable in normal mode
#if !defined(STARVE) && !defined(LINKEDLIST)
static void freeOrgs( Org **orgs )
{
  for ( int i = 0; i < hall->capacity; i++ )
    freeOrg( orgs[ i ] );

  free( orgs );
}
#endif

#ifdef LINKEDLIST
// insert org as waiting
void insertOrg( Org *org )
{
  // insert in the beginning
  Org *start = hall->waitingOrgs;
  if ( hall->waitingOrgs )
    start->prev = org;

  org->next = start;
  hall->waitingOrgs = org;
}

// link these two nodes together
// prev is guaranted not NULL
void link( Org *prev, Org *next )
{
  prev->next = next;
  if ( next )
    next->prev = prev;
}

// remove org, no longer waiting
void removeOrg( Org *org )
{
  if ( org == NULL )
    fail( "Org is NULL" );
  
  if ( hall->waitingOrgs == NULL )
    fail( "List is NULL" );
  
  // remove beginning
  if ( org == hall->waitingOrgs ) {
    hall->waitingOrgs = org->next;
  } else { // remove otherwise
    link( org->prev, org->next );
  }

  // Free on all paths
  freeOrg( org );
}
#else // keep array-based
// insert org as waiting
void insertOrg( Org *org )
{
  if ( hall->size == hall->capacity ) {
    int newCapacity = 2 * ( hall->capacity + 1 ); // lazy if ( hall->capacity == 0 ) hall->capacity = 1
    Org **newOrgs = calloc( newCapacity, sizeof( Org * ) ); // would be nice if recalloc exists
    // copy over old list  
    for ( int i = 0; i < hall->capacity; i++ )
      newOrgs[ i ] = hall->waitingOrgs[ i ];
    // free old list
    free( hall->waitingOrgs );
    hall->waitingOrgs = newOrgs;
    hall->capacity = newCapacity;
  }

  int i;
  for (i = 0; hall->waitingOrgs[ i ] != NULL; i++ ) // find empty space
    ;
  if ( i >= hall->capacity )
    fail( "List is corrupted (insert)" );

  hall->waitingOrgs[ i ] = org;
  hall->size++;
  org->idx = i;
}

// remove org, no longer waiting
void removeOrg( Org *org )
{ 
  if ( org != hall->waitingOrgs[ org->idx ] )
    fail( "List is corrupted (remove)" );
  
  hall->waitingOrgs[ org->idx ] = NULL;
  freeOrg( org );
  hall->size--;
}
#endif // end array-based

#endif // end ifndef STARVE

// Deallocate hall resources
static void freeHall()
{
#if !defined(STARVE) && !defined(LINKEDLIST)
  freeOrgs( hall->waitingOrgs );
#endif
  free( hall->allocation );
  free( hall );
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
  pthread_mutex_destroy( &lock );
  freeHall();
}

static void printAllocation()
{
  printf( "%s\n", hall->allocation );
}

// only one at a time
#ifdef ONE
bool can = true;
#endif

// Anti-starvation
#ifndef STARVE

// When to let someone else in
#define BOUND 100

// to make an organization wait even if there is space
// i.e. to make it "starve" for a little bit
static pthread_cond_t starve = PTHREAD_COND_INITIALIZER;

// max age
static int max = 0;

// update max age if new age is bigger
static void updateAge( Org *org )
{
  if ( org && max < ++org->age )
    max = org->age;
}

// update the ages of all other orgs
static void updateAges()
{ 
#ifndef LINKEDLIST
  for ( int i = 0; i < hall->capacity; i++ )
    updateAge( hall->waitingOrgs[ i ] );
#else
  for ( Org *org = hall->waitingOrgs; org; org = org->next )
    updateAge( org );
#endif
}
#endif

/** Called when an organization wants to reserve the given number
  (width) of contiguous spaces in the hall.  Returns the start of
  the left-most (lowest-numbered) end of the space allocated to the
  organization. */
int allocateSpace( char const *name, int width )
{
// to see how many "reservations" happen if I immediately return
#ifdef DENY
  printf( "%s denied: ", name );
  printAllocation();
  return 0;
#endif

  pthread_mutex_lock( &lock );

#ifdef ONE
  // printf( "%s = %d\n", name, can );
  while ( can == false )
    pthread_cond_wait( &space, &lock );

  can = false;
#endif

// prepare for potentially making this org wait
#ifndef STARVE
  // Create org, zero-out every field (ANSI-compliant)
  // age = 0, ( prev = next = NULL if applicable )
  Org *org = calloc( 1, sizeof( Org ) );
  // Copy the width and name, for debugging
#ifdef DEBUG
  org->width = width;
  org->name = malloc( ( strlen( name ) + 1 ) * sizeof( char ) );
  strcpy( org->name, name );
#endif

  // initialize age
  org->age = 0;
  // insert org in orgs list
  insertOrg( org );
#endif

  bool found = false, printed = false;
  int start = 0;
  while ( !found ) {
    // No need to search if total space < width
    while ( hall->space < width )
      pthread_cond_wait( &space, &lock );

#ifndef STARVE
    while ( max > org->age + BOUND ) {
      printf( "%s waiting: ", name );
      printAllocation();
      printed = true;
      pthread_cond_wait( &starve, &lock );
    }
#endif

    start = 0;
    for ( int i = 0; !found && i < hall->n; i++ ) {
      if ( hall->allocation[ i ] == '*' ) {
        if ( i - start + 1 == width ) {
          found = true;
        }
      } else {
        while ( i < hall->n && hall->allocation[ i ] != '*' ) {
          i++;
        }
        start = i--; // undo for loop's i++
      }
    }

    if ( !found ) {
      if ( !printed ) {
        printf( "%s waiting: ", name );
        printAllocation();
        printed = true;
      }
      pthread_cond_wait( &space, &lock );
    }
  }

  // insert org in allocation string
  for ( int i = 0; i < width; i++ )
    hall->allocation[ start + i ] = name[ 0 ];
  hall->space -= width;


#ifndef STARVE
  printf( "%s allocated (%d): ", name, org->age );
  printAllocation();
  if ( org->age == max ) {
    max = 0;                            // force updating global max
    pthread_cond_broadcast( &starve );  // wake up possible nice organizations that let me go first
  }
  removeOrg( org );                     // I am no longer waiting
  updateAges();                         // update all other ages

#else
  printf( "%s allocated: ", name );
  printAllocation();
#endif

  pthread_mutex_unlock( &lock );
  return start;
}

/** Relese the allocated spaces from start start up to (and including)
  start start + width - 1. */
void freeSpace( char const *name, int start, int width )
{
#ifdef DENIED
  return;
#endif

  pthread_mutex_lock( &lock );
  for ( int i = 0; i < width; i++ )
    hall->allocation[ start + i ] = '*';
  hall->space += width;

  printf( "%s freed: ", name );
  printAllocation();
#ifdef ONE
  can = true;
#endif
  pthread_cond_broadcast( &space );
  pthread_mutex_unlock( &lock );
}
