/**
 * @file hall.c
 * @author Jonathan Kolesar (jkolesa)
 * The Meeting Hall monitor.  If I was programming in Java or C++, this would 
 * all be wrapped up in a class.  Since we're using C, it's just a collection of 
 * functions, with an initialization function to init the state of the whole monitor.
 */


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


// Represents a dynamically allocated char array to hold a given number of spaces.
char *hall;
// An int that represents the size of the hall.
int hallSize;
// Lock for access to the monitor.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// Condition for blocking the a thread when there isn't a large enough open slot.
pthread_cond_t slotCond = PTHREAD_COND_INITIALIZER;


/**
 * Returns the whether there exists a starting index of the first slot that is wide enough for the thread.
 * 
 * @param width the minimum width that a valid slot needs to be for the thread
 * @param foundStart the starting index of the first slot that is wide enough for the thread
 * @return whether a slot that is wide enough for the thread exists in the hall
 */
bool getSlot( int width, int *foundStart ) {

    int currStart = 0;
    int currSlotWidth = 0;

    bool prevSlotIsOpen = false;
    for ( int i = 0; i < hallSize; i++ ) {
        if ( prevSlotIsOpen && hall[ i ] == '*' ) {
            currSlotWidth++;
        } else if ( !prevSlotIsOpen && hall[ i ] == '*' ) {
            currSlotWidth = 1;
            prevSlotIsOpen = true;
        } else if ( hall[ i ] != '*' ) {
            prevSlotIsOpen = false;
            if ( currSlotWidth >= width ) {
                *foundStart = currStart;
                return true;
            }
            currSlotWidth = 0;
            currStart = i + 1;
        }
    }

    if ( hall[ hallSize - 1 ] == '*' && currSlotWidth >= width ) {
        *foundStart = currStart;
        return true;
    }

    return false;
}


/**
 * Initialize the monitor as a hall with n spaces that can be partitioned off.
 * 
 * @param n the total width of the hall (the number of the spaces it contains)
 */
void initMonitor( int n ) {
    // Enter the monitor
    pthread_mutex_lock( &mon );

    // Saves the given total width of the hall to the global variable 'hallSize' for future reference
    hallSize = n;

    // Allocates space for the hall of the given total width
    hall = (char *)malloc( n * sizeof( char ) );

    // Initializes each space in the hall as available
    for ( int i = 0; i < n; i++ )
        hall[ i ] = '*';

    // Leave the monitor
    pthread_mutex_unlock( &mon );
}


/**
 * Destroy the monitor, freeing any resources it uses.
 * 
 */
void destroyMonitor() {
    free( hall );
}


/**
 * Called when an organization wants to reserve the given number (width) of 
 * contiguous spaces in the hall. Returns the index of the 
 * left-most (lowest-numbered) end of the space allocated to the organization.
 * 
 * @param name String name of the organization for the thread
 * @param width int width of the contiguous space the thread needs
 * @return int the index of the leftmost space assinged to the thread.
 */
int allocateSpace( char const *name, int width ) {
    // Keeps track of whether the thread has already checked for a slot once already.
    bool firstLoop = true;

    // The found starting index of the slot in the hall that is wide enough for the thread.
    int foundStart = 0;

    // Enter the monitor
    pthread_mutex_lock( &mon );

    // Block until there's a slot
    while ( !getSlot( width, &foundStart ) ) {
        if ( firstLoop ) {
            printf( "%s waiting: ", name );
            for ( int i = 0; i < hallSize; i++ )
                printf( "%c", hall[ i ] );
            printf("\n");
            firstLoop = false;
        }
        pthread_cond_wait( &slotCond, &mon );
    }

    // Fill in the first open slot
    for ( int i = foundStart; i < (foundStart + width); i++ )
        hall[ i ] = name[ 0 ];
    printf( "%s allocated: ", name );
    for ( int i = 0; i < hallSize; i++ )
        printf( "%c", hall[ i ] );
    printf("\n");

    // Leave the monitor
    pthread_mutex_unlock( &mon );

    return foundStart;
}


/**
 * Relese the allocated spaces from index start up to (and including) 
 * index start + width - 1.
 * 
 * @param name String name of the organization for the thread
 * @param start the index of the leftmost space assinged to the thread
 * @param width int width of the contiguous space the thread has
 */
void freeSpace( char const *name, int start, int width ) {
    // Enter the monitor
    pthread_mutex_lock( &mon );

    // Resests the given slot.
    for ( int i = start; i < (start + width); i++ )
        hall[ i ] = '*';

    // Reports the organization that was just freed.
    printf( "%s freed: ", name );

    // Reports the current state of the hall.
    for ( int i = 0; i < hallSize; i++ )
        printf( "%c", hall[ i ] );
    printf("\n");

    // Wake any threads waiting on for a slot
    pthread_cond_signal( &slotCond );

    // Leave the monitor
    pthread_mutex_unlock( &mon );
}
