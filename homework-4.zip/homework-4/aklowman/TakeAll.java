import java.util.Random;

/**
 * @file TakeAll.java
 * @author Annie Lowman aklowman
 * 
 * Class that has chefs "cook" (take turns sharing a resource)
 * This program uses the no-hold-and-wait methodology to solve the
 * problem of chefs using the same resources at the same time.
 * This is implemented using global booleans to represent each 
 * resource and a shared monitor for waiting and using the resources
 */
public class TakeAll {
  /** To tell all the chefs when they can quit running. */
  private static boolean running = true;

  /** Superclass for all chefs.  Contains methods to cook and rest and
      keeps a record of how many dishes were prepared. */
  private static class Chef extends Thread {
    /** Number of dishes prepared by this chef. */
    private int dishCount = 0;

    /** Source of randomness for this chef. */
    private Random rand = new Random();

    /** Called after the chef has locked all the required appliances and is
        ready to cook for about the given number of milliseconds. */
    protected void cook( int duration ) {
      System.out.printf( "%s is cooking\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be cooking)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
      dishCount++;
    }

    /** Called between dishes, to let the chef rest before cooking another dish. */
    protected void rest( int duration ) {
      System.out.printf( "%s is resting\n", getClass().getSimpleName() );
      try {
        // Wait for a while (pretend to be resting)
        Thread.sleep( rand.nextInt( duration / 2 ) + duration / 2 );
      } catch ( InterruptedException e ) {
      }
    }
  }

  // An object representing the lock on each appliance.
  // Locking the needed objects before cooking prevents two
  // chefs from trying to use the same appliance at the same time.
  private static boolean griddle = false;
  private static boolean mixer = false;
  private static boolean oven = false;
  private static boolean blender = false;
  private static boolean grill = false;
  private static boolean fryer = false;
  private static boolean microwave = false;
  private static boolean coffeeMaker = false;
  /** Monitor object for the different chefs to use */
  private static Object mon = new Object();

  /** Mandy is a chef needing 105 milliseconds to prepare a dish. */
  private static class Mandy extends Chef {
    /** Method to let the chef "cook" (use the microwave and coffeemaker for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while ( microwave || coffeeMaker) {
                try {
                    mon.wait();
                } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            microwave = true;
            coffeeMaker = true;
        }
        
        cook( 105 );
        // enter monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            microwave = false;
            coffeeMaker = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Edmund is a chef needing 30 milliseconds to prepare a dish. */
  private static class Edmund extends Chef {
    /** Method to let the chef "cook" (use the blender, oven, and mixer for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor 
        synchronized( mon ) {
            // wait until all resources are available
            while ( blender || oven || mixer ) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            blender = true;
            oven = true;
            mixer = true;
        }
        cook( 30 );
        // enter the monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            blender = false;
            oven = false;
            mixer = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Napoleon is a chef needing 60 milliseconds to prepare a dish. */
  private static class Napoleon extends Chef {
    /** Method to let the chef "cook" (use the blender and grill for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while( blender || grill ) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            blender = true;
            grill = true;
        }
        cook( 60 );
        // enter the monitor
        synchronized ( mon ) {
            // mark resources as no longer being in use
            blender = false;
            grill = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Prudence is a chef needing 15 milliseconds to prepare a dish. */
  private static class Prudence extends Chef {
    /** Method to let the chef "cook" (use the microwave, coffee maker, and griddle for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while (coffeeMaker || microwave || griddle) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            coffeeMaker = true;
            microwave = true;
            griddle = true;
        }
        
        cook( 15 );
        // enter the monitor again
        synchronized ( mon ) {
            // mark resources as no longer being in use
            coffeeMaker = false;
            microwave = false;
            griddle = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Kyle is a chef needing 45 milliseconds to prepare a dish. */
  private static class Kyle extends Chef {
    /** Method to let the chef "cook" (use the fryer and oven for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while ( fryer || oven ) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            fryer = true;
            oven = true;
        }
        cook( 45 );
        // enter the monitor again
        synchronized ( mon ) {
            // mark resources as no longer being in use
            fryer = false;
            oven = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Claire is a chef needing 15 milliseconds to prepare a dish. */
  private static class Claire extends Chef {
    /** Method to let the chef "cook" (use the grill and griddle for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while (grill || griddle) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            griddle = true;
            grill = true;
        }
        cook( 15 );
        // enter the monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            griddle = false;
            grill = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Lucia is a chef needing 15 milliseconds to prepare a dish. */
  private static class Lucia extends Chef {
    /** Method to let the chef "cook" (use griddle and mixer for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while (griddle || mixer) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            griddle = true;
            mixer = true;
        }
        cook( 15 );
        // enter the monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            griddle = false;
            mixer = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Marcos is a chef needing 60 milliseconds to prepare a dish. */
  private static class Marcos extends Chef {
    /** Method to let the chef "cook" (use the microwave, fryer, and blender for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while ( microwave || fryer || blender ) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            microwave = true;
            fryer = true;
            blender = true;
        }
        cook( 60 );
        // enter the monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            microwave = false;
            fryer = false;
            blender = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /** Roslyn is a chef needing 75 milliseconds to prepare a dish. */
  private static class Roslyn extends Chef {
    /** Method to let the chef "cook" (use the fryer and grill for a bit) */
    public void run() {
      while ( running ) {
        // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while ( fryer || grill ) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            fryer = true;
            grill = true;
        }
        cook( 75 );
        // enter the monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            fryer = false;
            grill = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }
        rest( 25 );
      }
    }
  }

  /** Stephenie is a chef needing 30 milliseconds to prepare a dish. */
  private static class Stephenie extends Chef {
    /** Method to let the chef "cook" (use the mixer, coffee maker, and oven for a bit) */
    public void run() {
      while ( running ) {
       // enter the monitor
        synchronized ( mon ) {
            // wait until all resources are available
            while ( mixer || coffeeMaker || oven ) {
                try {
                    mon.wait();
                    } catch ( InterruptedException e ) {
                }
            }
            // mark resources as being in use
            mixer = true;
            coffeeMaker = true;
            oven = true;
        }
        
        cook( 30 );
        // enter the monitor again
        synchronized( mon ) {
            // mark resources as no longer being in use
            mixer = false;
            coffeeMaker = false;
            oven = false;
            // notify other waiting threads that new resources have become available
            mon.notifyAll();
        }

        rest( 25 );
      }
    }
  }

  /**
   * Main method creates the new chefs and then starts them cooking, and has them report thier end cooking total
   * @param args command line argument
   */
  public static void main( String[] args ) throws InterruptedException {
    // Make a thread for each of our chefs.
    Chef chefList[] = {
      new Mandy(),
      new Edmund(),
      new Napoleon(),
      new Prudence(),
      new Kyle(),
      new Claire(),
      new Lucia(),
      new Marcos(),
      new Roslyn(),
      new Stephenie(),
    };

    // Start running all our chefs.
    for ( int i = 0; i < chefList.length; i++ )
      chefList[ i ].start();

    // Let the chefs cook for a while, then ask them to stop.
    Thread.sleep( 10000 );
    running = false;

    // Wait for all our chefs to finish, and collect up how much
    // cooking was done.
    int total = 0;
    for ( int i = 0; i < chefList.length; i++ ) {
      chefList[ i ].join();
      System.out.printf( "%s cooked %d dishes\n",
                         chefList[ i ].getClass().getSimpleName(),
                         chefList[ i ].dishCount );
      total += chefList[ i ].dishCount;
    }
    System.out.printf( "Total dishes cooked: %d\n", total );
  }
}
