/**
* @file hall.c
* @author Annie Lowman aklowman
*
* File implements the monitor to keep track of the current available spaces
* inside of the hall for different threads to use. Program creates a string 
* to keep track of the rooms, and uses a mutex and a condition variable to
* implement the waiting and notifying features.
*/
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>

/** Monitor to enter when looking at the rooms list*/
static pthread_mutex_t lock;
/** Condition variable to wait on*/
static pthread_cond_t cond;
/** String/ list to keep up with the current room allocations*/
static char *rooms;
/** number of spaces in the room hall*/
static int space;


/** 
* Function initializes the list of rooms, and then initializes
* the mutex and condition variables for use, and also marks the
* global variable for the number of rooms
* @param n number of rooms requested
*/
void initMonitor( int n )
{
    // allocate room for the rooms list, and initialize all of the spaces to be blank
    rooms = (char *) malloc ( (n  + 1) * sizeof( char ) );
    for ( int i = 0; i < n; i++ ) {
        rooms[i] = '*';
    }
    rooms[n] = '\0';
    // initialize monitor mutex
    pthread_mutex_init( &lock, NULL );
    // assing number of rooms to space global variable
    space = n;
    // initalize monitor condition variable
    pthread_cond_init( &cond, NULL);

}

/**
* Frees the malloced list for the rooms
*/
void destroyMonitor()
{
    // free the malloced string
    free ( rooms );
}

/**
* Function aquires the lock on the monitor, and then checks the list of rooms to 
* find the first open available space that is big enough. If no space is available
* the thread waits and continues to check until a space is found. It the claims the 
* space and reports the updated list
*
* @param name name of the current thread requesting the rooms
* @param width number of rooms to be allocating
* @return starting index of the allocated space
*/
int allocateSpace( char const *name, int width )
{
    // put a lock on the monitor
    pthread_mutex_lock( &lock );
    // initlaize variables needed for keeping track of counts and indexs
    int startIndex;
    int consecCount;
    int waitCount = 0;
    bool spaceFound = false;
    // loop while the space for a request has not been found
    while ( !spaceFound ) {
        startIndex = 0;
        consecCount = 0;
        // iterate through each index of the current room list
        for ( int i = 0; i < space; i++ ) {
            
            char ch = rooms[ i ];
            if ( ch != '*' ) {
                consecCount = 0; // reset the count of concesutive empty spaces if a taken space is found
            }
            else {
                if (consecCount == 0) { // if this is the first empty space found, mark the index of it
                    startIndex = i;
                }
                consecCount++;
            }
            if ( consecCount == width ) { // check if we have found a wide enough space, then exit if so
                spaceFound = true;
                break;
            }
        }
        if ( !spaceFound ) {
            if ( waitCount == 0 ) { // only print out message if this is the first time the thread is waiting
                printf("%s waiting: %s\n", name, rooms );
            }
           pthread_cond_wait( &cond, &lock );
           waitCount++;
        }
    }
    // fill in the new room spaces in the room list
    for ( int i = startIndex; i < startIndex + width; i++ ) {
        rooms[i] = name[0];
    }
    // print out the update and exit the monitor
     printf("%s allocated: %s\n", name, rooms );
     pthread_mutex_unlock( &lock );
     return startIndex;
}

/**
* Function marks the rooms as free for allocation,
* and then prints out the update for the list and signals
* to other threads there are now more spaces
* @param name name of the current thread freeing space
* @param start starting index of the current threads rooms
* @param width number of rooms allocated
*/
void freeSpace( char const *name, int start, int width )
{
    // clear out the rooms that had been allocated
    for ( int i = start; i < start + width; i++ ) {
        rooms[ i ] = '*';
    }
    // print out string and let other threads now ther is new space available
    printf("%s freed: %s\n", name, rooms);
    pthread_cond_broadcast( &cond );
}