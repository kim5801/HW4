/**
 * @file hall.c
 * @author Abhinav Pratap, aspratap
 * Simulates a hall where organizations can book rooms.
 */

#include <stdbool.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

/** rooms in the hall that organizations can reserve */
char *rooms;
/** number of rooms in the hall*/
int numRooms = -1;

/** monitor to prevent unsafe concurrent access to the rooms */
pthread_mutex_t hallLock;

/** condition variable organizations can wait on */
pthread_cond_t waitingList;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor(int n)
{
    pthread_mutex_init(&hallLock, NULL);
    pthread_cond_init(&waitingList, NULL);
    numRooms = n;
    rooms = (char *)malloc((n + 1) * sizeof(char));
    for (int i = 0; i < n; i++)
    {
        rooms[i] = '*';
    }
    rooms[n] = '\0';
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor()
{
    free(rooms);
    pthread_mutex_destroy(&hallLock);
    pthread_cond_destroy(&waitingList);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace(char const *name, int width)
{
    pthread_mutex_lock(&hallLock);
    int availSpaceIndex = -1;
    int spacesFound = 0;
    bool initialRun = true;
    while (spacesFound < width)
    {
        availSpaceIndex = -1;
        spacesFound = 0;
        for (int i = 0; i < numRooms; i++)
        {
            if (rooms[i] == '*')
            {
                if (availSpaceIndex == -1)
                {
                    availSpaceIndex = i;
                }

                spacesFound++;
            }
            else
            {
                availSpaceIndex = -1;
                spacesFound = 0;
            }

            if (spacesFound == width && availSpaceIndex != -1)
            {
                break;
            }
        }

        if (spacesFound < width || availSpaceIndex == -1)
        {
            if (initialRun)
                printf("%s waiting: %s\n", name, rooms);
            pthread_cond_wait(&waitingList, &hallLock);
        }

        initialRun = false;
    }

    for (int i = 0; i < spacesFound; i++)
    {
        rooms[availSpaceIndex + i] = name[0];
    }

    printf("%s allocated: %s\n", name, rooms);

    pthread_mutex_unlock(&hallLock);

    return availSpaceIndex;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace(char const *name, int start, int width)
{
    pthread_mutex_lock(&hallLock);
    for (int i = 0; i < width; i++)
    {
        rooms[start + i] = '*';
    }

    printf("%s freed: %s\n", name, rooms);
    pthread_cond_broadcast(&waitingList);
    pthread_mutex_unlock(&hallLock);
}
