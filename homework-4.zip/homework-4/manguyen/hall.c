#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdbool.h>

//arr of available space
static char* ptr;

//how much of the width is available
static int available;

//where the mem is free in regards to the ptr
static int availableIdx;

// mutex lock
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

//conditions for producer/consumer
pthread_cond_t conCond = PTHREAD_COND_INITIALIZER;
pthread_cond_t prodCond = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    //malloc in heap, initialize so everything is available
    ptr = (char *) malloc(n * sizeof(char));
    for (int i = 0; i < n; i++) {
        ptr[i] = '*';
    }
    available = n;
    availableIdx = 0;
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free(ptr);
}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
    //consumer
    int start = -1;

    pthread_mutex_lock( &lock);

    if (available < width) {
        printf("%s waiting: %s\n", name, ptr);
        while (available < width) {
            //wait for producer
            pthread_cond_wait(&conCond, &lock);
        }
    }
    
    start = availableIdx;
    for (int i = start; i < start + width; i++) {
        ptr[i] = name[0];
    }

    available -= width;
    availableIdx = start + width;

    printf("%s allocated: %s\n", name, ptr);
    pthread_cond_signal( &prodCond );
    pthread_mutex_unlock( &lock );


    //wait until freeSpace is called once it is, we can continue
    return start;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    //producer
    pthread_mutex_lock( &lock);
    //thread_exit
    for (int i = start; i <= start + width - 1; i++) {
        ptr[i] = '*';
    }

    if (start < availableIdx) {
        availableIdx = start;
    }
    available += width;

    pthread_cond_signal( &conCond );
    pthread_mutex_unlock( &lock );

    printf("%s freed: %s\n", name, ptr);
}