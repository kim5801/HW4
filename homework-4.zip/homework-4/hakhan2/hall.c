#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "hall.h"

// basic fail function to call 
static void fail( char *msg ) {
  printf( "Error: %s\n", msg );
  exit( EXIT_FAILURE );
}

// a pointer to the character array of the hall and its current status
char *hall;

// maxAge variable to determine if a thread should defer space allocation
int maxAge = 0;
// name of the thread with maxAge
char maxName[21] = "";

// Lock for access to the buffer.
pthread_mutex_t mon;

// Conditions for Monitor
pthread_cond_t spaceAvailable = PTHREAD_COND_INITIALIZER;
pthread_cond_t young = PTHREAD_COND_INITIALIZER;

void initMonitor( int n ) {
    // Initialize the character array that will store the current state of the hall
    // this will be n (size of hall) + 1 (null terminator) size
    hall = (char * ) calloc( n + 1, sizeof( char ) );
    // set the first n characters to '*'
    memset( hall, '*', n );

    // initialize the monitor
    pthread_mutex_init( &mon, NULL );
}

void destroyMonitor() {
    // free everything he init monitor function allocated in the heap
    free( hall );

    // destroy the monitor
    pthread_mutex_destroy( &mon );
}

// a helper function for allocate space to determine if there is space
bool canFit( int width ) {
    // create a string the size of width
    char lengthChar[width + 1];
    memset( lengthChar, '*', width); // set everything before null terminator to '*'
    lengthChar[width] = '\0'; // set the last character to the null terminator
    
    // this determines if there is or isn't a substring 
    return NULL != strstr(hall, lengthChar); 
}

int allocateSpace( char const *name, int width ) {
    // basic check to ensure width is <= len( hall )
    if( width > strlen( hall ) )
        fail( "width is greater than length of hall" );


    pthread_mutex_lock( &mon );

    // keep track of your own age
    int myAge = 0;

    // do a check on your own age 
    while ( maxAge - myAge >= 100 ) {
        pthread_cond_wait( &young, &mon ); // wait until the older thread is allocated
    }

    // continuously check to see if the space needed can fit in the hall-- 
    // only proceed from this loop when the width can fit in hall 
    while( !canFit( width ) ){
        // increment my age
        myAge++;
        
        // update maxAge 
        if( myAge > maxAge ) {
            // update the maxAge and maxName
            maxAge = myAge;
            strcpy( maxName, name );
        }

        // notify that you're waiting for space and then wait
        if( myAge == 1 ) 
            printf("%s waiting: %s\n", name, hall);
        pthread_cond_wait( &spaceAvailable, &mon );
    }
    
    int length = strlen( hall );

    int count = 0; // count of how many '*' we have seen

    // reset maxAge and maxName
    if( strcmp(name, maxName) == 0 ) {
        maxAge = 0;
        strcpy( maxName, "" );
        // notify all threads that they can try to allocate space
        pthread_cond_broadcast( &young );
    }

    // find the place where the string can fit
    for( int i = 0; i < length; i++ ) {
        if( hall[i] == '*' ) {
            count++;
            if( count == width ) {
                // replace the '*' with the first letter of name
                for( int j = i; j > i - width; j-- )
                    hall[j] = name[0];
                printf("%s allocated (%d): %s\n", name, myAge, hall);
                pthread_mutex_unlock( &mon );
                return i - width + 1; // return the index of the first character
            }
        }
        // otherwise reset the count and start looking again
        else {
            count = 0;
        }
    }

    return -1; // a fail value (this should never return)
}


void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock( &mon );
    
    // free the spaces in the hall used by name
    for( int i = start; i < start + width; i++ ) {
        hall[i] = '*';
    }

    printf( "%s freed: %s\n", name, hall );

    // notify all monitors waiting for available space
    pthread_cond_signal( &spaceAvailable );

    pthread_mutex_unlock( &mon );
}