#include <stdlib.h>
#include "hall.h"
#include <stdio.h>
#include <pthread.h>




char *memory;
int size;
int numFree;
pthread_mutex_t lock;
pthread_cond_t cond;

void initMonitor(int n)
{
  memory = (char *)malloc(n * sizeof(char));
  size = n;
  numFree = size;
  for (int i = 0; i < n; i++) {
    memory[i] = '*';
  }
  pthread_mutex_init(&lock, NULL);
}

void destroyMonitor()
{

  pthread_cond_destroy(&cond);
  free(memory);
}


int allocateSpace(char const *name, int width)
{
  pthread_mutex_lock(&lock);
  int waitCount = 0;
  while (numFree < width) {
    if (waitCount++ == 0) printf("%s waiting: %s\n", name, memory);
    pthread_cond_wait(&cond, &lock);
  }

  for (int i = 0; i < size; i++) {
    if (memory[i] == '*') {
      int start = i;
      int gap = 0;
      for (int j = i; j < size; j++) {

        if (memory[j] == '*') {
          // if (gap == 0) start = j;
          gap++;
          // printf("j: %d gap: %d width: %d\n",j, gap, width);
          // printf("name: %s start: %d\n", name, start);
          if (gap >= width) {
            // printf("%s %d\n",name, start);
            for (int k = start; k < start + width; k++) {
              // printf("2 name: %s start: %d k: %d\n", name, start, k);
              memory[k] = name[0];
            }
            numFree -= width;
            printf("%s allocated: %s\n", name, memory);
            pthread_cond_signal(&cond);
            pthread_mutex_unlock(&lock);
            return start;
          }
        } else {
          gap = 0;
          j = size;
        }
      }
    }
  }
  pthread_mutex_unlock(&lock);
  return -1;
}


void freeSpace(char const *name, int start, int width)
{
  pthread_mutex_lock(&lock);
  for (int i = start; i < start + width; i++) {
    if (memory[i] == name[0]) memory[i] = '*';
  }
  numFree += width;
  printf("%s freed: %s\n", name, memory);
  pthread_cond_signal(&cond);
  pthread_mutex_unlock(&lock);
}