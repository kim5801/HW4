/**
 * @file hall.c
 * 
 * A monitor implementation that allows organizations to rent "halls" and uses the monitor to organize when the halls are taken 
 * used Synchronization slides and buffer.c implementation in slides (bounded buffer)
 */
#include "hall.h"
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdio.h>
/** the halls available for rent */
char* halls;
/** size of the halls array*/
int size;
/** locks the halls array when in use */
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
/** the condition that notifies organization threads about the space */
pthread_cond_t spaceAvail = PTHREAD_COND_INITIALIZER;
/**
 * Checks the Halls array to see if space is available to rent
 * 
 * @param width the amount of contiguous space needed for rent
 * @return true if there is enough space for given width
 * @return false if there isn't enough space for given width
 */
bool spaceAvailable(int width) {
    // the number of contiguous space in the array
    int space = 0;
    // iterates through the array to check for enough space
    for (int i = 0; i < size; i++) {
        if (halls[i] == '*') {
            space++;
        }
        else {
            space = 0;
        }
        if (space == width) {
            return true;
        }
    }
    return false;
}
void initMonitor( int n ) {
    // assigning heap memory to the halls array
    halls = (char *)malloc(n * sizeof(char));
    size = n;
    // locking the array to fill the array with empty spaces
    pthread_mutex_lock(&mon);
    for (int i = 0; i < n; i++) {
        halls[i] = '*';
    }
    // signal to let other threads know that space is available
    pthread_cond_signal(&spaceAvail);
    pthread_mutex_unlock(&mon);
}

void destroyMonitor() {
    free(halls);
}

int allocateSpace( char const *name, int width ) {
    // since we only print the waiting message once according to instructions, this boolean checks if the current thread is checking for the first time
    bool firstTime = true;
    pthread_mutex_lock(&mon);
    // will continue to loop until space is available
    while (!spaceAvailable(width)) {
        if (firstTime) {
            firstTime = false;
            // prints out the waiting message
            printf("%s waiting: %s\n", name, halls);
        }
        // waits until more space is made available
        pthread_cond_wait(&spaceAvail, &mon);
    }
    // the amount of contiguous space 
    int space = 0;
    // the start of the organization's space
    int start = 0;
    // finds the starting space available in the array
    for (int i = 0; i < size; i++) {
        if (halls[i] == '*' && space == 0) {
            space++;
            start = i;
        }
        else if (halls[i] != '*'){
            space = 0;
        }
        else {
            space++;
        }
        if (space == width) {
            break;
        }
    }
    // fills the space according to the start position and width necessary
    for (int i = start; i < (start + width); i++) {
        halls[i] = name[0];
    }
    // prints a message saying that the array has been filled up by the given organization
    printf("%s allocated: %s\n", name, halls);
    pthread_mutex_unlock(&mon);
    return start;
}

void freeSpace( char const *name, int start, int width ) {
    pthread_mutex_lock(&mon);
    // frees the space the organization was taking up
    for(int i = start; i < (start + width); i++) {
        halls[i] = '*';
    }
    // prints the message saying that the halls that the organization was taking up is now freed
    printf("%s freed: %s\n", name, halls);
    // signals to other threads that more space has been freed up
    pthread_cond_signal(&spaceAvail);
    pthread_mutex_unlock(&mon);
}