#include "hall.h"
#include <stdlib.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

/** Representation of a free memory hole. */
typedef struct Room {
    //amount of free rooms.
    int size;

    int start;

    // This takes zero bytes in the struct, but it lets us treat the
    // memory right after size as an array of bytes, sometimes useful.
    char name[ 1 ];

    // Pointer to the next block if this one is free.
    struct Room *next;
} Room;

Room *hall;
Room *usedRooms;
char *roomList;
int totalSize;
int fullSlots;

// Lock for access to the monitor.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Condition for free, there are some rooms being used.
pthread_cond_t fullRooms = PTHREAD_COND_INITIALIZER;

// Condition for blocking the allocateSpace, are there empty room slots.
pthread_cond_t emptyRooms = PTHREAD_COND_INITIALIZER;

/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {
    totalSize = n;
    fullSlots = 0;
    hall = (Room*)malloc(sizeof(Room));
    hall->size = n;
    hall->start = 0;
    hall->name[0] = '*';
    hall->next = NULL;

    usedRooms = (Room*)malloc(sizeof(Room));
    usedRooms->size = 0;
    usedRooms->start = 0;
    usedRooms->next = NULL;

    roomList = (char*)malloc(n * sizeof(char));
    for (int i = 0; i < n; i ++) {
        roomList[i] = '*';
    }

    pthread_cond_signal(&emptyRooms);
}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {
    free(hall);
    free(usedRooms);
    free(roomList);
    hall = NULL;

}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {

    int retStart = 0;

    //enter the monitor here:
    pthread_mutex_lock( &mon );

    // Temporary Hole to keep track of which one the loop is currently viewing
    Room *current = hall;

    Room *prev = NULL;

    while (totalSize - fullSlots < width) {
        pthread_cond_wait( &emptyRooms, &mon );
    }
    
    fullSlots += width;

    //Loop that "walks" to the first block that can fit the requested amount of memory
    while(current->size < width && current->next) {
        prev = current;
        current = current->next;
    }
    retStart = current->start;
    char nameChar[1] = ""; 
    strcpy(nameChar, &name[0]);
    *current->name = *nameChar;

    for (int i = current->start; i < width; i++) {
        roomList[i] = *nameChar;
    }

    if (current->size >= width) {
        
        if (prev) {
            prev->next = current->next;
        }
        else {
            hall = current->next;
        }
        current->next = NULL;
        
    }


    // This block may be larger than what's needed.  If it's large
    // enough, split off anything extra and give it back to the free list.
    if ( width < current->size ) {
        // Where would the next block start.
        Room *h2 = (Room *)malloc( (sizeof(Room)));

        // Split the available memory between the blocks.
        h2->size = current->size - width;
        current->size = width;
        //current->start += width + 1;
        h2->start = current->start + width;


        // Merge the remaining memory back into the "free rooms list"

        // Link the new (still empty) node back into the linked list.
        if ( prev ) {
            h2->next = prev->next;
            prev->next = h2;
        } else {
            // No predecessor, must be the first node on
            // the list.
            h2->next = hall;
            hall = h2;
        }

        // Should this node absorb its successor?
        if ( h2->next && h2->next->start && h2->start + h2->size == h2->next->start ) {
            // Yes.  Absorb the successor block into this one.  Block h
            // gets larger, by the size of its successor block and memory used
            // for its successor's size field.
            h2->size += h2->next->size;

            // And the successor node no longer needs to show up as a separate
            // node in the linked list, skip over it.
            h2->next = h2->next->next;
        }

    }
    printf("%s allocated:", name);
    for (int i = 0; i < totalSize; i++) {
        printf("%c", roomList[i]);
    }
    printf("\n");
    
    pthread_cond_signal( &fullRooms );
    pthread_mutex_unlock( &mon );
    return retStart;
}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {
    
    pthread_mutex_lock( &mon );

    // Find the predecessor of this block in the free list.
    Room *current = hall;
    Room *prev = NULL;

    // Where would the next block start.
    Room *h2 = (Room *)malloc( (sizeof(Room)));

    // merge the memory back together.
    h2->size = width;
    h2->start = start;

    while (fullSlots < 1) {
        pthread_cond_wait( &fullRooms, &mon );
    }    

    if (h2->size + h2->start == current->start) {
        h2->next = current;
    }

    while (start != current->start - width - 1 && current->next) {
        prev = current;
        current = current->next;
    }
    fullSlots -= width;

    for (int i = start; i < width; i++) {
        roomList[i] = '*';
    }

    // Link the new (still empty) node back into the linked list.
    if ( prev ) {
        h2->next = prev->next;
        prev->next = current;
    } else {
        // No predecessor, must be the first node on
        // the list.
        if (current->start != hall->start) {           
            current->next = hall;
        }
        hall = current;
    }

    // Should this node absorb its successor?
    if ( current->next && current->start + current->size == current->next->start ) {
        // Yes.  Absorb the successor block into this one.  Block h
        // gets larger, by the size of its successor block and memory used
        // for its successor's size field.
        current->size += current->next->size;

        // And the successor node no longer needs to show up as a separate
        // node in the linked list, skip over it.
        current->next = current->next->next;
    }
    // Does block h have a predecessor?
    if ( prev ) {
        // Absorb h into its predecessor if there's no gap
        // between them.

        // Functions similarly to the if statement that absorbs the sucessor block
        // Should the predecessor absorb this block?
        if ( prev->start + prev->size == current->start ) {
            // If yes, absorb the current block into the predecessor.  Block pred gets bigger 
            // by the size of the current block and memory used for the current block's size field.
            prev->size += current->size;
            prev->next = current->next;
            current = prev;
        }
    }
    printf("%s freed:", name);
    for (int i = 0; i < totalSize; i++) {
        printf("%c", roomList[i]);
    }
    printf("\n");
    
    pthread_cond_signal( &emptyRooms );
    
    pthread_mutex_unlock( &mon );
}
