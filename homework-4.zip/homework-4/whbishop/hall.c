#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hall.h"


/** Our condition variable */
static pthread_cond_t condition;

/** Our MUTEX to control access to the monitor */
static pthread_mutex_t lock;

/** The number of spaces */
static int spaces;

/** Array for holding the hall */
static char *array;

/** Extra variable to make sure the monitor is accessed separately */
static int synchronize; //0 is false 1 is true


void initMonitor( int n ) {
	
	spaces = n;

	//Fill our array with a bunch of zeroes
	array = calloc(spaces, sizeof(char));

	//Set our synchronized variable to 0
	synchronize = 0;

	//Initiate our MUTEX and our condition variable 
	pthread_mutex_init(&lock, NULL);
	pthread_cond_init(&condition, NULL);
	
}


void destroyMonitor() {
	
	//Destroy our MUTEX and condition variable
	pthread_cond_destroy(&condition);
	pthread_mutex_destroy(&lock);
	
	//Free our Calloc'd array
	free(array);
}



int allocateSpace( char const *name, int width ) {

	//Set some initial variables 
	//The count
	int count = 0;

	//Set the start to the end of the number of spaces, this will get overrwriten
	int start = spaces;

	//Another synchronizing variable to help access control
	int synced = 0;

	//Lock our MUTEX
	pthread_mutex_lock(&lock);

	//int started = 0;

	//Overarching Do-While that will run infinitely until our count is the maximum it can be
	do { 

		//Iterate through the number of spaces 
		for (int i = 0; i < spaces; i++) {

			//If any of our array is 0, i.e. just calloc'd
			if (array[i] == 0) {

				//And the start variable is = to the spaces, set start to i
				if (start == spaces) start = i;

				//Increment count
				count++;
			}

			//Create our start width 
			int startWidth = start + width;
			//if (started) startWidth--;

			//If our named array is not 0, reset our starting variables 
			if (array[i] != 0) {
				start = spaces;
				count = 0;
				//started = 0;
			}

			//If our count is the maximum it can be 
			if (count == width) {

				//Iterate through and add the characters to our named array
				for (int i = start; i < startWidth; i++) array[i] = name[0];
				
				//Print said named array
				printf(name);
				printf(" allocated: ");

				//Print out the current monitor 
				for (int i = 0; i < spaces; i++) {
					if (array[i] == 0) printf("*");
					else printf("%c", array[i]);
				}
				printf("\n");

				//Lock out MUTEX for the monitor and return the index of the end of the space given to the organization
				pthread_mutex_unlock(&lock);
				return start;
			}

			
		}

		//Reset our variables, set our synchronization 
		start = spaces;
		count = 0;
		synchronize = 1;

		//If we are waiting
		if (synced == 0) {

			//Print the name of the organization
			printf(name);
			printf(" waiting: ");

			//Print out the current monitor
			for (int i = 0; i < spaces; i++) {
				if (array[i] == 0) printf("*");
				else printf("%c", array[i]);
			}
			printf("\n");
		}

		//While we are waiting
		while (synchronize) {

			//Wait
			pthread_cond_wait(&condition, &lock);
		}
	}
	while (true);
}

void freeSpace( char const *name, int start, int width ) {
	
	//Set our starting width
	int startWidth = start + width;

	//Lock our monitor 
	pthread_mutex_lock(&lock);

	//Iterate through and add the characters to our named array
	for (int i = start; i < startWidth; i++) array[i] = 0;

	//Print the name of the organization 
	printf(name);
	printf(" freed: ");

	//Print out the current monitor
	for (int i = 0; i < spaces; i++) {
		if (array[i] == 0) printf("*");
		else printf("%c", array[i]);
	}
	printf("\n");

	//Set our sync variable
	synchronize = 0;

	//Signal our condition var, and unlock our monitor
	pthread_cond_signal(&condition);
	pthread_mutex_unlock(&lock);
}
