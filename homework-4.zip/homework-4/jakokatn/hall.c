#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

static int hallSize;
static char * allocation;
static pthread_mutex_t lock;

void initMonitor( int n ) {
  hallSize = n;

  // malloc our state string to size n and initialize to all * characters
  allocation = ( char * ) malloc( ( n ) * sizeof( char ) );
  for ( int i = 0; i < n; i++ ) {
    allocation[ i ] = '*';
  }
  allocation[ n ] = '\0';

  // init mutex
  int res = pthread_mutex_init(&lock, NULL);
  if ( res != 0 ) {
    printf( "Failed to initialize mutex.\n" );
    exit( 1 );
  }
}

void destroyMonitor() {
  // free malloced memory
  free( allocation );  

  // destroy mutex
  pthread_mutex_destroy(&lock);
}

int allocateSpace( char const *name, int width ) {
  int retIndex = -2;

  // repeat until we find an open space
  while ( retIndex < 0 ) {
    // lock mutex
    pthread_mutex_lock(&lock);

    // search for sufficient space
    int currentWidth = 0;
    for ( int i = 0; i < hallSize; i++ ) {
      // count open space if char is a *
      if ( allocation[ i ] == '*' ) {
        currentWidth++;
      } else {
        currentWidth = 0;
      }

      // if the width of this section is sufficient, fill it
      if ( currentWidth == width ) {

        // iterate backwards, filling each character
        for ( int j = i; j > i - width; j-- ) {
          allocation[ j ] = name[ 0 ]; // set it to first char of name
        }

        // set index to be returned
        retIndex = i - width + 1;

        // print allocation and break from for loop
        printf( "%s allocated: %s\n", name, allocation );
        break;
      }
    } 

    // print message if waiting
    if ( retIndex == -2 ) {
      printf( "%s waiting: %s\n", name, allocation );
      retIndex = -1;
    }

    // unlock mutex
    pthread_mutex_unlock(&lock);
  }

  return retIndex;
}

void freeSpace( char const *name, int start, int width ) {
  // lock mutex
  pthread_mutex_lock(&lock);

  // iterate over indices, setting them to * chars
  for ( int i = start; i < start + width; i++ ) {
    allocation[ i ] = '*';
  }

  printf( "%s freed: %s\n", name, allocation );

  // unlock mutex
  pthread_mutex_unlock(&lock);
}
