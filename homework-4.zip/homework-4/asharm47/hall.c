/**
 * simulation of conference hall allocation system
 * @author Arnav Sharma
 * @file hall.c
 *
 */

#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// global variables
int topIndex = 0;
int perm;
pthread_mutex_t monitor = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
char *charArray;

/** initializes the monitors using the pthread
 * @param n length
 */
void initMonitor(int n)
{
    perm = n;
    // makes a space for the charArray and fills it with *.
    pthread_cond_init(&cond, NULL);
    charArray = (char *)malloc((n * (sizeof(char))) + sizeof(char));
    for (int i = 0; i < n - 1; i++) {
        charArray[i] = '*';
    }
    charArray[n] = '\0';
}

/** destroys the monitor using free Arrays
 *  @param n length
 */
void destroyMonitor()
{
    // this frees the monitor
    free(charArray);
}

/** allocates space for the char Array
 * @param name charArray
 * @param width length of name
 */
int allocateSpace(char const *name, int width)
{
    pthread_mutex_lock(&monitor);
    // check if theres space for slot
    char oldCharacter = ' ';
    int counter = 0;
    for (int i = 0; i < perm; i++) {
        if (oldCharacter == '*' && charArray[i] == '*') {
            oldCharacter = '*';
            counter++;
        } else if (oldCharacter != '*' && charArray[i] == '*') {
            oldCharacter = '*';
            counter = 1;
        }
        if (counter == width) {
            topIndex = i;
            int idx = i - width;
            for (int j = idx; j < width; j++) {
                charArray[i] = name[0];
            }
        }
        if (oldCharacter != '*' && charArray[i] != '*') {
            oldCharacter = ' ';
            counter = 0;
            continue;
        }
        if (i == perm - 1) {
            printf("%s: ", name);
            for (int l = 0; l < perm; l++) {
                printf(&charArray[i]);
            }
        }
    }
    return topIndex;
    pthread_mutex_unlock(&monitor);
}

/** allocates space for the char Array
 * @param name charArray
 * @param start integers
 * @param width length of name
 */
void freeSpace(char const *name, int start, int width)
{
    pthread_mutex_lock(&monitor);

    pthread_mutex_unlock(&monitor);
}