/**
 * @author Jack Benton (jnbenton)
 * @file hall.c
 * This file implements the monitor's functions
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <stdbool.h>
#include "hall.h"

static pthread_mutex_t mut;
static pthread_cond_t block;
static char *hall;
static int HALL_SIZE = 20;

/*
 This function initializes the monitor, allocating any heap memory it needs
 and initializing its state when necessary. 
 @param n the total width of the hall - number of spaces it contains 
*/
void initMonitor(int n) {
    pthread_mutex_init(&mut, NULL);
    pthread_cond_init(&block, NULL);
    hall = malloc(10 * sizeof(char));
    // Initialize hall to all zeros
    for (int i = 0; i < HALL_SIZE; i++) {
        hall[i] = '*';
    }
}

/**
 * This function frees any resource used by the monitor (destroys) 
 */
void destroyMonitor() {
    pthread_mutex_destroy(&mut);
    pthread_cond_destroy(&block);
    free(hall);
}

bool noSpace(int width) {
    int contig = 0;
    for (int i = 0; i < 10; i++) {
        if (hall[i] == '*') {
            contig++;
        } else {
            contig = 0;
        }
        if (contig == width) {
            return false;
        }
    }
    return true;
}

int findSpace(int width) {
    int contig = 0;
    int start = 0;
    for (int i = 0; i < HALL_SIZE; i++) {
        if (hall[i] == '*') {
            start = i;
            contig++;
            for (int j = i + 1; j < HALL_SIZE; j++) {
                if (hall[i] == '*') {
                    contig++;
                    if (contig == width) {
                        return start;
                    }
                } else {
                    contig = 0;
                    break;
                }
            }
        }
        contig = 0;
    }
    return -1;
}

/**
 * This function is called by a thread when it wants to use a space in the hall.
 * @param name name of the organization of the thread
 * @param width the width of the contigous space the thread needs
 * @return start - the index of the leftmost space assigned to the thread
 */
int allocateSpace(char const *name, int width) {
    // If no space is available, make thread wait until space is available
    // If waiting 
    pthread_mutex_lock(&mut);
    while (noSpace(width)) {
        printf("%s waiting: %s\n", name, hall);
        pthread_cond_wait(&block, &mut);
    }
    int start = findSpace(width);
    for (int i = start; i < (start + width); i++) {
        hall[i] = name[0];
    }

    // Once the thread has its requested space
    pthread_mutex_unlock(&mut);
    printf("%s allocated: %s\n", name, hall);

    return start;
}

/**
 * This function is called by a thread when it is done using the space it was given 
 * in a previous call to allocateSpace(). 
 * @param name name of the thread's organization
 * @param start index of the leftmost space allocated to the thread
 * @param width the number of contigous spaces allocated to the thread 
 */
void freeSpace(char const* name, int start, int width) {
    // This function makes spaces from start up to start + (width - 1) considered
    // available and may be given to some other thread
    for (int i = start; i < (start + width); i++) {
        hall[i] = '*';
    }

    //Once done 
    pthread_cond_signal(&block);
    printf("%s freed: %s\n", name, hall);
}