#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

//number of spaces allowed for this monitor
pthread_mutex_t count;
//the condition set by the monitor for allocated space
pthread_cond_t allocated;
//the allocated room in the hall itself
char *hallspace;

//Initializes the monitor to a given n value
void initMonitor(int n)
{
    //create the hallway space
    hallspace = (char *) malloc(sizeof(char)*n);
    //add stars to the hallspace for references in printline
    memset(hallspace, '*', sizeof(hallspace));
    //create the condition variable
    pthread_cond_t allocated = PTHREAD_COND_INITIALIZER;
    pthread_mutex_init(&count, n);
}

//frees up the monitor after it is used
void destroyMonitor()
{
    free(hallspace);
    pthread_cond_destroy(&allocated);
    pthread_mutex_destroy(&count);
}

//allocates the given space for the name and the memory spacing it needs
int allocateSpace( char const *name, int width )
{
    pthread_mutex_lock(&count);
    int index = 0;
    //lock the space needed or wait if neccesary
    for(int i=0; i<width; i++){
        pthread_cond_wait(&allocated, &count);
    }
    //allocate the space
    bool spaceHere = false;
    for(int i=0; i<hallspace[i]; i++){
        if(strcmp(hallspace[i+width-1], '*') == 0 && strcmp(hallspace[i], '*') == 0){
            spaceHere = true;
            index = i;
        }
        //spaceHere = true;
    }
    if(!spaceHere){
        printf("%s waiting: %s\n", name, hallspace);
        pthread_cond_wait(&allocated, &count);
    }
    printf("%s allocated: %s\n", name, hallspace);
    return index;
}

//frees the memory space for the name and the width it was given
void freeSpace( char const *name, int start, int width )
{
    for(int i=0; i<width; i++){
        pthread_mutex_unlock(&count);
    }
    pthread_cond_signal(&allocated);
    printf("%s freed: %s\n", name, hallspace);
}