#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "hall.h"

//char pointer representing the hall space
static char *hall;
//total size of the hall space
static int size;
//lock access for the hall
static pthread_mutex_t mon;
//condition for blocking organizations, is there enough space available
static pthread_cond_t unavailable;


void initMonitor( int n ) {
    hall = (char *)malloc(n * sizeof(char));

    //initializes all hall spaces to empty
    for (int i = 0; i < n; i++) {
        hall[i] = '*';
    }
    size = n;
    pthread_mutex_init( &mon, NULL);
    pthread_cond_init( &unavailable, NULL);
}

void destroyMonitor() {
    free(hall);
}

int allocateSpace( char const *name, int width ) {

    //enter monitor
    pthread_mutex_lock(&mon);
    bool printed = false;
    
    int start = 0;
    //length of current contiguous space blocks
    int currSpace = 0;

    //look through the hall spaces and find the first contiguous block that is big enough
    for (int i = 0; i < size; i++) {
        if (hall[i] != '*') {
            continue;
        } else {
            currSpace++;
        }
        if (currSpace >= width) {
            start = i;
            break;
        }
        for (int j = i + 1; j < size; j++) {
            if (hall[j] != '*') {
                break;
            } else {
                currSpace++;
            }
        }
        if (currSpace >= width) {
            start = i;
            break;
        }
        currSpace = 0;
    }

    //if we find a suitable space, allocate space
    if (currSpace != 0) {
        for (int i = 0; i < width; i++) {
            hall[start + i] = name[0];
        }
        printf("%s allocated: %s\n", name, hall);

        //leave monitor
        pthread_mutex_unlock(&mon);
        return start;
    }

    //if we did not find a large enough space, wait and check again
    while (currSpace == 0) {
        if (!printed) {
            printf("%s waiting: %s\n", name, hall);
            printed = true;
        }
        pthread_cond_wait(&unavailable, &mon);

        for (int i = 0; i < size; i++) {
            if (hall[i] != '*') {
                continue;
            } else {
                currSpace++;
            }
            if (currSpace >= width) {
                start = i;
                break;
            }
            for (int j = i + 1; j < size; j++) {
                if (hall[j] != '*') {
                    break;
                } else {
                    currSpace++;
                }
            }
            if (currSpace >= width) {
                start = i;
                break;
            }
            currSpace = 0;
        }
    }

    //once we find the space then update the hall with the newly reserved spaces
    for (int i = 0; i < width; i++) {
        hall[start + i] = name[0];
    }

    printf("%s allocated: %s\n", name, hall);

    //leave monitor
    pthread_mutex_unlock(&mon);

    return start;
}

void freeSpace(char const *name, int start, int width) {

    //enter monitor
    pthread_mutex_lock(&mon);

    //update the hall with newly freed spaces
    for (int i = start; i < start + width; i++) {
        hall[i] = '*';
    }

    printf("%s freed: %s\n", name, hall);

    //once space is freed, signal all other organizations that space is available
    pthread_cond_broadcast( &unavailable);

    //leave monitor
    pthread_mutex_unlock(&mon);
}
