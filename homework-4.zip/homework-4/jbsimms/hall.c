#include "hall.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

static int hallSize;
static pthread_mutex_t lock;
static pthread_cond_t spaceAvailable;
static char *hall;

// n is number of spaces in hall
void initMonitor( int n )
{
    //Allocate lock and condition variables in the heap
    hall = ( char * ) malloc ( (n + 1) * sizeof(char) );

    //Itialize state where necessary
    hallSize = n;
    pthread_mutex_init( &lock, NULL );
    pthread_cond_init( &spaceAvailable, NULL );
    for (int i = 0; i < n; i++)
        hall[i] = '*';
    hall[n + 1] = '\0';
}

void destroyMonitor()
{
    free(hall);
}

int checkFit( int width ) //make this another monitor?
{
    int n = width;

    //See if there's enough consecutive open spaces
    for (int i = 0; i < hallSize; i++) {
        if (hall[i] == '*')
            n--;
        else
            n = width;
        if (n == 0)
            return i - width + 1;
    }
    return -1;
}

int allocateSpace( char const *name, int width )
{
    pthread_mutex_lock( &lock );

    int fit = checkFit(width);

    //Makes thread wait if there isn't enough space for the organization
    if (fit == -1)
        printf( "%s waiting: %s\n", name, hall );
    while (fit == -1) {
        pthread_cond_wait( &spaceAvailable, &lock );
        fit = checkFit(width);
    }

    //When there's enough space (width), give it to the organization
    for (int i = fit; i < (fit + width); i++)
        hall[i] = name[0];

    //Print allocated message "name allocated: current-allocation"
    printf( "%s allocated: %s\n", name, hall );

    pthread_mutex_unlock( &lock );
    return fit;
}

void freeSpace( char const *name, int start, int width )
{
    pthread_mutex_lock( &lock );

    //Free spaces
    for (int i = start; i < (start + width); i++)
        hall[i] = '*';

    //Print free message "name freed: current-allocated"
    printf( "%s freed: %s\n", name, hall );

    pthread_cond_signal( &spaceAvailable );
    pthread_mutex_unlock( &lock );
}
