#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "hall.h"

static char *hall;

static int cap;

static int wait;

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static pthread_cond_t condition = PTHREAD_COND_INITIALIZER;



/** Initialize the monitor as a hall with n spaces that can be partitioned
    off. */
void initMonitor( int n ) {

  hall = (char *)calloc(n * sizeof(char), sizeof(char));

  for(int i = 0; i < n; i++) {
    hall[i] = '*';
  }

  cap = n;

}

/** Destroy the monitor, freeing any resources it uses. */
void destroyMonitor() {

  free(hall);

}

int checkSpace(int width) {

  int start = 0;
  int space = 0;

  for(int i = 0; i < cap; i++ ) {
    if(hall[i] == '*') {
      if(space < 1) {
        start = i;
      }
      space++;
    }
    else {
      start = i;
      space = 0;
    }

    if(space == width) {
      return start;
    }
  }

  return -1;

}

/** Called when an organization wants to reserve the given number
    (width) of contiguous spaces in the hall.  Returns the index of
    the left-most (lowest-numbered) end of the space allocated to the
    organization. */
int allocateSpace( char const *name, int width ) {
  pthread_mutex_lock( &lock );

  bool check = true;
  int start = -1;

  while(check) {

    if(start == -1) {
      start = checkSpace(width);
    }

    if(start == -1) {
      wait = width;
      printf("%s waiting: %s\n", name, hall );
      pthread_cond_wait( &condition, &lock );
    }
    else {
      check = false;

      for(int i = start; i < start + width; i++) {
        hall[i] = name[0];
      }
    }

  }

  printf("%s allocated: %s\n", name, hall );
  pthread_mutex_unlock( &lock );

  return start;

}

/** Relese the allocated spaces from index start up to (and including)
    index start + width - 1. */
void freeSpace( char const *name, int start, int width ) {

  pthread_mutex_lock( &lock );

  for(int i = start; i < start + width; i++) {
    hall[i] = '*';
  }

  printf("%s freed: %s\n", name, hall );

  if(checkSpace(wait) != -1) {
    pthread_cond_signal( &condition);
  }

  pthread_mutex_unlock( &lock );

}
