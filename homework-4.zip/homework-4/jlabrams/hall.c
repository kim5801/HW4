/**
* A file that implements a monitor, coordinating reserving the sections of a large conference room.
* @file hall.c
* @author Jaden Abrams (jlabrams)
*/
#include "hall.h"
#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

// This holds the current state of the hall
char *reservations;
// the size of the hall
int hallsize = 0;
// the biggest space in the hall
int biggestSpace = 0;
// the monitor for the hall
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// used to make sure that threads only get sections one at a time
pthread_cond_t waitForRoom = PTHREAD_COND_INITIALIZER;
/**
* Creates the monitor and its starting state
* @param n the size of the hall
*/
void initMonitor( int n ) {
    reservations = (char *) malloc(n * sizeof(char) + 1);
    hallsize = n;
    biggestSpace = n;
    for(int i = 0; i < n; i++) {
        reservations[i] = '*';
    }
    reservations[n] = 0;
}
/** Destroys the dynamically allocated string holding the hall state*/
void destroyMonitor() {
    free(reservations);
}
/** Finds the biggest space and updates the global variable holding it*/
static void findBiggestSpace() {
    int biggestFound = 0;
    int contender = 0;
    for(int i = 0; i < hallsize; i++) { // finds the biggest space by counting if the space is blank (*)
        if(reservations[i] == '*') {
            contender++;
            if(contender > biggestFound) {
                biggestFound = contender;
            }
        }
        else {// we hit a reserved space, reset the contender
            contender = 0;
        }
    }
    biggestSpace = biggestFound; // update the biggestFound space
}

/**
* Finds the first section in the hall that is big enough for the thread.
* This returns -1 if we couldn't find a big enough space
* @param width the requested width
* @return the index of the first space big enough
*/
static int findFirstFit(int width) {
    int start = -1;// use -1 for error checking and as a default for not finding a fit
    int w = 0;
    for(int i = 0; i < hallsize; i++) {
        if(reservations[i] == '*') {//we found an empty slot, update the count
            if(start == -1) {
                start = i;
            }
            w++;
            if(w == width) {// return once we found a space that's just big enough
                return start;
            }
        }
        if(reservations[i] != '*') {
            start = -1;
            w = 0;
        }
    }
    return -1; // if we've gotten to this point, there couldn't have been a big enough space, so return -1
}

/**
* Synchronized function that a thread uses to book part of the hall
* This makes the thread wait until there is enough space for it, at which point, it
* enters the critical section, takes its space, then returns the starting point for the reserved section
* @param name the organization name
* @param width the space the organization needs
* @return the starting point for the reserved space
*/
int allocateSpace(char const *name, int width) {
    // wait for a big enough space
    bool alreadyPrinted = false;
    pthread_mutex_lock(&mon); // enter the monitor
    while( biggestSpace < width ) { // wait if the biggest space is too small for us
        if(!alreadyPrinted) {
            printf("%s waiting: %s\n", name, reservations);
            alreadyPrinted = true;
        }
        pthread_cond_wait(&waitForRoom, &mon);
    }
    int start = findFirstFit(width); // find the first fit for the reservation
    for(int i = start; i < start + width; i++) { // fill in reservation chart
        reservations[i] = name[0];
    }
    printf("%s allocated: %s\n", name, reservations); // print update for user
    findBiggestSpace();
    pthread_mutex_unlock(&mon);
    return start;
}

/**
* Frees the space taken by the organization
* @param name the organization name
* @param start the starting index of the reserved space
* @param width the reserved width
*/
void freeSpace(char const *name, int start, int width) {
    pthread_mutex_lock(&mon); // enter the monitor and clear the space we reserved
    for(int i = start;i < start + width; i++) {
        reservations[i] = '*';
    }
    findBiggestSpace(); // find the biggest space, signal waiting threads, then exit
    pthread_cond_signal(&waitForRoom);
    pthread_mutex_unlock(&mon);
}